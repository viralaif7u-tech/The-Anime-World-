import type {
  AnimeDetail,
  AnimeSummary,
  CharacterSummary,
  DiscoverParams,
  DiscoverResponse,
} from '../src/types/anime.ts';
import { buildAnimeUrl, stripHtmlTags } from '../src/lib/validation.ts';

const ANILIST_ENDPOINT = 'https://graphql.anilist.co';
const JIKAN_ENDPOINT = 'https://api.jikan.moe/v4';

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

const cache = new Map<string, CacheEntry<unknown>>();
let lastRequestAt = 0;

function getCached<T>(key: string): T | null {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    cache.delete(key);
    return null;
  }
  return entry.value as T;
}

function setCached<T>(key: string, value: T, ttlMs: number): void {
  if (cache.size > 400) {
    const firstKey = cache.keys().next().value;
    if (firstKey) cache.delete(firstKey);
  }
  cache.set(key, { value, expiresAt: Date.now() + ttlMs });
}

async function fetchWithRetry(url: string, init: RequestInit, retries = 2): Promise<Response> {
  const now = Date.now();
  const elapsed = now - lastRequestAt;
  if (elapsed < 120) {
    await new Promise((r) => setTimeout(r, 120 - elapsed));
  }
  lastRequestAt = Date.now();

  let lastError: unknown = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 12000);
      const res = await fetch(url, { ...init, signal: controller.signal });
      clearTimeout(timer);

      if (res.status === 429 || res.status >= 500) {
        const retryAfter = Number(res.headers.get('Retry-After') || 0);
        const delay = retryAfter > 0 ? retryAfter * 1000 : 400 * Math.pow(2, attempt);
        if (attempt < retries) {
          await new Promise((r) => setTimeout(r, delay));
          continue;
        }
      }
      return res;
    } catch (err) {
      lastError = err;
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, 350 * Math.pow(2, attempt)));
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error('External anime metadata request failed');
}

interface RawAniListMedia {
  id: number;
  title: {
    english: string | null;
    romaji: string;
    native: string | null;
  };
  coverImage: {
    extraLarge: string | null;
    large: string | null;
    color: string | null;
  } | null;
  bannerImage: string | null;
  format: string | null;
  status: string | null;
  episodes: number | null;
  duration: number | null;
  season: string | null;
  seasonYear: number | null;
  averageScore: number | null;
  popularity: number | null;
  genres: string[] | null;
  countryOfOrigin: string | null;
  source: string | null;
  description: string | null;
  synonyms?: string[] | null;
  studios?: {
    nodes: Array<{ name: string }>;
  } | null;
  nextAiringEpisode?: {
    episode: number;
    airingAt: number;
  } | null;
}

function normalizeAniListMedia(m: RawAniListMedia): AnimeSummary {
  const displayTitle = m.title?.english || m.title?.romaji || m.title?.native || `Anime #${m.id}`;
  return {
    id: m.id,
    slug: buildAnimeUrl(m.id, displayTitle).replace('/anime/', ''),
    title: {
      english: m.title?.english ?? null,
      romaji: m.title?.romaji ?? displayTitle,
      native: m.title?.native ?? null,
    },
    displayTitle,
    coverImage: {
      extraLarge: m.coverImage?.extraLarge ?? null,
      large: m.coverImage?.large ?? null,
      color: m.coverImage?.color ?? null,
    },
    bannerImage: m.bannerImage ?? null,
    format: m.format ?? null,
    status: m.status ?? null,
    episodes: m.episodes ?? null,
    duration: m.duration ?? null,
    season: m.season ?? null,
    seasonYear: m.seasonYear ?? null,
    averageScore: m.averageScore ?? null,
    popularity: m.popularity ?? null,
    genres: Array.isArray(m.genres) ? m.genres : [],
    countryOfOrigin: m.countryOfOrigin ?? null,
    source: m.source ?? null,
    studios: m.studios?.nodes?.map((s) => s.name) ?? [],
    synopsis: stripHtmlTags(m.description) || 'Synopsis not provided by metadata source.',
    nextAiringEpisode: m.nextAiringEpisode ?? null,
  };
}

const DISCOVER_QUERY = `
query DiscoverAnime(
  $page: Int,
  $perPage: Int,
  $search: String,
  $genre: String,
  $seasonYear: Int,
  $season: MediaSeason,
  $countryOfOrigin: CountryCode,
  $format: MediaFormat,
  $status: MediaStatus,
  $sort: [MediaSort],
  $averageScore_greater: Int,
  $popularity_lesser: Int,
  $startDate_lesser: FuzzyDateInt
) {
  Page(page: $page, perPage: $perPage) {
    pageInfo {
      total
      currentPage
      lastPage
      hasNextPage
      perPage
    }
    media(
      type: ANIME,
      isAdult: false,
      search: $search,
      genre: $genre,
      seasonYear: $seasonYear,
      season: $season,
      countryOfOrigin: $countryOfOrigin,
      format: $format,
      status: $status,
      sort: $sort,
      averageScore_greater: $averageScore_greater,
      popularity_lesser: $popularity_lesser,
      startDate_lesser: $startDate_lesser
    ) {
      id
      title {
        english
        romaji
        native
      }
      coverImage {
        extraLarge
        large
        color
      }
      bannerImage
      format
      status
      episodes
      duration
      season
      seasonYear
      averageScore
      popularity
      genres
      countryOfOrigin
      source
      description(asHtml: false)
      studios(isMain: true) {
        nodes {
          name
        }
      }
      nextAiringEpisode {
        episode
        airingAt
      }
    }
  }
}
`;

const ANIME_DETAIL_QUERY = `
query AnimeDetail($id: Int!) {
  Media(id: $id, type: ANIME, isAdult: false) {
    id
    title {
      english
      romaji
      native
    }
    synonyms
    coverImage {
      extraLarge
      large
      color
    }
    bannerImage
    format
    status
    episodes
    duration
    season
    seasonYear
    averageScore
    popularity
    genres
    countryOfOrigin
    source
    description(asHtml: false)
    trailer {
      id
      site
      thumbnail
    }
    studios {
      nodes {
        name
      }
    }
    nextAiringEpisode {
      episode
      airingAt
    }
    characters(sort: [ROLE, FAVOURITES_DESC], perPage: 16) {
      edges {
        role
        voiceActors(language: JAPANESE, sort: [RELEVANCE, ID]) {
          id
          name {
            full
          }
          languageV2
          image {
            medium
          }
        }
        node {
          id
          name {
            full
            native
          }
          image {
            large
          }
        }
      }
    }
    staff(sort: [RELEVANCE, ID], perPage: 8) {
      edges {
        role
        node {
          id
          name {
            full
          }
          image {
            medium
          }
        }
      }
    }
    relations {
      edges {
        relationType
        node {
          id
          type
          isAdult
          title {
            english
            romaji
            native
          }
          coverImage {
            extraLarge
            large
            color
          }
          bannerImage
          format
          status
          episodes
          duration
          season
          seasonYear
          averageScore
          popularity
          genres
          countryOfOrigin
          source
          description(asHtml: false)
        }
      }
    }
    recommendations(sort: [RATING_DESC], perPage: 8) {
      nodes {
        mediaRecommendation {
          id
          type
          isAdult
          title {
            english
            romaji
            native
          }
          coverImage {
            extraLarge
            large
            color
          }
          bannerImage
          format
          status
          episodes
          duration
          season
          seasonYear
          averageScore
          popularity
          genres
          countryOfOrigin
          source
          description(asHtml: false)
        }
      }
    }
  }
}
`;

const CHARACTERS_QUERY = `
query DiscoverCharacters($page: Int, $perPage: Int, $search: String) {
  Page(page: $page, perPage: $perPage) {
    pageInfo {
      total
      currentPage
      lastPage
      hasNextPage
      perPage
    }
    characters(search: $search, sort: [FAVOURITES_DESC]) {
      id
      name {
        full
        native
      }
      image {
        large
      }
      favourites
      description(asHtml: false)
      media(type: ANIME, sort: [POPULARITY_DESC], perPage: 3) {
        nodes {
          id
          isAdult
          title {
            english
            romaji
          }
          coverImage {
            large
          }
          format
        }
      }
    }
  }
}
`;

const CHARACTER_DETAIL_QUERY = `
query CharacterDetail($id: Int!) {
  Character(id: $id) {
    id
    name {
      full
      native
    }
    image {
      large
    }
    favourites
    description(asHtml: false)
    media(type: ANIME, sort: [POPULARITY_DESC], perPage: 12) {
      nodes {
        id
        isAdult
        title {
          english
          romaji
        }
        coverImage {
          large
        }
        format
      }
    }
  }
}
`;

function getCurrentSeason(): { season: string; year: number } {
  const now = new Date();
  const m = now.getMonth() + 1;
  const year = now.getFullYear();
  if (m <= 3) return { season: 'WINTER', year };
  if (m <= 6) return { season: 'SPRING', year };
  if (m <= 9) return { season: 'SUMMER', year };
  return { season: 'FALL', year };
}

function buildAniListVariables(params: DiscoverParams): Record<string, unknown> {
  const page = Math.max(1, Number(params.page || 1));
  const perPage = Math.min(30, Math.max(1, Number(params.perPage || 20)));
  const vars: Record<string, unknown> = { page, perPage };

  if (params.search && params.search.trim()) {
    vars.search = params.search.trim();
  }
  if (params.genre && params.genre !== 'ALL') {
    vars.genre = params.genre;
  }
  if (params.year && params.year !== 'ALL') {
    const yr = Number(params.year);
    if (Number.isInteger(yr) && yr > 1950) vars.seasonYear = yr;
  }
  if (params.season && params.season !== 'ALL') {
    vars.season = params.season.toUpperCase();
  }
  if (params.country && params.country !== 'ALL') {
    vars.countryOfOrigin = params.country.toUpperCase();
  }
  if (params.format && params.format !== 'ALL') {
    vars.format = params.format.toUpperCase();
  }
  if (params.status && params.status !== 'ALL') {
    vars.status = params.status.toUpperCase();
  }

  let sort: string[] = ['TRENDING_DESC', 'POPULARITY_DESC'];
  switch (params.category) {
    case 'trending':
      sort = ['TRENDING_DESC', 'POPULARITY_DESC'];
      break;
    case 'popular':
      sort = ['POPULARITY_DESC'];
      break;
    case 'top_rated':
      sort = ['SCORE_DESC', 'POPULARITY_DESC'];
      break;
    case 'latest':
      sort = ['START_DATE_DESC', 'POPULARITY_DESC'];
      break;
    case 'upcoming':
      vars.status = vars.status || 'NOT_YET_RELEASED';
      sort = ['POPULARITY_DESC'];
      break;
    case 'airing':
      vars.status = vars.status || 'RELEASING';
      sort = ['TRENDING_DESC', 'POPULARITY_DESC'];
      break;
    case 'classic':
      vars.startDate_lesser = 20050101;
      sort = ['SCORE_DESC', 'POPULARITY_DESC'];
      break;
    case 'hidden_gems':
      vars.averageScore_greater = 78;
      vars.popularity_lesser = 60000;
      sort = ['SCORE_DESC'];
      break;
    case 'seasonal': {
      const current = getCurrentSeason();
      if (!vars.season) vars.season = current.season;
      if (!vars.seasonYear) vars.seasonYear = current.year;
      sort = ['POPULARITY_DESC'];
      break;
    }
    case 'recommended':
      vars.averageScore_greater = 80;
      sort = ['SCORE_DESC', 'TRENDING_DESC'];
      break;
    default:
      break;
  }

  if (params.sort && params.sort !== 'DEFAULT') {
    sort = [params.sort];
  } else if (params.search && params.search.trim()) {
    sort = ['SEARCH_MATCH', 'POPULARITY_DESC'];
  }

  vars.sort = sort;
  return vars;
}

async function queryAniList<T>(query: string, variables: Record<string, unknown>): Promise<T> {
  const res = await fetchWithRetry(ANILIST_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify({ query, variables }),
  });

  if (!res.ok) {
    const bodyText = await res.text().catch(() => '');
    throw new Error(`AniList API HTTP ${res.status}: ${bodyText.slice(0, 200)}`);
  }

  const json = (await res.json()) as { data?: T; errors?: Array<{ message: string }> };
  if (json.errors?.length) {
    throw new Error(`AniList GraphQL error: ${json.errors.map((e) => e.message).join('; ')}`);
  }
  if (!json.data) {
    throw new Error('AniList returned empty data payload');
  }
  return json.data;
}

async function discoverViaJikan(params: DiscoverParams): Promise<DiscoverResponse> {
  const page = Math.max(1, Number(params.page || 1));
  const limit = Math.min(25, Math.max(1, Number(params.perPage || 20)));
  const qs = new URLSearchParams({
    page: String(page),
    limit: String(limit),
    sfw: 'true',
  });
  if (params.search?.trim()) qs.set('q', params.search.trim());
  if (params.category === 'top_rated') {
    qs.set('order_by', 'score');
    qs.set('sort', 'desc');
  } else if (params.category === 'upcoming') {
    qs.set('status', 'upcoming');
  } else if (params.category === 'airing') {
    qs.set('status', 'airing');
  } else {
    qs.set('order_by', 'popularity');
    qs.set('sort', 'asc');
  }

  const res = await fetchWithRetry(`${JIKAN_ENDPOINT}/anime?${qs.toString()}`, {
    headers: { Accept: 'application/json' },
  });
  if (!res.ok) {
    throw new Error(`Jikan fallback HTTP ${res.status}`);
  }
  const payload = (await res.json()) as {
    data: Array<{
      mal_id: number;
      title: string;
      title_english: string | null;
      title_japanese: string | null;
      images?: { jpg?: { large_image_url?: string; image_url?: string } };
      type: string | null;
      status: string | null;
      episodes: number | null;
      score: number | null;
      popularity: number | null;
      genres?: Array<{ name: string }>;
      studios?: Array<{ name: string }>;
      synopsis: string | null;
      year: number | null;
      season: string | null;
    }>;
    pagination: {
      last_visible_page: number;
      has_next_page: boolean;
      items?: { total: number; per_page: number };
      current_page: number;
    };
  };

  const items: AnimeSummary[] = payload.data.map((m) => {
    const displayTitle = m.title_english || m.title;
    return {
      id: m.mal_id,
      slug: buildAnimeUrl(m.mal_id, displayTitle).replace('/anime/', ''),
      title: {
        english: m.title_english,
        romaji: m.title,
        native: m.title_japanese,
      },
      displayTitle,
      coverImage: {
        extraLarge: m.images?.jpg?.large_image_url || m.images?.jpg?.image_url || null,
        large: m.images?.jpg?.image_url || null,
        color: '#5126A8',
      },
      bannerImage: m.images?.jpg?.large_image_url || null,
      format: m.type?.toUpperCase() || null,
      status: m.status || null,
      episodes: m.episodes,
      duration: null,
      season: m.season?.toUpperCase() || null,
      seasonYear: m.year,
      averageScore: m.score ? Math.round(m.score * 10) : null,
      popularity: m.popularity,
      genres: m.genres?.map((g) => g.name) || [],
      countryOfOrigin: 'JP',
      source: null,
      studios: m.studios?.map((s) => s.name) || [],
      synopsis: m.synopsis || 'Synopsis not provided.',
      nextAiringEpisode: null,
    };
  });

  return {
    items,
    pageInfo: {
      total: payload.pagination?.items?.total || items.length,
      currentPage: payload.pagination?.current_page || page,
      lastPage: payload.pagination?.last_visible_page || 1,
      hasNextPage: Boolean(payload.pagination?.has_next_page),
      perPage: limit,
    },
    source: 'Jikan REST API',
  };
}

export async function discoverAnime(params: DiscoverParams): Promise<DiscoverResponse> {
  const vars = buildAniListVariables(params);
  const cacheKey = `discover:${JSON.stringify(vars)}`;
  const cached = getCached<DiscoverResponse>(cacheKey);
  if (cached) return cached;

  try {
    const data = await queryAniList<{
      Page: {
        pageInfo: {
          total: number;
          currentPage: number;
          lastPage: number;
          hasNextPage: boolean;
          perPage: number;
        };
        media: RawAniListMedia[];
      };
    }>(DISCOVER_QUERY, vars);

    const seen = new Set<number>();
    const items: AnimeSummary[] = [];
    for (const raw of data.Page.media) {
      if (!seen.has(raw.id)) {
        seen.add(raw.id);
        items.push(normalizeAniListMedia(raw));
      }
    }

    const result: DiscoverResponse = {
      items,
      pageInfo: data.Page.pageInfo,
      source: 'AniList GraphQL API',
    };
    setCached(cacheKey, result, 5 * 60 * 1000);
    return result;
  } catch (err) {
    console.warn('AniList discover failed, attempting Jikan fallback:', err);
    const jikanRes = await discoverViaJikan(params);
    setCached(cacheKey, jikanRes, 3 * 60 * 1000);
    return jikanRes;
  }
}

export async function getAnimeDetail(id: number): Promise<AnimeDetail> {
  const cacheKey = `anime:${id}`;
  const cached = getCached<AnimeDetail>(cacheKey);
  if (cached) return cached;

  const data = await queryAniList<{
    Media: RawAniListMedia & {
      trailer?: { id: string; site: string; thumbnail: string | null } | null;
      characters?: {
        edges: Array<{
          role: string;
          voiceActors: Array<{
            id: number;
            name: { full: string };
            languageV2: string;
            image: { medium: string | null } | null;
          }>;
          node: {
            id: number;
            name: { full: string; native: string | null };
            image: { large: string | null } | null;
          };
        }>;
      };
      staff?: {
        edges: Array<{
          role: string;
          node: {
            id: number;
            name: { full: string };
            image: { medium: string | null } | null;
          };
        }>;
      };
      relations?: {
        edges: Array<{
          relationType: string;
          node: RawAniListMedia & { type: string; isAdult: boolean };
        }>;
      };
      recommendations?: {
        nodes: Array<{
          mediaRecommendation: (RawAniListMedia & { type: string; isAdult: boolean }) | null;
        }>;
      };
    };
  }>(ANIME_DETAIL_QUERY, { id });

  const m = data.Media;
  const base = normalizeAniListMedia(m);

  const detail: AnimeDetail = {
    ...base,
    synonyms: Array.isArray(m.synonyms) ? m.synonyms : [],
    trailer: m.trailer ?? null,
    characters:
      m.characters?.edges?.map((edge) => ({
        id: edge.node.id,
        name: edge.node.name.full,
        nativeName: edge.node.name.native,
        role: edge.role,
        image: edge.node.image?.large ?? null,
        voiceActor: edge.voiceActors?.[0]
          ? {
              id: edge.voiceActors[0].id,
              name: edge.voiceActors[0].name.full,
              language: edge.voiceActors[0].languageV2,
              image: edge.voiceActors[0].image?.medium ?? null,
            }
          : null,
      })) ?? [],
    staff:
      m.staff?.edges?.map((edge) => ({
        id: edge.node.id,
        name: edge.node.name.full,
        role: edge.role,
        image: edge.node.image?.medium ?? null,
      })) ?? [],
    relations:
      m.relations?.edges
        ?.filter((e) => e.node.type === 'ANIME' && !e.node.isAdult)
        .map((e) => ({
          relationType: e.relationType,
          media: normalizeAniListMedia(e.node),
        })) ?? [],
    recommendations:
      m.recommendations?.nodes
        ?.map((n) => n.mediaRecommendation)
        .filter((r): r is RawAniListMedia & { type: string; isAdult: boolean } =>
          Boolean(r && r.type === 'ANIME' && !r.isAdult)
        )
        .map(normalizeAniListMedia) ?? [],
    externalSource: 'AniList',
  };

  setCached(cacheKey, detail, 15 * 60 * 1000);
  return detail;
}

export async function discoverCharacters(params: {
  search?: string;
  page?: number;
  perPage?: number;
}): Promise<{
  items: CharacterSummary[];
  pageInfo: { total: number; currentPage: number; lastPage: number; hasNextPage: boolean; perPage: number };
}> {
  const page = Math.max(1, Number(params.page || 1));
  const perPage = Math.min(30, Math.max(1, Number(params.perPage || 24)));
  const vars: Record<string, unknown> = { page, perPage };
  if (params.search?.trim()) vars.search = params.search.trim();

  const cacheKey = `chars:${JSON.stringify(vars)}`;
  const cached = getCached<{
    items: CharacterSummary[];
    pageInfo: { total: number; currentPage: number; lastPage: number; hasNextPage: boolean; perPage: number };
  }>(cacheKey);
  if (cached) return cached;

  const data = await queryAniList<{
    Page: {
      pageInfo: { total: number; currentPage: number; lastPage: number; hasNextPage: boolean; perPage: number };
      characters: Array<{
        id: number;
        name: { full: string; native: string | null };
        image: { large: string | null } | null;
        favourites: number;
        description: string | null;
        media: {
          nodes: Array<{
            id: number;
            isAdult: boolean;
            title: { english: string | null; romaji: string };
            coverImage: { large: string | null } | null;
            format: string | null;
          }>;
        };
      }>;
    };
  }>(CHARACTERS_QUERY, vars);

  const items: CharacterSummary[] = data.Page.characters.map((c) => ({
    id: c.id,
    name: c.name.full,
    nativeName: c.name.native,
    image: c.image?.large ?? null,
    favourites: c.favourites || 0,
    description: stripHtmlTags(c.description) || 'Character profile retrieved from AniList.',
    media: (c.media?.nodes || [])
      .filter((m) => !m.isAdult)
      .map((m) => ({
        id: m.id,
        title: m.title.english || m.title.romaji,
        coverImage: m.coverImage?.large ?? null,
        format: m.format,
      })),
  }));

  const result = { items, pageInfo: data.Page.pageInfo };
  setCached(cacheKey, result, 10 * 60 * 1000);
  return result;
}

export async function getCharacterDetail(id: number): Promise<CharacterSummary> {
  const cacheKey = `char:${id}`;
  const cached = getCached<CharacterSummary>(cacheKey);
  if (cached) return cached;

  const data = await queryAniList<{
    Character: {
      id: number;
      name: { full: string; native: string | null };
      image: { large: string | null } | null;
      favourites: number;
      description: string | null;
      media: {
        nodes: Array<{
          id: number;
          isAdult: boolean;
          title: { english: string | null; romaji: string };
          coverImage: { large: string | null } | null;
          format: string | null;
        }>;
      };
    };
  }>(CHARACTER_DETAIL_QUERY, { id });

  const c = data.Character;
  const charDetail: CharacterSummary = {
    id: c.id,
    name: c.name.full,
    nativeName: c.name.native,
    image: c.image?.large ?? null,
    favourites: c.favourites || 0,
    description: stripHtmlTags(c.description) || 'Character profile retrieved from AniList.',
    media: (c.media?.nodes || [])
      .filter((m) => !m.isAdult)
      .map((m) => ({
        id: m.id,
        title: m.title.english || m.title.romaji,
        coverImage: m.coverImage?.large ?? null,
        format: m.format,
      })),
  };

  setCached(cacheKey, charDetail, 15 * 60 * 1000);
  return charDetail;
}

export const ANILIST_GENRES = [
  'Action',
  'Adventure',
  'Comedy',
  'Drama',
  'Fantasy',
  'Horror',
  'Mahou Shoujo',
  'Mecha',
  'Music',
  'Mystery',
  'Psychological',
  'Romance',
  'Sci-Fi',
  'Slice of Life',
  'Sports',
  'Supernatural',
  'Thriller',
];
