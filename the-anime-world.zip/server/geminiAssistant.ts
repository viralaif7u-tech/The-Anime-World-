import { GoogleGenAI, Type } from '@google/genai';
import { discoverAnime } from './anilistClient.ts';
import type { AnimeSummary } from '../src/types/anime.ts';

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export interface ParsedSearchFilters {
  search: string;
  genre: string;
  year: string;
  format: string;
  category: string;
  reasoning: string;
}

export interface AiRecommendationResult {
  reply: string;
  filters: ParsedSearchFilters;
  anime: AnimeSummary[];
  source: string;
}

export async function parseNaturalLanguageSearch(query: string): Promise<ParsedSearchFilters> {
  const ai = getAiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured in server secrets.');
  }

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: `Convert this anime discovery request into structured AniList search filters.
User request: "${query}"`,
    config: {
      systemInstruction:
        'You convert natural language anime queries into structured search parameters. Use standard AniList genres (Action, Adventure, Comedy, Drama, Fantasy, Horror, Mecha, Mystery, Psychological, Romance, Sci-Fi, Slice of Life, Sports, Supernatural, Thriller) or "ALL". Format must be TV, MOVIE, OVA, ONA, SPECIAL, or ALL. Category must be trending, popular, top_rated, latest, upcoming, airing, classic, hidden_gems, seasonal, or all.',
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          search: { type: Type.STRING, description: 'Short keyword or title query if specified, else empty string.' },
          genre: { type: Type.STRING, description: 'Primary genre from standard AniList genres, or ALL.' },
          year: { type: Type.STRING, description: '4-digit release year if specifically asked, else ALL.' },
          format: { type: Type.STRING, description: 'TV, MOVIE, OVA, ONA, SPECIAL, or ALL.' },
          category: {
            type: Type.STRING,
            description: 'trending, popular, top_rated, latest, upcoming, airing, classic, hidden_gems, seasonal, or all',
          },
          reasoning: { type: Type.STRING, description: 'Brief 1-sentence explanation of the filter mapping.' },
        },
        required: ['search', 'genre', 'year', 'format', 'category', 'reasoning'],
      },
    },
  });

  const parsed = JSON.parse((response.text ?? '{}').trim()) as Partial<ParsedSearchFilters>;
  return {
    search: parsed.search || '',
    genre: parsed.genre || 'ALL',
    year: parsed.year || 'ALL',
    format: parsed.format || 'ALL',
    category: parsed.category || 'popular',
    reasoning: parsed.reasoning || 'Mapped query to live anime discovery filters.',
  };
}

export async function generateGroundedRecommendations(params: {
  message: string;
  history?: Array<{ role: 'user' | 'assistant'; text: string }>;
  favoriteGenres?: string[];
  favoriteTitles?: string[];
}): Promise<AiRecommendationResult> {
  const ai = getAiClient();
  if (!ai) {
    throw new Error('GEMINI_API_KEY is not configured in server secrets. Configure it in Settings > Secrets.');
  }

  const parsed = await parseNaturalLanguageSearch(
    `${params.message}${
      params.favoriteGenres?.length ? ` (User enjoys genres: ${params.favoriteGenres.join(', ')})` : ''
    }`
  );

  const discovery = await discoverAnime({
    search: parsed.search || undefined,
    genre: parsed.genre !== 'ALL' ? parsed.genre : undefined,
    year: parsed.year !== 'ALL' ? parsed.year : undefined,
    format: parsed.format !== 'ALL' ? parsed.format : undefined,
    category: parsed.category !== 'all' ? parsed.category : 'popular',
    perPage: 8,
    page: 1,
  });

  let candidates = discovery.items;
  if (candidates.length === 0 && parsed.search) {
    const fallbackDiscovery = await discoverAnime({
      genre: parsed.genre !== 'ALL' ? parsed.genre : undefined,
      category: 'popular',
      perPage: 8,
      page: 1,
    });
    candidates = fallbackDiscovery.items;
  }

  const groundedContext = candidates.map((a) => ({
    id: a.id,
    title: a.displayTitle,
    nativeTitle: a.title.native,
    year: a.seasonYear,
    format: a.format,
    score: a.averageScore ? `${(a.averageScore / 10).toFixed(1)}/10` : 'N/A',
    genres: a.genres.slice(0, 4),
    synopsis: a.synopsis.slice(0, 240),
  }));

  const historyLines = (params.history || [])
    .slice(-4)
    .map((h) => `${h.role === 'user' ? 'User' : 'Assistant'}: ${h.text}`)
    .join('\n');

  const prompt = `${historyLines ? `Recent conversation:\n${historyLines}\n\n` : ''}User question: "${params.message}"
${params.favoriteTitles?.length ? `User's saved favorites: ${params.favoriteTitles.slice(0, 8).join(', ')}\n` : ''}
Verified real anime retrieved from ${discovery.source}:
${JSON.stringify(groundedContext, null, 2)}

Recommend 3 to 5 of the best matching titles strictly from the verified list above. Never invent anime titles not present in the verified list. Mention why each fits the user's request concisely, and keep the response clear, engaging, and under 220 words.`;

  const answer = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: prompt,
    config: {
      systemInstruction:
        'You are the Anime AI Assistant for THE ANIME WORLD. You must ONLY recommend real anime present in the verified database results provided to you. Never hallucinate titles, episodes, or ratings.',
    },
  });

  return {
    reply:
      answer.text?.trim() ||
      'Here are verified matches from the global anime catalog based on your request.',
    filters: parsed,
    anime: candidates.slice(0, 6),
    source: discovery.source,
  };
}
