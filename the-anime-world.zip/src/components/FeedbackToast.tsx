import { createPortal } from 'react-dom';
import { AlertCircle, CheckCircle2, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export function FeedbackToast() {
  const { feedbackToast, dismissFeedbackToast } = useAuth();

  if (!feedbackToast || typeof document === 'undefined') return null;

  const isError = feedbackToast.kind === 'error';

  return createPortal(
    <div
      className="pointer-events-none fixed bottom-20 left-1/2 z-[65] w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 sm:top-20 sm:bottom-auto sm:right-5 sm:left-auto sm:translate-x-0"
      aria-live={isError ? 'assertive' : 'polite'}
    >
      <div
        role={isError ? 'alert' : 'status'}
        className={`pointer-events-auto flex items-start gap-3 rounded-2xl border px-4 py-3 text-xs font-medium shadow-2xl ${
          isError
            ? 'border-red-500/45 bg-red-50 text-red-900 dark:bg-[#230e17] dark:text-red-100'
            : 'border-[#0284C7]/45 dark:border-[#43B8FF]/45 bg-white text-[#141229] dark:bg-[#10101F] dark:text-[#F5F3FF]'
        }`}
      >
        {isError ? (
          <AlertCircle className="h-4 w-4 shrink-0 text-red-600 dark:text-red-400 mt-0.5" />
        ) : (
          <CheckCircle2 className="h-4 w-4 shrink-0 text-[#0284C7] dark:text-[#43B8FF] mt-0.5" />
        )}
        <span className="flex-1 leading-relaxed">{feedbackToast.message}</span>
        <button
          type="button"
          onClick={dismissFeedbackToast}
          aria-label="Dismiss notification"
          className="rounded-md p-0.5 opacity-70 hover:opacity-100"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>,
    document.body
  );
}
