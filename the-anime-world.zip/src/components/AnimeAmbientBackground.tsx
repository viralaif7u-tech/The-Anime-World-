import { useEffect, useRef } from 'react';
import { useTheme } from '../context/ThemeContext';
import { detectSoftwareGl } from './three/webglUtils';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  alpha: number;
  twinkleSpeed: number;
  phase: number;
  kind: 'star' | 'spark' | 'petal';
  rotation: number;
  rotSpeed: number;
  hue: 'violet' | 'cyan' | 'rose' | 'gold';
}

/**
 * Global cinematic anime animated sky & energy environment.
 * Combines GPU-composited parallax clouds, aurora light beams, and a lightweight
 * canvas particle/sakura/starfield layer that adapts smoothly to Dark and Light modes.
 */
export function AnimeAmbientBackground() {
  const { theme } = useTheme();
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const layerSlowRef = useRef<HTMLDivElement | null>(null);
  const layerMidRef = useRef<HTMLDivElement | null>(null);
  const layerFastRef = useRef<HTMLDivElement | null>(null);

  // Passive scroll parallax directly via transform (zero React re-renders on scroll)
  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) return;

    let rafPending = false;
    const updateParallax = () => {
      rafPending = false;
      const sy = window.scrollY || 0;
      if (layerSlowRef.current) {
        layerSlowRef.current.style.transform = `translate3d(0, ${-sy * 0.05}px, 0)`;
      }
      if (layerMidRef.current) {
        layerMidRef.current.style.transform = `translate3d(0, ${-sy * 0.11}px, 0)`;
      }
      if (layerFastRef.current) {
        layerFastRef.current.style.transform = `translate3d(0, ${-sy * 0.18}px, 0)`;
      }
    };

    const onScroll = () => {
      if (!rafPending) {
        rafPending = true;
        requestAnimationFrame(updateParallax);
      }
    };

    updateParallax();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Animated particle starfield, glowing energy sparks & drifting sakura petals
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const isSoftwareGl = detectSoftwareGl();
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const lowSpec = isSoftwareGl || window.innerWidth < 768;
    const count = reducedMotion ? 24 : lowSpec ? 32 : 64;

    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const onResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', onResize, { passive: true });

    const hues: Particle['hue'][] = ['violet', 'cyan', 'rose', 'gold'];
    const particles: Particle[] = Array.from({ length: count }, (_, i) => {
      const kind: Particle['kind'] = i % 5 === 0 ? 'petal' : i % 3 === 0 ? 'spark' : 'star';
      return {
        x: Math.random() * width,
        y: Math.random() * height,
        vx: kind === 'petal' ? 0.25 + Math.random() * 0.35 : (Math.random() - 0.5) * 0.18,
        vy: kind === 'petal' ? 0.22 + Math.random() * 0.35 : -0.08 - Math.random() * 0.22,
        size: kind === 'petal' ? 3.5 + Math.random() * 3.5 : kind === 'spark' ? 1.8 + Math.random() * 2.2 : 1 + Math.random() * 1.6,
        alpha: 0.25 + Math.random() * 0.65,
        twinkleSpeed: 0.015 + Math.random() * 0.03,
        phase: Math.random() * Math.PI * 2,
        kind,
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.025,
        hue: hues[i % hues.length],
      };
    });

    const isDark = theme === 'dark';

    const getColor = (p: Particle, opacity: number) => {
      if (isDark) {
        if (p.hue === 'cyan') return `rgba(67, 184, 255, ${opacity})`;
        if (p.hue === 'rose') return `rgba(244, 156, 214, ${opacity})`;
        if (p.hue === 'gold') return `rgba(216, 198, 255, ${opacity})`;
        return `rgba(155, 92, 255, ${opacity})`;
      }
      if (p.hue === 'cyan') return `rgba(2, 132, 199, ${opacity * 0.68})`;
      if (p.hue === 'rose') return `rgba(236, 118, 175, ${opacity * 0.78})`;
      if (p.hue === 'gold') return `rgba(217, 119, 6, ${opacity * 0.45})`;
      return `rgba(109, 56, 232, ${opacity * 0.65})`;
    };

    const drawFrame = (time: number) => {
      ctx.clearRect(0, 0, width, height);

      for (const p of particles) {
        if (!reducedMotion) {
          p.x += p.vx + Math.sin(time * 0.0008 + p.phase) * (p.kind === 'petal' ? 0.22 : 0.04);
          p.y += p.vy;
          p.rotation += p.rotSpeed;
          p.phase += p.twinkleSpeed;

          if (p.y < -16) p.y = height + 16;
          if (p.y > height + 16) p.y = -16;
          if (p.x < -16) p.x = width + 16;
          if (p.x > width + 16) p.x = -16;
        }

        const twinkle = 0.55 + 0.45 * Math.sin(p.phase);
        const opacity = p.alpha * twinkle;

        if (p.kind === 'petal') {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.fillStyle = isDark
            ? `rgba(235, 168, 226, ${opacity * 0.72})`
            : `rgba(244, 134, 184, ${opacity * 0.85})`;
          ctx.beginPath();
          ctx.ellipse(0, 0, p.size * 1.35, p.size * 0.72, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        } else if (p.kind === 'spark') {
          const glow = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 3.4);
          glow.addColorStop(0, getColor(p, opacity));
          glow.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = glow;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 3.4, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = getColor(p, opacity);
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    };

    if (reducedMotion || isSoftwareGl) {
      drawFrame(0);
      return () => window.removeEventListener('resize', onResize);
    }

    let rafId = 0;
    let lastDraw = 0;
    const minInterval = lowSpec ? 42 : 16;
    const tick = (now: number) => {
      rafId = requestAnimationFrame(tick);
      if (document.hidden || now - lastDraw < minInterval) return;
      lastDraw = now;
      drawFrame(now);
    };
    rafId = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', onResize);
    };
  }, [theme]);

  return (
    <div
      ref={containerRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-0 overflow-hidden select-none transition-colors duration-500"
    >
      {/* Sky gradient base */}
      <div
        className={`absolute inset-0 transition-opacity duration-500 ${
          theme === 'dark'
            ? 'bg-[radial-gradient(ellipse_at_20%_0%,rgba(81,38,168,0.34)_0%,rgba(8,8,18,0.92)_58%,#080812_100%)]'
            : 'bg-[linear-gradient(165deg,#e4ecff_0%,#f1ecff_46%,#fff4fb_100%)]'
        }`}
      />

      {/* Parallax Layer 1: Celestial Aurora & Sun/Moon Halo */}
      <div ref={layerSlowRef} className="absolute -inset-12 will-change-transform">
        <div
          className={`aw-orb-float absolute -top-20 -left-16 h-[460px] w-[460px] rounded-full ${
            theme === 'dark'
              ? 'bg-[radial-gradient(circle,rgba(155,92,255,0.24)_0%,rgba(155,92,255,0.08)_42%,transparent_72%)]'
              : 'bg-[radial-gradient(circle,rgba(109,56,232,0.16)_0%,rgba(109,56,232,0.05)_42%,transparent_72%)]'
          }`}
        />
        <div
          className={`aw-orb-float absolute top-[22%] -right-24 h-[500px] w-[500px] rounded-full [animation-delay:-6s] ${
            theme === 'dark'
              ? 'bg-[radial-gradient(circle,rgba(67,184,255,0.2)_0%,rgba(67,184,255,0.06)_42%,transparent_72%)]'
              : 'bg-[radial-gradient(circle,rgba(56,189,248,0.22)_0%,rgba(56,189,248,0.06)_42%,transparent_72%)]'
          }`}
        />
        {/* Diagonal anime sky light rays */}
        <div
          className={`absolute inset-0 opacity-45 ${
            theme === 'dark'
              ? 'bg-[linear-gradient(125deg,transparent_18%,rgba(155,92,255,0.08)_32%,transparent_48%,rgba(67,184,255,0.07)_64%,transparent_80%)]'
              : 'bg-[linear-gradient(125deg,transparent_15%,rgba(255,255,255,0.65)_30%,transparent_46%,rgba(165,180,252,0.24)_62%,transparent_80%)]'
          }`}
        />
      </div>

      {/* Parallax Layer 2: Volumetric Stylized Anime Clouds */}
      <div ref={layerMidRef} className="absolute -inset-x-16 top-0 h-[125vh] will-change-transform">
        <svg
          viewBox="0 0 1440 380"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="aw-cloud-drift-slow absolute top-[6%] left-0 w-[112%] max-w-none opacity-65"
        >
          <path
            d="M-40 280C55 215 160 198 258 228C322 145 455 128 568 188C645 120 792 128 866 205C948 164 1072 178 1138 234C1222 190 1352 204 1480 272V380H-40V280Z"
            fill={theme === 'dark' ? 'url(#awCloudDark1)' : 'url(#awCloudLight1)'}
          />
          <defs>
            <linearGradient id="awCloudDark1" x1="720" y1="120" x2="720" y2="380" gradientUnits="userSpaceOnUse">
              <stop stopColor="#5126A8" stopOpacity="0.22" />
              <stop offset="1" stopColor="#080812" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="awCloudLight1" x1="720" y1="120" x2="720" y2="380" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FFFFFF" stopOpacity="0.88" />
              <stop offset="1" stopColor="#E4ECFF" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>

        <svg
          viewBox="0 0 1440 360"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="aw-cloud-drift-reverse absolute top-[46%] left-0 w-[114%] max-w-none opacity-55"
        >
          <path
            d="M-60 250C40 190 175 182 260 225C360 150 510 155 605 218C705 148 860 160 950 222C1055 170 1210 178 1315 232C1395 205 1450 218 1500 248V360H-60V250Z"
            fill={theme === 'dark' ? 'url(#awCloudDark2)' : 'url(#awCloudLight2)'}
          />
          <defs>
            <linearGradient id="awCloudDark2" x1="720" y1="145" x2="720" y2="360" gradientUnits="userSpaceOnUse">
              <stop stopColor="#43B8FF" stopOpacity="0.14" />
              <stop offset="1" stopColor="#080812" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="awCloudLight2" x1="720" y1="145" x2="720" y2="360" gradientUnits="userSpaceOnUse">
              <stop stopColor="#FFFFFF" stopOpacity="0.78" />
              <stop offset="1" stopColor="#F3F2FB" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Parallax Layer 3: Subtle Dimensional Magic Ring Silhouette */}
      <div ref={layerFastRef} className="absolute inset-0 will-change-transform flex items-center justify-center">
        <div
          className={`aw-spin-slow h-[680px] w-[680px] rounded-full border border-dashed opacity-20 ${
            theme === 'dark' ? 'border-[#9B5CFF]/40' : 'border-[#6D38E8]/25'
          }`}
        />
      </div>

      {/* Interactive Starfield, Glowing Motes & Sakura Petals Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
    </div>
  );
}
