import { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import {
  Bell,
  Box,
  Compass,
  FileText,
  HelpCircle,
  Home,
  Info,
  LayoutDashboard,
  LogIn,
  LogOut,
  Moon,
  Palette,
  Settings,
  Shield,
  Sparkles,
  Sun,
  User as UserIcon,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { BrandLogo } from './BrandLogo';

interface SidebarMenuProps {
  open: boolean;
  onClose: () => void;
}

export function SidebarMenu({ open, onClose }: SidebarMenuProps) {
  const { user, publicProfile, unreadCount, isAdmin, logout, saveThemePreference } = useAuth();
  const { theme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();

  // Close drawer cleanly on route navigation or Escape key
  useEffect(() => {
    onClose();
  }, [location.pathname, onClose]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const handleLogout = async () => {
    await logout();
    onClose();
    navigate('/');
  };

  const handleToggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    void saveThemePreference(next);
  };

  const primaryLinks = [
    { label: 'Home', to: '/', icon: Home },
    { label: 'My Profile', to: '/profile', icon: UserIcon },
    { label: 'Dashboard', to: '/dashboard', icon: LayoutDashboard },
    { label: 'Account Settings', to: '/settings', icon: Settings },
    {
      label: unreadCount > 0 ? `Notifications (${unreadCount})` : 'Notifications',
      to: '/notifications',
      icon: Bell,
    },
  ];

  const supportAndLegalLinks = [
    { label: 'Help & Support', to: '/faq', icon: HelpCircle },
    { label: 'About Us', to: '/about', icon: Info },
    { label: 'Privacy Policy', to: '/privacy', icon: Shield },
    { label: 'Terms & Conditions', to: '/terms', icon: FileText },
  ];

  const exploreLinks = [
    { label: 'Explore Catalog', to: '/explore', icon: Compass },
    { label: '3D Anime World', to: '/3d-world', icon: Box },
    { label: 'Anime AI Assistant', to: '/ai-assistant', icon: Sparkles },
  ];

  const drawerContent = (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[60] flex justify-end" role="dialog" aria-modal="true" aria-label="Navigation sidebar menu">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#080812]/65 backdrop-blur-xs"
          />

          {/* Animated Drawer */}
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 320, damping: 32 }}
            className="relative z-10 flex h-full w-[min(340px,88vw)] flex-col border-l border-[var(--aw-border)] bg-white dark:bg-[#0B0B19] text-[#141229] dark:text-[#F5F3FF] shadow-2xl"
          >
            {/* Sidebar Header */}
            <div className="flex items-center justify-between border-b border-[var(--aw-border)] px-5 py-4">
              <BrandLogo />
              <button
                type="button"
                onClick={onClose}
                aria-label="Close sidebar menu"
                className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* User Card */}
            <div className="border-b border-[var(--aw-border)] px-5 py-4">
              {user ? (
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-[#6D38E8]/40 dark:border-[#9B5CFF]/40 bg-[var(--aw-surface-elevated)]">
                    {publicProfile?.avatarUrl || user.photoURL ? (
                      <img
                        src={publicProfile?.avatarUrl || user.photoURL || ''}
                        alt={publicProfile?.displayName || 'Avatar'}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <UserIcon className="h-5 w-5 text-[#6D38E8] dark:text-[#9B5CFF]" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-display text-sm font-bold text-[#141229] dark:text-[#F5F3FF]">
                      {publicProfile?.displayName || user.displayName || 'Anime Explorer'}
                    </div>
                    <div className="truncate text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                      {user.email || `@${publicProfile?.username || 'traveler'}`}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                    Sign in to sync your anime collections, 4K favorites &amp; AI profile.
                  </p>
                  <div className="flex gap-2">
                    <Link
                      to="/login"
                      className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-3 py-2 text-xs font-semibold text-white dark:text-[#080812]"
                    >
                      <LogIn className="h-3.5 w-3.5" /> Sign In
                    </Link>
                    <Link
                      to="/register"
                      className="flex-1 inline-flex items-center justify-center rounded-xl border border-[var(--aw-border-strong)] px-3 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF]"
                    >
                      Register
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {/* Scrollable Links */}
            <nav aria-label="Sidebar navigation" className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
              {/* Account & Workspace Links */}
              <div className="space-y-1">
                {primaryLinks.map((item) => {
                  const Icon = item.icon;
                  const active = location.pathname === item.to;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors ${
                        active
                          ? 'bg-[#6D38E8]/12 dark:bg-[#9B5CFF]/18 text-[#6D38E8] dark:text-[#F5F3FF]'
                          : 'text-[#524E6B] dark:text-[#AAA7BC] hover:bg-[var(--aw-surface-elevated)] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
                      }`}
                    >
                      <Icon className="h-4 w-4 shrink-0 text-[#6D38E8] dark:text-[#43B8FF]" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}

                {isAdmin && (
                  <Link
                    to="/admin"
                    className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors ${
                      location.pathname === '/admin'
                        ? 'bg-[#0284C7]/15 dark:bg-[#43B8FF]/20 text-[#0284C7] dark:text-[#43B8FF]'
                        : 'text-[#0284C7] dark:text-[#43B8FF] hover:bg-[var(--aw-surface-elevated)]'
                    }`}
                  >
                    <Shield className="h-4 w-4 shrink-0" />
                    <span>Admin Console</span>
                  </Link>
                )}
              </div>

              {/* Appearance Switcher */}
              <div className="rounded-2xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/75 p-3.5">
                <div className="flex items-center justify-between gap-2">
                  <Link to="/settings#appearance" className="flex items-center gap-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:underline">
                    <Palette className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
                    <span>Appearance</span>
                  </Link>
                  <span className="text-[11px] font-medium capitalize text-[#524E6B] dark:text-[#AAA7BC]">
                    {theme} Mode
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleToggleTheme}
                  className="mt-2.5 flex w-full items-center justify-between rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] transition-colors"
                >
                  <span className="inline-flex items-center gap-2">
                    {theme === 'dark' ? (
                      <>
                        <Moon className="h-3.5 w-3.5 text-[#9B5CFF]" />
                        Switch to Light Mode
                      </>
                    ) : (
                      <>
                        <Sun className="h-3.5 w-3.5 text-amber-500" />
                        Switch to Dark Mode
                      </>
                    )}
                  </span>
                  <span
                    className={`inline-flex h-5 w-9 items-center rounded-full p-0.5 transition-colors ${
                      theme === 'dark' ? 'bg-[#9B5CFF] justify-end' : 'bg-[#6D38E8]/30 justify-start'
                    }`}
                  >
                    <span className="h-4 w-4 rounded-full bg-white shadow-xs" />
                  </span>
                </button>
              </div>

              {/* Quick Discovery Links */}
              <div className="space-y-1 border-t border-[var(--aw-border)] pt-4">
                <div className="px-3.5 pb-1 text-[11px] font-semibold uppercase tracking-wider text-[#524E6B] dark:text-[#AAA7BC]">
                  Universe Portals
                </div>
                {exploreLinks.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      className="flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] hover:bg-[var(--aw-surface-elevated)] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors"
                    >
                      <Icon className="h-4 w-4 shrink-0 text-[#0284C7] dark:text-[#43B8FF]" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </div>

              {/* Support & Legal Links */}
              <div className="space-y-1 border-t border-[var(--aw-border)] pt-4">
                <div className="px-3.5 pb-1 text-[11px] font-semibold uppercase tracking-wider text-[#524E6B] dark:text-[#AAA7BC]">
                  Support &amp; Legal
                </div>
                {supportAndLegalLinks.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      className="flex items-center gap-3 rounded-xl px-3.5 py-2 text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] hover:bg-[var(--aw-surface-elevated)] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors"
                    >
                      <Icon className="h-4 w-4 shrink-0" />
                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            </nav>

            {/* Footer Action (Logout / Sign In) */}
            <div className="border-t border-[var(--aw-border)] p-4">
              {user ? (
                <button
                  type="button"
                  onClick={() => void handleLogout()}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/35 bg-red-50 dark:bg-red-950/30 px-4 py-2.5 text-xs font-semibold text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-red-950/50 transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  Logout
                </button>
              ) : (
                <Link
                  to="/login"
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-4 py-2.5 text-xs font-bold text-white dark:text-[#080812]"
                >
                  <LogIn className="h-4 w-4" />
                  Sign In to Your Account
                </Link>
              )}
            </div>
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );

  if (typeof document === 'undefined') return null;
  return createPortal(drawerContent, document.body);
}
