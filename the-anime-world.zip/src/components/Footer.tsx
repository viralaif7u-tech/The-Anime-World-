import { Link } from 'react-router-dom';
import { BrandLogo } from './BrandLogo';
import { useAuth } from '../context/AuthContext';

export function Footer() {
  const { user, isAdmin } = useAuth();

  return (
    <footer className="relative z-10 border-t border-[var(--aw-border)] bg-white/95 dark:bg-[#080812]/92 backdrop-blur-md text-[#524E6B] dark:text-[#AAA7BC]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="inline-block">
              <BrandLogo />
            </Link>
            <p className="max-w-sm text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
              ENTER THE WORLD OF ANIME. EXPERIENCE THE IMPOSSIBLE. Global 3D animated discovery platform powered by live AniList &amp; Jikan metadata, interactive Three.js showcases, and Gemini AI.
            </p>
            <p className="text-xs text-[#524E6B]/80 dark:text-[#AAA7BC]/75">
              Anime &amp; character metadata sourced via AniList GraphQL API and Jikan API. Only original, public-domain, and authorized media are displayed.
            </p>
          </div>

          <div>
            <h3 className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">Discovery</h3>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link to="/explore" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Explore Catalog</Link></li>
              <li><Link to="/trending" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Trending Anime</Link></li>
              <li><Link to="/popular" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Popular Anime</Link></li>
              <li><Link to="/upcoming" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Upcoming Releases</Link></li>
              <li><Link to="/seasonal" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Seasonal Anime</Link></li>
              <li><Link to="/characters" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Characters Directory</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">3D &amp; Galleries</h3>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link to="/3d-world" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">3D Anime World</Link></li>
              <li><Link to="/wallpapers" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">4K Wallpapers</Link></li>
              <li><Link to="/animations" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Animations &amp; Trailers</Link></li>
              <li><Link to="/workspace" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Gmail &amp; Google Drive</Link></li>
              <li><Link to="/ai-assistant" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Anime AI Assistant</Link></li>
              <li><Link to="/community" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Community Creators</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">Account &amp; Support</h3>
            <ul className="mt-3 space-y-2 text-sm">
              {user ? (
                <>
                  <li><Link to="/dashboard" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">User Dashboard</Link></li>
                  <li><Link to="/profile" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">My Profile</Link></li>
                  <li><Link to="/downloads" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">My Downloads</Link></li>
                  <li><Link to="/favorites" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">My Favorites</Link></li>
                  <li><Link to="/settings" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Account Settings</Link></li>
                  <li><Link to="/privacy-settings" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Privacy Settings</Link></li>
                  <li><Link to="/collections" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">My Collections</Link></li>
                  <li><Link to="/notifications" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Notifications</Link></li>
                  {isAdmin && (
                    <li><Link to="/admin" className="text-[#0284C7] dark:text-[#43B8FF] hover:underline">Admin Dashboard</Link></li>
                  )}
                </>
              ) : (
                <>
                  <li><Link to="/login" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Sign In</Link></li>
                  <li><Link to="/register" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Create Account</Link></li>
                  <li><Link to="/forgot-password" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Reset Password</Link></li>
                </>
              )}
              <li><Link to="/feedback" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Feedback</Link></li>
              <li><Link to="/contact" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Contact Us</Link></li>
              <li><Link to="/about" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">About Us</Link></li>
              <li><Link to="/faq" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">FAQ</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-[var(--aw-border)] pt-6 text-xs sm:flex-row sm:items-center">
          <p>© {new Date().getFullYear()} THE ANIME WORLD. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-5">
            <Link to="/privacy" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Terms &amp; Conditions</Link>
            <Link to="/copyright" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Copyright &amp; DMCA</Link>
            <a href="/sitemap.xml" className="hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
