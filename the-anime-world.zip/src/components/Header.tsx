import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Download,
  Heart,
  LogOut,
  Moon,
  Settings,
  Shield,
  Sun,
  User as UserIcon,
} from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

const PRIMARY_NAV = [
  { label: 'Explore', to: '/explore' },
  { label: 'Characters', to: '/characters' },
  { label: '3D World', to: '/3d-world' },
  { label: 'Animations', to: '/animations' },
  { label: 'Wallpapers', to: '/wallpapers' },
  { label: 'Workspace', to: '/workspace' },
];

export function Header() {
  const { user, publicProfile, saveThemePreference, logout, showFeedback } = useAuth();
  const { theme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();

  const [menuOpen, setMenuOpen] = useState(false);
  const [avatarBroken, setAvatarBroken] = useState(false);
  const [scrollPct, setScrollPct] = useState(0);
  const menuContainerRef = useRef<HTMLDivElement | null>(null);

  const avatarSrc = !avatarBroken ? (publicProfile?.avatarUrl || user?.photoURL || '') : '';

  useEffect(() => {
    setAvatarBroken(false);
  }, [publicProfile?.avatarUrl, user?.photoURL, user?.uid]);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (!menuOpen) return;
    const handleOutsideClick = (event: MouseEvent) => {
      if (menuContainerRef.current && !menuContainerRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [menuOpen]);

  useEffect(() => {
    const onScroll = () => {
      const doc = document.documentElement;
      const total = doc.scrollHeight - doc.clientHeight;
      setScrollPct(total > 0 ? Math.min(100, Math.round((window.scrollY / total) * 100)) : 0);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleLogout = async () => {
    setMenuOpen(false);
    try {
      await logout();
      showFeedback('success', 'Signed out securely.');
      navigate('/');
    } catch {
      showFeedback('error', 'Unable to sign out. Please try again.');
    }
  };

  return (
    <header className="sticky top-0 z-40 border-b border-[var(--aw-border)] bg-white/95 dark:bg-[#080812]/90 backdrop-blur-md">
      <div
        className="h-[2px] bg-gradient-to-r from-[#5126A8] via-[#9B5CFF] to-[#43B8FF] transition-[width] duration-150"
        style={{ width: `${scrollPct}%` }}
        aria-hidden="true"
      />
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-2 sm:gap-8 px-3 sm:px-6 lg:px-8">
        {/* Zone 1: Brand wordmark */}
        <Link
          to="/"
          className="whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#43B8FF] rounded-md"
        >
          <BrandLogo />
        </Link>

        {/* Zone 2: Concise single-line desktop nav links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-6 lg:gap-7">
          {PRIMARY_NAV.map((item) => {
            const active = location.pathname === item.to || location.pathname.startsWith(`${item.to}/`);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`relative py-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors ${
                  active
                    ? 'text-[#141229] dark:text-[#F5F3FF]'
                    : 'text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
                }`}
              >
                {item.label}
                {active && (
                  <span className="absolute inset-x-0 -bottom-0.5 h-0.5 bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF]" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Zone 3: Theme Toggle + Circular Profile Avatar (Signed In) OR Login / Sign Up (Signed Out) */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => void saveThemePreference(theme === 'dark' ? 'light' : 'dark')}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            className="inline-flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-full border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors"
          >
            {theme === 'dark' ? <Sun className="h-4 w-4 text-amber-300" /> : <Moon className="h-4 w-4 text-[#6D38E8]" />}
          </button>

          {user ? (
            <div ref={menuContainerRef} className="relative">
              <button
                type="button"
                onClick={() => setMenuOpen((prev) => !prev)}
                aria-label="Open account menu"
                aria-expanded={menuOpen}
                aria-haspopup="menu"
                data-testid="header-profile-avatar-btn"
                className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full border-2 border-[#6D38E8]/60 dark:border-[#9B5CFF]/70 bg-gradient-to-br from-[#6D38E8]/15 to-[#0284C7]/20 dark:from-[#9B5CFF]/25 dark:to-[#43B8FF]/25 text-[#6D38E8] dark:text-[#F5F3FF] shadow-sm hover:border-[#0284C7] dark:hover:border-[#43B8FF] focus-visible:outline-2 focus-visible:outline-[#43B8FF] transition-colors"
              >
                {avatarSrc ? (
                  <img
                    src={avatarSrc}
                    alt="Profile avatar"
                    referrerPolicy="no-referrer"
                    onError={() => setAvatarBroken(true)}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <UserIcon className="h-5 w-5" />
                )}
              </button>

              {menuOpen && (
                <div
                  role="menu"
                  aria-label="Account menu"
                  data-testid="header-account-menu"
                  className="absolute right-0 mt-2.5 w-56 overflow-hidden rounded-2xl border border-[var(--aw-border-strong)] bg-white/98 dark:bg-[#10101F]/98 p-1.5 shadow-2xl backdrop-blur-xl"
                >
                  <Link
                    to="/profile"
                    role="menuitem"
                    onClick={() => setMenuOpen(false)}
                    className="flex min-h-[42px] items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:bg-[#6D38E8]/10 dark:hover:bg-[#9B5CFF]/15 transition-colors"
                  >
                    <UserIcon className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
                    <span>My Profile</span>
                  </Link>
                  <Link
                    to="/downloads"
                    role="menuitem"
                    onClick={() => setMenuOpen(false)}
                    className="flex min-h-[42px] items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:bg-[#6D38E8]/10 dark:hover:bg-[#9B5CFF]/15 transition-colors"
                  >
                    <Download className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
                    <span>My Downloads</span>
                  </Link>
                  <Link
                    to="/favorites"
                    role="menuitem"
                    onClick={() => setMenuOpen(false)}
                    className="flex min-h-[42px] items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:bg-[#6D38E8]/10 dark:hover:bg-[#9B5CFF]/15 transition-colors"
                  >
                    <Heart className="h-4 w-4 text-rose-500" />
                    <span>My Favorites</span>
                  </Link>
                  <Link
                    to="/settings"
                    role="menuitem"
                    onClick={() => setMenuOpen(false)}
                    className="flex min-h-[42px] items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:bg-[#6D38E8]/10 dark:hover:bg-[#9B5CFF]/15 transition-colors"
                  >
                    <Settings className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
                    <span>Account Settings</span>
                  </Link>
                  <Link
                    to="/privacy-settings"
                    role="menuitem"
                    onClick={() => setMenuOpen(false)}
                    className="flex min-h-[42px] items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:bg-[#6D38E8]/10 dark:hover:bg-[#9B5CFF]/15 transition-colors"
                  >
                    <Shield className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
                    <span>Privacy Settings</span>
                  </Link>

                  <div className="my-1 border-t border-[var(--aw-border)]" />

                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => void handleLogout()}
                    className="flex min-h-[42px] w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-500/10 transition-colors"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Logout</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Link
                to="/login"
                className="inline-flex min-h-[38px] sm:min-h-[40px] items-center rounded-xl border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-2.5 sm:px-3.5 py-1.5 sm:py-2 text-[11px] sm:text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] transition-colors whitespace-nowrap shrink-0"
              >
                Login
              </Link>
              <Link
                to="/register"
                className="inline-flex min-h-[38px] sm:min-h-[40px] items-center rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-2.5 sm:px-3.5 py-1.5 sm:py-2 text-[11px] sm:text-xs font-semibold text-white dark:text-[#080812] hover:opacity-95 transition-opacity whitespace-nowrap shrink-0"
              >
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
