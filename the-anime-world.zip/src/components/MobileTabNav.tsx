import { Link, useLocation } from 'react-router-dom';
import { Box, Compass, Download, Film, Image } from 'lucide-react';

const MOBILE_TABS = [
  { label: 'Explore', to: '/explore', icon: Compass },
  { label: '3D World', to: '/3d-world', icon: Box },
  { label: 'Videos', to: '/animations', icon: Film },
  { label: 'Walls', to: '/wallpapers', icon: Image },
  { label: 'Downloads', to: '/downloads', icon: Download },
];

export function MobileTabNav() {
  const location = useLocation();

  return (
    <nav
      aria-label="Mobile quick navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-14 border-t border-[var(--aw-border)] bg-white/95 dark:bg-[#080812]/95 backdrop-blur-md"
    >
      <div className="grid h-full grid-cols-5 items-center">
        {MOBILE_TABS.map((tab) => {
          const Icon = tab.icon;
          const active = location.pathname === tab.to || location.pathname.startsWith(`${tab.to}/`);
          return (
            <Link
              key={tab.to}
              to={tab.to}
              className={`flex h-full flex-col items-center justify-center gap-0.5 text-[10px] font-semibold tracking-tight transition-colors ${
                active
                  ? 'text-[#6D38E8] dark:text-[#43B8FF]'
                  : 'text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
              }`}
            >
              <Icon className="h-[19px] w-[19px]" />
              <span>{tab.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
