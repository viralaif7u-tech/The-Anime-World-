import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bot, Send, Trash2, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import type { AnimeSummary } from '../types/anime';
import { buildAnimeUrl } from '../lib/validation';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  anime?: AnimeSummary[];
  error?: boolean;
}

const SUGGESTED_QUESTIONS = [
  'Recommend anime like Attack on Titan',
  'Find action fantasy anime released after 2020',
  'Suggest emotional sci-fi or slice of life anime',
  'Find underrated hidden gem anime',
];

export function FloatingAiAssistant() {
  const { privateUser, favorites } = useAuth();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: 'Ask me for anime recommendations, similar titles, or natural-language search filters. Every recommendation is grounded directly in the live AniList database.',
    },
  ]);

  const sendMessage = async (textOverride?: string) => {
    const query = (textOverride ?? input).trim();
    if (!query || loading) return;

    const userMsg: ChatMessage = { id: `u_${Date.now()}`, role: 'user', text: query };
    setMessages((prev) => [...prev, userMsg]);
    if (!textOverride) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.slice(-4).map((m) => ({ role: m.role, text: m.text })),
          favoriteGenres: privateUser?.favoriteGenres || [],
          favoriteTitles: favorites.filter((f) => f.itemType === 'anime').map((f) => f.title),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Could not reach Anime AI Assistant.');
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `a_${Date.now()}`,
          role: 'assistant',
          text: data.reply,
          anime: Array.isArray(data.anime) ? data.anime : [],
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `e_${Date.now()}`,
          role: 'assistant',
          text: err instanceof Error ? err.message : 'Request failed.',
          error: true,
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? 'Close Anime AI Assistant' : 'Open Anime AI Assistant'}
        className="fixed right-3 bottom-[4.25rem] md:right-5 md:bottom-5 z-40 inline-flex h-11 md:h-12 items-center gap-2 rounded-xl border border-[#6D38E8]/50 dark:border-[#9B5CFF]/50 bg-white dark:bg-[#10101F] px-3 md:px-4 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] shadow-lg hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors"
      >
        <Bot className="h-5 w-5 text-[#0284C7] dark:text-[#43B8FF]" />
        <span className="hidden sm:inline whitespace-nowrap">Anime AI</span>
      </button>

      {open && (
        <section
          aria-label="Anime AI Assistant chat"
          className="fixed right-3 bottom-32 md:right-4 md:bottom-20 z-50 flex h-[520px] max-h-[70vh] w-[min(410px,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-2xl border border-[#6D38E8]/35 dark:border-[#9B5CFF]/35 bg-white dark:bg-[#080812] shadow-2xl"
        >
          <div className="flex items-center justify-between border-b border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#10101F] px-4 py-3">
            <div className="flex items-center gap-2.5">
              <Bot className="h-5 w-5 text-[#0284C7] dark:text-[#43B8FF]" />
              <div>
                <h2 className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">Anime AI Assistant</h2>
                <p className="text-[11px] text-[#524E6B] dark:text-[#AAA7BC]">Grounded in real AniList metadata</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() =>
                  setMessages([
                    {
                      id: 'welcome',
                      role: 'assistant',
                      text: 'Chat cleared. Ask for any anime recommendation or natural-language search!',
                    },
                  ])
                }
                aria-label="Clear chat history"
                className="rounded-lg p-1.5 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]"
              >
                <Trash2 className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close assistant"
                className="rounded-lg p-1.5 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[88%] rounded-xl px-3.5 py-2.5 text-sm leading-relaxed whitespace-pre-line ${
                    m.role === 'user'
                      ? 'bg-[#6D38E8] dark:bg-[#5126A8] text-white dark:text-[#F5F3FF]'
                      : m.error
                      ? 'border border-red-500/40 bg-red-50 dark:bg-red-950/30 text-red-800 dark:text-red-200'
                      : 'border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#10101F] text-[#141229] dark:text-[#F5F3FF]'
                  }`}
                >
                  {m.text}
                </div>

                {m.anime && m.anime.length > 0 && (
                  <div className="mt-2 grid w-full grid-cols-1 gap-1.5">
                    {m.anime.slice(0, 4).map((a) => (
                      <Link
                        key={a.id}
                        to={buildAnimeUrl(a.id, a.displayTitle)}
                        onClick={() => setOpen(false)}
                        className="flex items-center gap-2.5 rounded-lg border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#10101F] p-2 hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors"
                      >
                        {a.coverImage.large && (
                          <img
                            src={a.coverImage.large}
                            alt={a.displayTitle}
                            referrerPolicy="no-referrer"
                            className="h-11 w-8 rounded object-cover shrink-0"
                          />
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-xs font-semibold text-[#141229] dark:text-[#F5F3FF]">{a.displayTitle}</div>
                          <div className="text-[11px] text-[#524E6B] dark:text-[#AAA7BC]">
                            {[a.format, a.seasonYear, a.averageScore ? `${(a.averageScore / 10).toFixed(1)}/10` : null]
                              .filter(Boolean)
                              .join(' · ')}
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="inline-flex items-center gap-2 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#10101F] px-3.5 py-2 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                Searching database and preparing recommendations...
              </div>
            )}
          </div>

          {messages.length <= 2 && (
            <div className="flex flex-wrap gap-1.5 border-t border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/70 dark:bg-[#0d0d1a] px-3 py-2">
              {SUGGESTED_QUESTIONS.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => void sendMessage(q)}
                  className="rounded-md border border-[var(--aw-border)] bg-white dark:bg-[#10101F] px-2.5 py-1 text-[11px] text-[#524E6B] dark:text-[#AAA7BC] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors text-left"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void sendMessage();
            }}
            className="flex items-center gap-2 border-t border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#10101F] p-3"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask for anime recommendations..."
              aria-label="Ask Anime AI Assistant"
              className="flex-1 rounded-lg border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF] placeholder:text-[#524E6B]/60 dark:placeholder:text-[#AAA7BC]/60 focus:border-[#0284C7] dark:focus:border-[#43B8FF] focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              aria-label="Send message"
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812] disabled:opacity-40 hover:opacity-90 transition-colors"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </section>
      )}
    </>
  );
}
