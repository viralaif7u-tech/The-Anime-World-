import { createPortal } from 'react-dom';
import { AlertTriangle, CheckCircle2, Loader2, X } from 'lucide-react';

export interface WorkspaceConfirmRequest {
  title: string;
  description: string;
  details?: string[];
  confirmLabel: string;
  tone?: 'danger' | 'primary';
  onConfirm: () => Promise<void>;
}

interface WorkspaceConfirmModalProps {
  request: WorkspaceConfirmRequest | null;
  busy?: boolean;
  onCancel: () => void;
  onProceed: () => void;
}

export function WorkspaceConfirmModal({
  request,
  busy = false,
  onCancel,
  onProceed,
}: WorkspaceConfirmModalProps) {
  if (!request || typeof document === 'undefined') return null;

  const isDanger = request.tone === 'danger';

  return createPortal(
    <div
      className="fixed inset-0 z-[75] flex items-center justify-center bg-black/65 p-4 backdrop-blur-sm"
      role="presentation"
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="workspace-confirm-title"
        data-testid="workspace-confirm-dialog"
        className="w-full max-w-md rounded-2xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#10101F] p-6 shadow-2xl"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            {isDanger ? (
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-500/15 text-red-600 dark:text-red-400">
                <AlertTriangle className="h-5 w-5" />
              </div>
            ) : (
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#6D38E8]/15 dark:bg-[#9B5CFF]/20 text-[#6D38E8] dark:text-[#9B5CFF]">
                <CheckCircle2 className="h-5 w-5" />
              </div>
            )}
            <h2
              id="workspace-confirm-title"
              className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]"
            >
              {request.title}
            </h2>
          </div>

          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            aria-label="Cancel confirmation"
            className="rounded-lg p-1.5 text-[#524E6B] dark:text-[#AAA7BC] hover:bg-black/5 dark:hover:bg-white/10"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <p className="mt-3 text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
          {request.description}
        </p>

        {request.details && request.details.length > 0 && (
          <ul className="mt-3 space-y-1.5 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3 text-xs text-[#141229] dark:text-[#F5F3FF]">
            {request.details.map((line, idx) => (
              <li key={idx} className="truncate">
                {line}
              </li>
            ))}
          </ul>
        )}

        <div className="mt-6 flex flex-wrap justify-end gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            className="inline-flex min-h-[44px] items-center rounded-xl border border-[var(--aw-border-strong)] px-4 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onProceed}
            disabled={busy}
            data-testid="workspace-confirm-submit"
            className={`inline-flex min-h-[44px] items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold disabled:opacity-60 ${
              isDanger
                ? 'bg-red-600 text-white hover:bg-red-700'
                : 'bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] text-white dark:text-[#080812]'
            }`}
          >
            {busy && <Loader2 className="h-4 w-4 animate-spin" />}
            <span>{request.confirmLabel}</span>
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
}
