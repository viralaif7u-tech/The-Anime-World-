import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import {
  AlertCircle,
  CheckCircle2,
  Eye,
  EyeOff,
  KeyRound,
  Loader2,
  Mail,
  Sparkles,
  Upload,
  UserPlus,
} from 'lucide-react';
import { useAuth, type OAuthProviderKey } from '../context/AuthContext';
import { BrandLogo } from './BrandLogo';
import { validateRegistrationInput } from '../lib/validation';
import { resizeAvatarToDataUrl } from '../lib/imageUpload';

export type AuthMode = 'login' | 'register' | 'email-link' | 'forgot';

function GoogleIcon() {
  return (
    <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z" />
      <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z" />
      <path fill="#FBBC05" d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z" />
      <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z" />
    </svg>
  );
}

function FacebookIcon() {
  return (
    <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" fill="#1877F2" aria-hidden="true">
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073Z" />
    </svg>
  );
}

function AppleIcon() {
  return (
    <svg className="h-4 w-4 shrink-0 fill-current" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M16.365 1.43c0 1.14-.493 2.27-1.177 3.08-.744.9-1.99 1.57-2.987 1.57-.12 0-.23-.02-.3-.03-.01-.06-.04-.22-.04-.39 0-1.15.572-2.27 1.206-2.98.804-.94 2.142-1.64 3.248-1.68.03.13.05.28.05.43Zm4.565 15.71c-.03.07-.463 1.58-1.518 3.12-.945 1.34-1.94 2.71-3.43 2.71-1.517 0-1.9-.88-3.63-.88-1.698 0-2.302.91-3.67.91-1.377 0-2.332-1.26-3.428-2.8-1.287-1.82-2.323-4.63-2.323-7.28 0-4.28 2.797-6.55 5.552-6.55 1.448 0 2.675.95 3.6.95.865 0 2.222-1.01 3.902-1.01.613 0 2.886.06 4.374 2.19-.13.09-2.383 1.37-2.383 4.19 0 3.26 2.854 4.42 2.955 4.45Z" />
    </svg>
  );
}

function MicrosoftIcon() {
  return (
    <svg className="h-4 w-4 shrink-0" viewBox="0 0 23 23" aria-hidden="true">
      <path fill="#f35325" d="M1 1h10v10H1z" />
      <path fill="#81bc06" d="M12 1h10v10H12z" />
      <path fill="#05a6f0" d="M1 12h10v10H1z" />
      <path fill="#ffba08" d="M12 12h10v10H12z" />
    </svg>
  );
}

function GitHubIcon() {
  return (
    <svg className="h-4 w-4 shrink-0 fill-current" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
    </svg>
  );
}

const PROVIDER_BUTTONS: Array<{
  id: OAuthProviderKey;
  label: string;
  renderIcon: () => React.ReactNode;
}> = [
  { id: 'google', label: 'Continue with Google', renderIcon: GoogleIcon },
  { id: 'facebook', label: 'Continue with Facebook', renderIcon: FacebookIcon },
  { id: 'apple', label: 'Continue with Apple', renderIcon: AppleIcon },
  { id: 'microsoft', label: 'Continue with Microsoft', renderIcon: MicrosoftIcon },
  { id: 'github', label: 'Continue with GitHub', renderIcon: GitHubIcon },
];

export function mapAuthError(err: unknown, providerLabel?: string): string {
  const msg = err instanceof Error ? err.message : String(err);
  if (msg.includes('auth/operation-not-allowed')) {
    return `${providerLabel || 'This sign-in provider'} is not enabled yet in Firebase Console. Enable it under Firebase Authentication → Sign-in method (and add OAuth App ID / Secret for external providers), or continue with Google.`;
  }
  if (msg.includes('auth/unauthorized-domain')) {
    return `This domain is not yet authorized in Firebase Console → Authentication → Settings → Authorized domains.`;
  }
  if (msg.includes('auth/account-exists-with-different-credential')) {
    return 'An account already exists with this email using a different sign-in provider. Sign in using your original method first.';
  }
  if (msg.includes('auth/popup-blocked')) {
    return 'Browser popup was blocked. Please allow popups for this site and try again.';
  }
  if (msg.includes('auth/popup-closed-by-user')) {
    return 'Sign-in window was closed before authentication completed.';
  }
  if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password')) {
    return 'Invalid email address or password.';
  }
  if (msg.includes('auth/email-already-in-use')) {
    return 'An account with this email already exists. Try signing in instead.';
  }
  if (msg.includes('auth/weak-password')) {
    return 'Password should be at least 8 characters with letters and numbers.';
  }
  if (msg.includes('auth/too-many-requests')) {
    return 'Too many attempts. Please wait a moment before trying again.';
  }
  return msg;
}

export function AuthExperience({
  initialMode = 'login',
  onSuccess,
  onGuestContinue,
  showGuestButton = false,
  titleOverride,
}: {
  initialMode?: AuthMode;
  onSuccess?: () => void;
  onGuestContinue?: () => void;
  showGuestButton?: boolean;
  titleOverride?: string;
}) {
  const {
    signInWithOAuthProvider,
    sendEmailSignInLink,
    completeEmailLinkSignIn,
    hasPendingEmailLink,
    loginWithEmail,
    registerWithEmail,
    requestPasswordReset,
  } = useAuth();

  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [busyProvider, setBusyProvider] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Login state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showLoginPass, setShowLoginPass] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Register state
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirm, setRegConfirm] = useState('');
  const [showRegPass, setShowRegPass] = useState(false);
  const [showRegConfirm, setShowRegConfirm] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [regErrors, setRegErrors] = useState<Record<string, string>>({});

  // Email link / forgot password state
  const [magicEmail, setMagicEmail] = useState('');
  const [needsEmailConfirmForLink, setNeedsEmailConfirmForLink] = useState(false);

  useEffect(() => {
    setMode(initialMode);
  }, [initialMode]);

  // Complete passwordless email link login automatically if URL carries a Firebase email link
  useEffect(() => {
    if (!hasPendingEmailLink()) return;
    setMode('email-link');
    completeEmailLinkSignIn()
      .then((ok) => {
        if (ok) {
          setNotice('Email link verified! Welcome to THE ANIME WORLD.');
          onSuccess?.();
        }
      })
      .catch((err) => {
        setNeedsEmailConfirmForLink(true);
        setError(mapAuthError(err, 'Email Link'));
      });
  }, [completeEmailLinkSignIn, hasPendingEmailLink, onSuccess]);

  const switchMode = (next: AuthMode) => {
    setError(null);
    setNotice(null);
    setRegErrors({});
    setMode(next);
  };

  const handleOAuth = async (providerKey: OAuthProviderKey, label: string) => {
    setError(null);
    setNotice(null);
    setBusyProvider(providerKey);
    try {
      await signInWithOAuthProvider(providerKey);
      onSuccess?.();
    } catch (err) {
      setError(mapAuthError(err, label));
    } finally {
      setBusyProvider(null);
    }
  };

  const handleEmailPasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setBusyProvider('password');
    try {
      await loginWithEmail(email, password, rememberMe);
      onSuccess?.();
    } catch (err) {
      setError(mapAuthError(err, 'Email & Password'));
    } finally {
      setBusyProvider(null);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    const check = validateRegistrationInput({
      fullName,
      username,
      email: regEmail,
      password: regPassword,
      confirmPassword: regConfirm,
      acceptTerms,
    });
    setRegErrors(check.errors);
    if (!check.valid) return;

    setBusyProvider('register');
    try {
      await registerWithEmail({
        fullName,
        username,
        email: regEmail,
        password: regPassword,
        avatarUrl: avatarPreview,
      });
      setNotice(
        'Account created! A verification email has been sent to your inbox. Verify your email to unlock cloud favorites, profile updates, and community posting.'
      );
    } catch (err) {
      setError(mapAuthError(err, 'Email Registration'));
    } finally {
      setBusyProvider(null);
    }
  };

  const handleAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);
    try {
      const compressed = await resizeAvatarToDataUrl(file);
      setAvatarPreview(compressed);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to process image.');
    }
  };

  const handleEmailLinkSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setBusyProvider('email-link');
    try {
      if (needsEmailConfirmForLink) {
        await completeEmailLinkSignIn(magicEmail);
        setNotice('Signed in successfully via email verification link!');
        onSuccess?.();
      } else {
        await sendEmailSignInLink(magicEmail);
        setNotice(`Sign-in link dispatched to ${magicEmail.trim()}. Check your inbox and open the link on this device.`);
      }
    } catch (err) {
      setError(mapAuthError(err, 'Passwordless Email Link'));
    } finally {
      setBusyProvider(null);
    }
  };

  const handleForgotSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setBusyProvider('forgot');
    try {
      await requestPasswordReset(magicEmail);
      setNotice('If an account exists for this email, password reset instructions have been sent.');
    } catch (err) {
      setError(mapAuthError(err, 'Password Reset'));
    } finally {
      setBusyProvider(null);
    }
  };

  const loading = busyProvider !== null;

  return (
    <div className="relative overflow-hidden rounded-3xl border border-[var(--aw-border-strong)] bg-white/95 dark:bg-[#10101F]/92 backdrop-blur-md p-6 sm:p-8 shadow-[0_24px_80px_rgba(81,38,168,0.28)]">
      {/* Subtle anime orbital aura accent inside card */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 left-1/2 -translate-x-1/2 h-48 w-96 rounded-full bg-gradient-to-r from-[#9B5CFF]/25 via-[#43B8FF]/20 to-[#5126A8]/25 blur-3xl"
      />

      <div className="relative z-10">
        <div className="flex flex-col items-center text-center">
          <BrandLogo />
          <h1 className="mt-4 font-display text-2xl sm:text-3xl font-extrabold tracking-tight text-[#141229] dark:text-[#F5F3FF]">
            {titleOverride ||
              (mode === 'login'
                ? 'Welcome Back, Traveler'
                : mode === 'register'
                ? 'Join THE ANIME WORLD'
                : mode === 'email-link'
                ? 'Continue with Email'
                : 'Recover Account Access')}
          </h1>
          <p className="mt-1.5 text-xs sm:text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            {mode === 'login'
              ? 'Sign in to sync your anime catalog, 4K wallpapers, 3D models & AI profile.'
              : mode === 'register'
              ? 'Create your personalized identity across anime discovery, 3D worlds, and community.'
              : mode === 'email-link'
              ? 'Receive an instant, secure passwordless sign-in link directly to your inbox.'
              : 'Enter your registered email address to receive a secure password reset link.'}
          </p>
        </div>

        {/* Mode Tabs */}
        <div className="mt-6 grid grid-cols-3 gap-1.5 rounded-xl border border-[var(--aw-border)] bg-[#ebe8fa] dark:bg-[#080812]/80 p-1 text-xs font-semibold">
          <button
            type="button"
            onClick={() => switchMode('login')}
            className={`rounded-lg py-2 transition-transform ${
              mode === 'login'
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812] shadow-sm'
                : 'text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => switchMode('register')}
            className={`rounded-lg py-2 transition-transform ${
              mode === 'register'
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812] shadow-sm'
                : 'text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
            }`}
          >
            Create Account
          </button>
          <button
            type="button"
            onClick={() => switchMode('email-link')}
            className={`rounded-lg py-2 transition-transform ${
              mode === 'email-link'
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812] shadow-sm'
                : 'text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
            }`}
          >
            Email Link
          </button>
        </div>

        {/* Alerts */}
        {error && (
          <div
            role="alert"
            className="mt-4 flex items-start gap-2.5 rounded-xl border border-red-500/40 bg-red-50 dark:bg-red-950/40 p-3.5 text-xs leading-relaxed text-red-800 dark:text-red-200"
          >
            <AlertCircle className="h-4 w-4 shrink-0 text-red-500 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
        {notice && (
          <div
            role="status"
            className="mt-4 flex items-start gap-2.5 rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-sky-50 dark:bg-[#080812]/80 p-3.5 text-xs leading-relaxed text-[#0369A1] dark:text-[#43B8FF]"
          >
            <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{notice}</span>
          </div>
        )}

        {/* Animated View Transitions */}
        <AnimatePresence mode="wait">
          {mode === 'login' && (
            <motion.div
              key="login"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="mt-5 space-y-5"
            >
              {/* Multi-provider OAuth Grid */}
              <div className="space-y-2">
                {PROVIDER_BUTTONS.slice(0, 1).map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    disabled={loading}
                    onClick={() => void handleOAuth(p.id, p.label)}
                    className="group flex w-full items-center justify-center gap-2.5 rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white dark:bg-[#080812] px-4 py-2.5 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF] hover:-translate-y-0.5 transition-transform disabled:opacity-50"
                  >
                    {busyProvider === p.id ? <Loader2 className="h-4 w-4 animate-spin" /> : p.renderIcon()}
                    <span>{p.label}</span>
                  </button>
                ))}

                <div className="grid grid-cols-2 gap-2">
                  {PROVIDER_BUTTONS.slice(1).map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      disabled={loading}
                      onClick={() => void handleOAuth(p.id, p.label)}
                      className="flex items-center justify-center gap-2 rounded-xl border border-[var(--aw-border)] bg-white dark:bg-[#080812]/90 px-3 py-2.5 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] hover:-translate-y-0.5 transition-transform disabled:opacity-50"
                    >
                      {busyProvider === p.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : p.renderIcon()}
                      <span className="truncate">{p.label.replace('Continue with ', '')}</span>
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  disabled={loading}
                  onClick={() => switchMode('email-link')}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-[var(--aw-border)] bg-white dark:bg-[#080812]/70 px-4 py-2.5 text-xs font-semibold text-[#524E6B] dark:text-[#AAA7BC] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-transform"
                >
                  <Mail className="h-3.5 w-3.5 text-[#6D38E8] dark:text-[#43B8FF]" />
                  Continue with Email (Passwordless Link)
                </button>
              </div>

              <div className="flex items-center gap-3 text-[11px] uppercase tracking-wider text-[#524E6B] dark:text-[#AAA7BC]">
                <span className="h-px flex-1 bg-[var(--aw-border)]" />
                <span>or email &amp; password</span>
                <span className="h-px flex-1 bg-[var(--aw-border)]" />
              </div>

              <form onSubmit={(e) => void handleEmailPasswordLogin(e)} className="space-y-3.5">
                <div>
                  <label htmlFor="auth-login-email" className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">
                    Email Address
                  </label>
                  <input
                    id="auth-login-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="traveler@example.com"
                    className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF] focus:border-[#6D38E8] dark:focus:border-[#9B5CFF] focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="auth-login-password" className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      id="auth-login-password"
                      type={showLoginPass ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3.5 py-2.5 pr-10 text-sm text-[#141229] dark:text-[#F5F3FF] focus:border-[#6D38E8] dark:focus:border-[#9B5CFF] focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() => setShowLoginPass((v) => !v)}
                      aria-label={showLoginPass ? 'Hide password' : 'Show password'}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]"
                    >
                      {showLoginPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <label className="flex items-center gap-2 text-[#524E6B] dark:text-[#AAA7BC] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="accent-[#6D38E8] dark:accent-[#9B5CFF]"
                    />
                    Keep me signed in
                  </label>
                  <button
                    type="button"
                    onClick={() => switchMode('forgot')}
                    className="font-medium text-[#0284C7] dark:text-[#43B8FF] hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-4 py-3 text-sm font-bold text-white dark:text-[#080812] hover:opacity-95 hover:-translate-y-0.5 transition-transform disabled:opacity-50"
                >
                  {busyProvider === 'password' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                  {busyProvider === 'password' ? 'Signing In...' : 'Sign In to World'}
                </button>
              </form>
            </motion.div>
          )}

          {mode === 'register' && (
            <motion.form
              key="register"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              onSubmit={(e) => void handleRegister(e)}
              className="mt-5 space-y-3.5"
            >
              {/* Avatar Upload Preview */}
              <div className="flex items-center gap-3.5 rounded-2xl border border-[var(--aw-border)] bg-[#ebe8fa]/50 dark:bg-[#080812]/70 p-3">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-[#6D38E8]/40 dark:border-[#9B5CFF]/40 bg-white dark:bg-[#10101F]">
                  {avatarPreview ? (
                    <img src={avatarPreview} alt="Avatar preview" className="h-full w-full object-cover" />
                  ) : (
                    <UserPlus className="h-5 w-5 text-[#6D38E8] dark:text-[#9B5CFF]" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold text-[#141229] dark:text-[#F5F3FF]">Profile Avatar (Optional)</div>
                  <label className="mt-1 inline-flex cursor-pointer items-center gap-1.5 text-[11px] font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline">
                    <Upload className="h-3.5 w-3.5" />
                    <span>Upload Photo</span>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={(e) => void handleAvatarFile(e)}
                      className="sr-only"
                    />
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Full Name</label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Akira Sato"
                    className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
                  />
                  {regErrors.fullName && <p className="mt-1 text-[11px] text-red-500 dark:text-red-400">{regErrors.fullName}</p>}
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Username</label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="astral_traveler"
                    className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
                  />
                  {regErrors.username && <p className="mt-1 text-[11px] text-red-500 dark:text-red-400">{regErrors.username}</p>}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Email Address</label>
                <input
                  type="email"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="akira@example.com"
                  className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
                />
                {regErrors.email && <p className="mt-1 text-[11px] text-red-500 dark:text-red-400">{regErrors.email}</p>}
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Password</label>
                  <div className="relative">
                    <input
                      type={showRegPass ? 'text' : 'password'}
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="Min 8 chars"
                      className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 pr-9 text-sm text-[#141229] dark:text-[#F5F3FF]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPass((v) => !v)}
                      aria-label={showRegPass ? 'Hide password' : 'Show password'}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]"
                    >
                      {showRegPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {regErrors.password && <p className="mt-1 text-[11px] text-red-500 dark:text-red-400">{regErrors.password}</p>}
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Confirm Password</label>
                  <div className="relative">
                    <input
                      type={showRegConfirm ? 'text' : 'password'}
                      value={regConfirm}
                      onChange={(e) => setRegConfirm(e.target.value)}
                      placeholder="Repeat password"
                      className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 pr-9 text-sm text-[#141229] dark:text-[#F5F3FF]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegConfirm((v) => !v)}
                      aria-label={showRegConfirm ? 'Hide confirm password' : 'Show confirm password'}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]"
                    >
                      {showRegConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {regErrors.confirmPassword && <p className="mt-1 text-[11px] text-red-500 dark:text-red-400">{regErrors.confirmPassword}</p>}
                </div>
              </div>

              <label className="flex items-start gap-2.5 text-xs text-[#524E6B] dark:text-[#AAA7BC] cursor-pointer">
                <input
                  type="checkbox"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  className="mt-0.5 accent-[#6D38E8] dark:accent-[#9B5CFF]"
                />
                <span>
                  I accept the{' '}
                  <Link to="/terms" className="text-[#0284C7] dark:text-[#43B8FF] underline">
                    Terms &amp; Conditions
                  </Link>{' '}
                  and{' '}
                  <Link to="/privacy" className="text-[#0284C7] dark:text-[#43B8FF] underline">
                    Privacy Policy
                  </Link>
                  .
                </span>
              </label>
              {regErrors.acceptTerms && <p className="text-[11px] text-red-500 dark:text-red-400">{regErrors.acceptTerms}</p>}

              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-4 py-3 text-sm font-bold text-white dark:text-[#080812] hover:opacity-95 transition-all disabled:opacity-50"
              >
                {busyProvider === 'register' && <Loader2 className="h-4 w-4 animate-spin" />}
                {busyProvider === 'register' ? 'Creating Account...' : 'Create Account & Send Verification'}
              </button>
            </motion.form>
          )}

          {mode === 'email-link' && (
            <motion.form
              key="email-link"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              onSubmit={(e) => void handleEmailLinkSubmit(e)}
              className="mt-5 space-y-4"
            >
              <div>
                <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[#524E6B] dark:text-[#AAA7BC]" />
                  <input
                    type="email"
                    required
                    value={magicEmail}
                    onChange={(e) => setMagicEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] pl-10 pr-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-4 py-3 text-sm font-bold text-white dark:text-[#080812] hover:opacity-95 disabled:opacity-50"
              >
                {busyProvider === 'email-link' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mail className="h-4 w-4" />}
                {needsEmailConfirmForLink
                  ? 'Confirm Email & Complete Sign In'
                  : busyProvider === 'email-link'
                  ? 'Sending Sign-In Link...'
                  : 'Send Passwordless Sign-In Link'}
              </button>

              <p className="text-center text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                Prefer a password?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('login')}
                  className="font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline"
                >
                  Return to standard sign in
                </button>
              </p>
            </motion.form>
          )}

          {mode === 'forgot' && (
            <motion.form
              key="forgot"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              onSubmit={(e) => void handleForgotSubmit(e)}
              className="mt-5 space-y-4"
            >
              <div>
                <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1.5">
                  Registered Email Address
                </label>
                <div className="relative">
                  <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[#524E6B] dark:text-[#AAA7BC]" />
                  <input
                    type="email"
                    required
                    value={magicEmail}
                    onChange={(e) => setMagicEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] pl-10 pr-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-4 py-3 text-sm font-bold text-white dark:text-[#080812] hover:opacity-95 disabled:opacity-50"
              >
                {busyProvider === 'forgot' && <Loader2 className="h-4 w-4 animate-spin" />}
                {busyProvider === 'forgot' ? 'Dispatching Reset Link...' : 'Send Password Reset Email'}
              </button>

              <p className="text-center text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                Remembered your credentials?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('login')}
                  className="font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline"
                >
                  Back to Sign In
                </button>
              </p>
            </motion.form>
          )}
        </AnimatePresence>

        {showGuestButton && onGuestContinue && (
          <div className="mt-5 border-t border-[var(--aw-border)] pt-4 text-center">
            <button
              type="button"
              onClick={onGuestContinue}
              className="text-xs font-semibold text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#6D38E8] dark:hover:text-[#43B8FF] transition-colors"
            >
              Continue as Guest &amp; Explore Anime Universe →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
