import { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  FolderOpen,
  HardDrive,
  Loader2,
  RefreshCw,
  Share2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useDownloads } from '../context/DownloadContext';
import { ensureAnimeWorldDriveFolder, uploadFileToDrive } from '../services/googleWorkspace';
import { buildSafeMp4Filename, formatBytes, isValidMp4Buffer } from '../services/videoDownloadHelpers';
import { WorkspaceConfirmModal, type WorkspaceConfirmRequest } from './WorkspaceConfirmModal';

interface VideoDownloadControlProps {
  videoId: string;
  title: string;
  thumbnailUrl?: string;
  compact?: boolean;
}

export function VideoDownloadControl({
  videoId,
  title,
  thumbnailUrl,
  compact = false,
}: VideoDownloadControlProps) {
  const { needsWorkspaceAuth, connectGoogleWorkspace, showFeedback } = useAuth();
  const { activeDownloads, startVideoDownload, retryVideoDownload, shareDownloadedVideo } = useDownloads();
  const [driveBusy, setDriveBusy] = useState(false);
  const [confirmRequest, setConfirmRequest] = useState<WorkspaceConfirmRequest | null>(null);
  const task = activeDownloads[videoId];

  const isDownloading = task?.status === 'downloading';
  const isCompleted = task?.status === 'completed';
  const isFailed = task?.status === 'failed';

  const handlePrimaryClick = () => {
    if (isDownloading) return;
    if (isFailed) {
      void retryVideoDownload(videoId, title, thumbnailUrl);
      return;
    }
    void startVideoDownload({ videoId, title, thumbnailUrl });
  };

  const handleSaveToDriveClick = () => {
    const filename = buildSafeMp4Filename(title, videoId);
    setConfirmRequest({
      title: 'Save MP4 Video to Google Drive?',
      description: needsWorkspaceAuth
        ? 'Sign in with Google and upload this verified MP4 video directly into "THE ANIME WORLD Library" in your Google Drive.'
        : 'Upload this verified MP4 video directly into "THE ANIME WORLD Library" folder in your Google Drive.',
      details: [`File: ${filename}`, 'Format: Video (MP4)', 'Destination: Google Drive / THE ANIME WORLD Library'],
      confirmLabel: needsWorkspaceAuth ? 'Connect Google & Save' : 'Upload to Drive',
      tone: 'primary',
      onConfirm: async () => {
        if (needsWorkspaceAuth) {
          await connectGoogleWorkspace();
        }
        const res = await fetch(`/api/videos/${encodeURIComponent(videoId)}/download`);
        if (!res.ok) {
          throw new Error(`Unable to fetch video stream (${res.status}).`);
        }
        const buf = await res.arrayBuffer();
        const bytes = new Uint8Array(buf);
        if (!isValidMp4Buffer(bytes)) {
          throw new Error('Downloaded file did not pass MP4 header validation.');
        }
        const folder = await ensureAnimeWorldDriveFolder();
        await uploadFileToDrive({
          name: filename,
          mimeType: 'video/mp4',
          content: new Blob([bytes], { type: 'video/mp4' }),
          parentId: folder.id,
        });
        showFeedback('success', `Saved "${filename}" to Google Drive → THE ANIME WORLD Library.`);
      },
    });
  };

  const runConfirmedDriveUpload = async () => {
    if (!confirmRequest) return;
    setDriveBusy(true);
    try {
      await confirmRequest.onConfirm();
      setConfirmRequest(null);
    } catch (err) {
      showFeedback('error', err instanceof Error ? err.message : 'Unable to save video to Google Drive.');
    } finally {
      setDriveBusy(false);
    }
  };

  return (
    <div className="space-y-2.5">
      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={handlePrimaryClick}
          disabled={isDownloading}
          data-testid={`download-btn-${videoId}`}
          className={`inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-all disabled:cursor-not-allowed ${
            isFailed
              ? 'bg-red-600 text-white hover:bg-red-700'
              : isCompleted
              ? 'border border-emerald-500/45 bg-emerald-500/12 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/20'
              : 'bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] text-white dark:text-[#080812] hover:opacity-95 disabled:opacity-75'
          }`}
        >
          {isDownloading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              <span className="font-mono-tabular">Downloading {task.progressPct}%</span>
            </>
          ) : isFailed ? (
            <>
              <RefreshCw className="h-4 w-4" />
              <span>Retry Download</span>
            </>
          ) : isCompleted ? (
            <>
              <CheckCircle2 className="h-4 w-4" />
              <span>Save Again (MP4)</span>
            </>
          ) : (
            <>
              <Download className="h-4 w-4" />
              <span>Download MP4</span>
            </>
          )}
        </button>

        {!compact && typeof window !== 'undefined' && 'showSaveFilePicker' in window && !isDownloading && (
          <button
            type="button"
            onClick={() => void startVideoDownload({ videoId, title, thumbnailUrl, useFolderPicker: true })}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#080812] px-3.5 py-2 text-xs font-medium text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] transition-colors"
            title="Choose Movies or Anime World folder on your device"
          >
            <FolderOpen className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
            <span>Choose Folder</span>
          </button>
        )}

        {!compact && (
          <button
            type="button"
            onClick={handleSaveToDriveClick}
            disabled={driveBusy || isDownloading}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[#0284C7]/45 dark:border-[#43B8FF]/45 bg-white/90 dark:bg-[#080812] px-3.5 py-2 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:bg-[#0284C7]/10 transition-colors disabled:opacity-60"
          >
            <HardDrive className="h-4 w-4" />
            <span>Save MP4 to Google Drive</span>
          </button>
        )}

        {isCompleted && task.canShareFile && (
          <button
            type="button"
            onClick={() => void shareDownloadedVideo(videoId)}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[#0284C7]/45 dark:border-[#43B8FF]/45 bg-white/90 dark:bg-[#080812] px-3.5 py-2 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:bg-[#0284C7]/10 transition-colors"
          >
            <Share2 className="h-4 w-4" />
            <span>Save to Gallery / Share</span>
          </button>
        )}
      </div>

      {task && (
        <div
          role={isFailed ? 'alert' : 'status'}
          aria-live="polite"
          data-testid={`download-status-${videoId}`}
          className={`rounded-xl border px-3.5 py-2.5 text-xs ${
            isFailed
              ? 'border-red-500/40 bg-red-50 dark:bg-red-950/30 text-red-700 dark:text-red-200'
              : isCompleted
              ? 'border-emerald-500/40 bg-emerald-50 dark:bg-emerald-950/25 text-emerald-800 dark:text-emerald-200'
              : 'border-[#0284C7]/35 dark:border-[#43B8FF]/35 bg-white/90 dark:bg-[#10101F]/90 text-[#141229] dark:text-[#F5F3FF]'
          }`}
        >
          <div className="flex items-center justify-between gap-2 font-medium">
            <span className="inline-flex items-center gap-1.5">
              {isFailed ? (
                <AlertCircle className="h-3.5 w-3.5 shrink-0" />
              ) : isCompleted ? (
                <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
              ) : (
                <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-[#0284C7] dark:text-[#43B8FF]" />
              )}
              <span>
                {isDownloading
                  ? 'Downloading MP4...'
                  : isCompleted
                  ? 'Download Complete'
                  : 'Download Failed'}
              </span>
            </span>
            <span className="font-mono-tabular">
              {task.totalBytes > 0
                ? `${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)}`
                : formatBytes(task.downloadedBytes)}{' '}
              ({task.progressPct}%)
            </span>
          </div>

          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-black/10 dark:bg-white/10">
            <div
              className={`h-full transition-[width] duration-150 ${
                isFailed
                  ? 'bg-red-500'
                  : isCompleted
                  ? 'bg-emerald-500'
                  : 'bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF]'
              }`}
              style={{ width: `${Math.max(4, task.progressPct)}%` }}
            />
          </div>

          {isCompleted && (
            <p className="mt-1.5 text-[11px] opacity-90">
              {task.filename} · Saved to {task.saveLocation}. {task.guidanceText}
            </p>
          )}
          {isFailed && task.errorMessage && (
            <p className="mt-1.5 text-[11px] opacity-95">{task.errorMessage}</p>
          )}
        </div>
      )}

      <WorkspaceConfirmModal
        request={confirmRequest}
        busy={driveBusy}
        onCancel={() => {
          if (!driveBusy) setConfirmRequest(null);
        }}
        onProceed={() => void runConfirmedDriveUpload()}
      />
    </div>
  );
}
