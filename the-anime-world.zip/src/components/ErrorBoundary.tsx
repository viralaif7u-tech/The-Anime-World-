import React from 'react';
import { Link } from 'react-router-dom';

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, ErrorBoundaryState> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, message: error.message || 'Unexpected rendering error' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[var(--aw-bg)] text-[var(--aw-text)] flex flex-col items-center justify-center px-6 text-center">
          <div className="max-w-md rounded-2xl border border-[#6D38E8]/25 dark:border-[#9B5CFF]/25 bg-white/95 dark:bg-[#10101F]/95 p-8 shadow-xl">
            <h1 className="font-display text-2xl font-bold">Dimensional Rift Encountered</h1>
            <p className="mt-3 text-sm text-[#524E6B] dark:text-[#AAA7BC]">{this.state.message}</p>
            <div className="mt-6 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => window.location.reload()}
                className="rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2 text-sm font-semibold text-white dark:text-[#080812] hover:bg-[#5b2cd1] dark:hover:bg-[#8847f5] transition-colors"
              >
                Reload Universe
              </button>
              <Link
                to="/"
                onClick={() => this.setState({ hasError: false, message: '' })}
                className="rounded-lg border border-[var(--aw-border-strong)] px-4 py-2 text-sm font-medium text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors"
              >
                Return Home
              </Link>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
