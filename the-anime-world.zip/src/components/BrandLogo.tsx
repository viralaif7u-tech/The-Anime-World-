export function BrandMarkSvg({ size = 32 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      className="shrink-0"
    >
      <circle cx="32" cy="32" r="27" stroke="url(#awPortalRing)" strokeWidth="2.4" />
      <circle cx="32" cy="32" r="20" stroke="#43B8FF" strokeWidth="1.2" strokeDasharray="5 4" opacity="0.75" />
      <path
        d="M12 32C18.5 22 25 18.5 32 18.5C39 18.5 45.5 22 52 32C45.5 42 39 45.5 32 45.5C25 45.5 18.5 42 12 32Z"
        fill="#10101F"
        stroke="#F5F3FF"
        strokeWidth="2"
      />
      <circle cx="32" cy="32" r="7.5" fill="url(#awIrisGrad)" />
      <circle cx="32" cy="32" r="3" fill="#080812" />
      <circle cx="34.8" cy="29.4" r="1.5" fill="#F5F3FF" />
      <defs>
        <linearGradient id="awPortalRing" x1="6" y1="6" x2="58" y2="58" gradientUnits="userSpaceOnUse">
          <stop stopColor="#9B5CFF" />
          <stop offset="1" stopColor="#43B8FF" />
        </linearGradient>
        <radialGradient
          id="awIrisGrad"
          cx="0"
          cy="0"
          r="1"
          gradientUnits="userSpaceOnUse"
          gradientTransform="translate(32 32) rotate(90) scale(7.5)"
        >
          <stop stopColor="#43B8FF" />
          <stop offset="0.6" stopColor="#9B5CFF" />
          <stop offset="1" stopColor="#5126A8" />
        </radialGradient>
      </defs>
    </svg>
  );
}

export function BrandLogo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="inline-flex items-center gap-1.5 sm:gap-2.5 whitespace-nowrap shrink-0">
      <BrandMarkSvg size={compact ? 24 : 28} />
      {!compact && (
        <span className="font-display text-[13px] sm:text-base font-bold tracking-tight text-[#141229] dark:text-[#F5F3FF] transition-colors">
          THE ANIME WORLD
        </span>
      )}
    </span>
  );
}

export function LoadingPortalLogo() {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-12" role="status" aria-label="Loading">
      <div className="relative flex items-center justify-center">
        <div className="h-16 w-16 rounded-full border-2 border-[#6D38E8]/40 dark:border-[#9B5CFF]/40 border-t-[#0284C7] dark:border-t-[#43B8FF] animate-spin" />
        <div className="absolute">
          <BrandMarkSvg size={38} />
        </div>
      </div>
      <span className="text-xs font-medium tracking-wider text-[#524E6B] dark:text-[#AAA7BC]">
        Loading THE ANIME WORLD
      </span>
    </div>
  );
}
