import { useEffect, useRef, useState } from 'react';
import { Maximize2, Minimize2, Pause, Play, Volume2, VolumeX } from 'lucide-react';
import type { AnimationItem } from '../types/anime';

export function ProceduralMotionPlayer({ item }: { item: AnimationItem }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);
  const [progress, setProgress] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);

  const playingRef = useRef(playing);
  useEffect(() => {
    playingRef.current = playing;
  }, [playing]);

  useEffect(() => {
    if (item.mode === 'youtube-embed') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let rafId = 0;
    let t = 0;

    const particles = Array.from({ length: 48 }, (_, i) => ({
      x: (i * 97) % 960,
      y: (i * 53) % 540,
      speed: 0.6 + (i % 5) * 0.35,
      size: 2 + (i % 4) * 1.4,
      hue: i % 2 === 0 ? '#9B5CFF' : '#43B8FF',
    }));

    const draw = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.fillStyle = '#080812';
      ctx.fillRect(0, 0, w, h);

      const cx = w / 2;
      const cy = h / 2;

      if (item.mode === 'procedural-portal') {
        const grad = ctx.createRadialGradient(cx, cy, 18, cx, cy, 240);
        grad.addColorStop(0, 'rgba(67, 184, 255, 0.48)');
        grad.addColorStop(0.5, 'rgba(155, 92, 255, 0.25)');
        grad.addColorStop(1, 'rgba(8, 8, 18, 0)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        for (let r = 0; r < 5; r++) {
          ctx.save();
          ctx.translate(cx, cy);
          ctx.rotate(t * (r % 2 === 0 ? 0.5 : -0.35) + r * 0.4);
          ctx.strokeStyle = r % 2 === 0 ? '#9B5CFF' : '#43B8FF';
          ctx.lineWidth = 2.5;
          ctx.setLineDash([28 + r * 8, 14]);
          ctx.beginPath();
          ctx.arc(0, 0, 62 + r * 32 + Math.sin(t * 2 + r) * 5, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }

        // Anime eye silhouette
        ctx.strokeStyle = '#F5F3FF';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(cx - 80, cy);
        ctx.quadraticCurveTo(cx, cy - 52, cx + 80, cy);
        ctx.quadraticCurveTo(cx, cy + 52, cx - 80, cy);
        ctx.stroke();

        ctx.fillStyle = '#43B8FF';
        ctx.beginPath();
        ctx.arc(cx, cy, 22 + Math.sin(t * 3) * 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#080812';
        ctx.beginPath();
        ctx.arc(cx, cy, 9, 0, Math.PI * 2);
        ctx.fill();
      } else if (item.mode === 'procedural-sakura') {
        const grad = ctx.createRadialGradient(cx, cy - 60, 20, cx, cy - 60, 260);
        grad.addColorStop(0, 'rgba(155, 92, 255, 0.45)');
        grad.addColorStop(1, 'rgba(8, 8, 18, 0)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        // Eclipse ring
        ctx.strokeStyle = '#9B5CFF';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(cx, cy - 70, 74, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#080812';
        ctx.beginPath();
        ctx.arc(cx, cy - 70, 70, 0, Math.PI * 2);
        ctx.fill();

        // Water ripples
        ctx.strokeStyle = 'rgba(67, 184, 255, 0.32)';
        ctx.lineWidth = 1.5;
        for (let i = 0; i < 6; i++) {
          const ry = h * 0.68 + i * 24;
          ctx.beginPath();
          ctx.moveTo(0, ry);
          for (let x = 0; x <= w; x += 40) {
            ctx.lineTo(x, ry + Math.sin(x * 0.02 + t * 2 + i) * 4);
          }
          ctx.stroke();
        }
      } else {
        // procedural-cyber
        const horizon = h * 0.62;
        ctx.strokeStyle = 'rgba(155, 92, 255, 0.35)';
        ctx.lineWidth = 1.5;
        for (let i = -8; i <= 8; i++) {
          ctx.beginPath();
          ctx.moveTo(cx + i * 32, horizon);
          ctx.lineTo(cx + i * 110, h);
          ctx.stroke();
        }
        for (let j = 0; j < 7; j++) {
          const y = horizon + ((j * 28 + t * 60) % (h - horizon));
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
          ctx.stroke();
        }
        ctx.strokeStyle = '#43B8FF';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(cx, horizon - 90, 68, 0, Math.PI * 2);
        ctx.stroke();
      }

      for (const p of particles) {
        if (playingRef.current && !reducedMotion) {
          p.y = (p.y + p.speed) % h;
          p.x = (p.x + Math.sin(t + p.y * 0.01) * 0.5 + w) % w;
        }
        ctx.fillStyle = p.hue;
        ctx.globalAlpha = 0.75;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      if (playingRef.current && !reducedMotion) {
        t += 0.022;
        setProgress(Math.round(((t % 10) / 10) * 100));
        rafId = requestAnimationFrame(draw);
      }
    };

    draw();
    return () => cancelAnimationFrame(rafId);
  }, [item.mode, playing]);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      void containerRef.current.requestFullscreen?.();
      setFullscreen(true);
    } else {
      void document.exitFullscreen?.();
      setFullscreen(false);
    }
  };

  if (item.mode === 'youtube-embed' && item.youtubeId) {
    return (
      <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-white/10 bg-[#080812]">
        <iframe
          src={`https://www.youtube-nocookie.com/embed/${item.youtubeId}?rel=0`}
          title={item.title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="h-full w-full"
        />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative overflow-hidden rounded-xl border border-white/15 bg-[#080812]"
    >
      <canvas
        ref={canvasRef}
        width={960}
        height={540}
        data-testid="animation-canvas"
        className="aspect-video w-full block"
      />
      <div className="flex items-center justify-between gap-4 border-t border-white/10 bg-[#10101F] px-4 py-3">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setPlaying((p) => !p)}
            aria-label={playing ? 'Pause animation' : 'Play animation'}
            className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#9B5CFF] text-[#080812] hover:bg-[#8a46f7] transition-colors"
          >
            {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </button>
          <button
            type="button"
            onClick={() => setMuted((m) => !m)}
            aria-label={muted ? 'Unmute audio' : 'Mute audio'}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/15 text-[#F5F3FF] hover:border-[#43B8FF] transition-colors"
          >
            {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </button>
          <span className="font-mono-tabular text-xs text-[#AAA7BC]">{item.durationLabel}</span>
        </div>

        <div className="flex-1 max-w-md">
          <input
            type="range"
            min={0}
            max={100}
            value={progress}
            onChange={(e) => setProgress(Number(e.target.value))}
            aria-label="Animation timeline progress"
            className="w-full accent-[#43B8FF]"
          />
        </div>

        <button
          type="button"
          onClick={toggleFullscreen}
          aria-label={fullscreen ? 'Exit fullscreen' : 'Fullscreen player'}
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/15 text-[#F5F3FF] hover:border-[#43B8FF] transition-colors"
        >
          {fullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </button>
      </div>
    </div>
  );
}
