import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export function BackButton() {
  const location = useLocation();
  const navigate = useNavigate();

  if (location.pathname === '/') {
    return null;
  }

  const handleBack = () => {
    const historyState = window.history.state as { idx?: number } | null;
    if (historyState && typeof historyState.idx === 'number' && historyState.idx > 0) {
      navigate(-1);
      return;
    }
    navigate('/');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 pt-4 sm:px-6 lg:px-8">
      <button
        type="button"
        onClick={handleBack}
        aria-label="Go back to previous page"
        data-testid="inner-back-button"
        className="inline-flex min-h-[44px] min-w-[44px] items-center gap-2 rounded-xl border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-3.5 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] shadow-sm hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] hover:text-[#6D38E8] dark:hover:text-[#43B8FF] transition-colors"
      >
        <ArrowLeft className="h-4 w-4 shrink-0" />
        <span>Back</span>
      </button>
    </div>
  );
}
