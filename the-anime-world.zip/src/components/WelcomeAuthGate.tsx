import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { Compass, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AuthExperience } from './AuthExperience';

const WELCOME_DISMISSED_KEY = 'aw_welcome_dismissed';

/**
 * Animated Welcome & Authentication Screen for new unauthenticated visitors.
 * Automatically stays out of the way when `?autostart=1` / `?guest=1` is present,
 * when already signed in, on dedicated auth routes, or once dismissed.
 */
export function WelcomeAuthGate() {
  const { user, authReady } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!authReady) return;
    if (user) {
      setOpen(false);
      return;
    }

    const params = new URLSearchParams(location.search);
    if (params.get('autostart') === '1' || params.get('guest') === '1') {
      try {
        window.sessionStorage.setItem(WELCOME_DISMISSED_KEY, '1');
      } catch {
        // Ignore
      }
      setOpen(false);
      return;
    }

    if (['/login', '/register', '/forgot-password', '/privacy', '/terms'].includes(location.pathname)) {
      setOpen(false);
      return;
    }

    try {
      const dismissed = window.sessionStorage.getItem(WELCOME_DISMISSED_KEY);
      if (!dismissed) {
        setOpen(true);
      }
    } catch {
      setOpen(true);
    }
  }, [authReady, user, location.pathname, location.search]);

  const dismiss = () => {
    try {
      window.sessionStorage.setItem(WELCOME_DISMISSED_KEY, '1');
    } catch {
      // Ignore
    }
    setOpen(false);
  };

  const dialog = (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          role="dialog"
          aria-modal="true"
          aria-label="Welcome to THE ANIME WORLD"
          className="fixed inset-0 z-[70] flex items-center justify-center overflow-y-auto bg-[#080812]/80 backdrop-blur-md p-4 sm:p-6"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 18 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="relative my-auto w-full max-w-lg"
          >
            <button
              type="button"
              onClick={dismiss}
              aria-label="Dismiss welcome screen and explore as guest"
              className="absolute right-4 top-4 z-20 inline-flex h-9 w-9 items-center justify-center rounded-xl border border-[var(--aw-border)] bg-white/80 dark:bg-[#080812]/80 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors"
            >
              <X className="h-4 w-4" />
            </button>

            <AuthExperience
              initialMode="login"
              titleOverride="Enter THE ANIME WORLD"
              showGuestButton
              onSuccess={() => {
                dismiss();
                navigate('/dashboard');
              }}
              onGuestContinue={dismiss}
            />

            <div className="mt-3 flex items-center justify-center gap-2 text-xs text-white/75">
              <Compass className="h-3.5 w-3.5 text-[#43B8FF]" />
              <span>Full catalog, 3D world &amp; galleries available to explore anytime.</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );

  if (typeof document === 'undefined') return null;
  return createPortal(dialog, document.body);
}
