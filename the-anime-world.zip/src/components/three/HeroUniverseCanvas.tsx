import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  afterDraw,
  createRunicRingTexture,
  createStudioEnvironment,
  createSurfaceMicroTexture,
  detectSoftwareGl,
  isWebGLAvailable,
} from './webglUtils';
import { BRAND_IMAGES } from '../../data/catalog';

interface HeroUniverseCanvasProps {
  scrollProgress?: number;
}

const _dummy = new THREE.Object3D();

function buildFloatingIsland(
  rockMat: THREE.Material,
  trimMat: THREE.Material,
  glowMat: THREE.Material,
  withTorii: boolean
): THREE.Group {
  const island = new THREE.Group();

  const deck = new THREE.Mesh(new THREE.CylinderGeometry(1.55, 1.35, 0.24, 7), trimMat);
  deck.position.y = 0;
  island.add(deck);

  const rockUpper = new THREE.Mesh(new THREE.ConeGeometry(1.42, 1.35, 7), rockMat);
  rockUpper.rotation.x = Math.PI;
  rockUpper.position.y = -0.78;
  island.add(rockUpper);

  const rockSpire = new THREE.Mesh(new THREE.ConeGeometry(0.65, 1.1, 6), rockMat);
  rockSpire.rotation.x = Math.PI;
  rockSpire.position.set(0.32, -1.35, -0.15);
  island.add(rockSpire);

  const energyRing = new THREE.Mesh(new THREE.TorusGeometry(1.48, 0.025, 10, 42), glowMat);
  energyRing.rotation.x = Math.PI / 2;
  energyRing.position.y = 0.08;
  island.add(energyRing);

  if (withTorii) {
    const pillarL = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.07, 0.95, 10), trimMat);
    pillarL.position.set(-0.36, 0.56, 0);
    island.add(pillarL);

    const pillarR = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.07, 0.95, 10), trimMat);
    pillarR.position.set(0.36, 0.56, 0);
    island.add(pillarR);

    const kasagi = new THREE.Mesh(new THREE.BoxGeometry(1.15, 0.09, 0.14), glowMat);
    kasagi.position.set(0, 1.05, 0);
    island.add(kasagi);

    const nuki = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.055, 0.09), trimMat);
    nuki.position.set(0, 0.86, 0);
    island.add(nuki);
  } else {
    const obelisk = new THREE.Mesh(new THREE.OctahedronGeometry(0.34, 0), glowMat);
    obelisk.scale.set(0.7, 1.9, 0.7);
    obelisk.position.y = 0.75;
    island.add(obelisk);
  }

  return island;
}

export function HeroUniverseCanvas({ scrollProgress = 0 }: HeroUniverseCanvasProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const scrollRef = useRef(scrollProgress);
  const [fallbackActive, setFallbackActive] = useState(false);

  useEffect(() => {
    scrollRef.current = scrollProgress;
  }, [scrollProgress]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    if (!isWebGLAvailable()) {
      setFallbackActive(true);
      return;
    }

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const isSoftwareGl = detectSoftwareGl();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x080812);
    scene.fog = new THREE.FogExp2(0x080812, 0.036);

    const camera = new THREE.PerspectiveCamera(52, width / height, 0.1, 160);
    camera.position.set(0, 0.9, 10.5);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;

    container.appendChild(renderer.domElement);

    const envTexture = createStudioEnvironment(renderer);
    scene.environment = envTexture;

    const bumpTex = createSurfaceMicroTexture(renderer);
    const runicTex = createRunicRingTexture(renderer);

    const hemiLight = new THREE.HemisphereLight(0x43b8ff, 0x10101f, 0.85);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xf5f3ff, 1.9);
    keyLight.position.set(6, 9, 7);
    scene.add(keyLight);

    const purpleLight = new THREE.PointLight(0x9b5cff, 6.5, 24, 1.6);
    purpleLight.position.set(-4.5, 2.5, 4);
    scene.add(purpleLight);

    const blueLight = new THREE.PointLight(0x43b8ff, 5.5, 24, 1.6);
    blueLight.position.set(4.5, -1.5, 4.5);
    scene.add(blueLight);

    // Central Dimensional Portal Group (8 composite parts)
    const portalGroup = new THREE.Group();
    portalGroup.position.set(0, 0.35, -2.6);
    scene.add(portalGroup);

    const outerRingMat = new THREE.MeshPhysicalMaterial({
      color: 0x1a1638,
      metalness: 0.88,
      roughness: 0.22,
      clearcoat: 1,
      bumpMap: bumpTex,
      bumpScale: 0.02,
    });
    const violetGlowMat = new THREE.MeshStandardMaterial({
      color: 0x9b5cff,
      emissive: 0x9b5cff,
      emissiveIntensity: 1.6,
      roughness: 0.25,
      metalness: 0.3,
    });
    const blueGlowMat = new THREE.MeshStandardMaterial({
      color: 0x43b8ff,
      emissive: 0x43b8ff,
      emissiveIntensity: 1.45,
      roughness: 0.25,
      metalness: 0.3,
    });
    const coreCrystalMat = new THREE.MeshPhysicalMaterial({
      color: 0x5126a8,
      emissive: 0x3b1b8c,
      emissiveIntensity: 0.75,
      roughness: 0.12,
      metalness: 0.15,
      transmission: isSoftwareGl ? 0 : 0.75,
      transparent: true,
      opacity: isSoftwareGl ? 0.55 : 0.92,
      ior: 1.65,
      thickness: 1.2,
    });

    const outerRing = new THREE.Mesh(new THREE.TorusGeometry(2.65, 0.12, 16, 72), outerRingMat);
    portalGroup.add(outerRing);

    const innerVioletRing = new THREE.Mesh(new THREE.TorusGeometry(2.38, 0.045, 12, 72), violetGlowMat);
    portalGroup.add(innerVioletRing);

    const innerBlueRing = new THREE.Mesh(new THREE.TorusGeometry(2.05, 0.032, 12, 64), blueGlowMat);
    portalGroup.add(innerBlueRing);

    const runicDisc = new THREE.Mesh(
      new THREE.PlaneGeometry(5.1, 5.1),
      new THREE.MeshBasicMaterial({
        map: runicTex,
        transparent: true,
        opacity: 0.55,
        depthWrite: false,
        side: THREE.DoubleSide,
      })
    );
    runicDisc.position.z = -0.05;
    portalGroup.add(runicDisc);

    const irisCore = new THREE.Mesh(new THREE.OctahedronGeometry(0.72, 2), coreCrystalMat);
    irisCore.scale.set(1.15, 0.78, 0.55);
    portalGroup.add(irisCore);

    const pupilCore = new THREE.Mesh(
      new THREE.SphereGeometry(0.28, 24, 24),
      new THREE.MeshStandardMaterial({
        color: 0x080812,
        roughness: 0.1,
        metalness: 0.9,
      })
    );
    pupilCore.position.z = 0.22;
    portalGroup.add(pupilCore);

    // Orbiting energy crystals around portal
    const shardGroup = new THREE.Group();
    const shardGeom = new THREE.OctahedronGeometry(0.16, 0);
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2;
      const shard = new THREE.Mesh(shardGeom, i % 2 === 0 ? blueGlowMat : violetGlowMat);
      shard.position.set(Math.cos(angle) * 3.15, Math.sin(angle) * 3.15, (i % 3 - 1) * 0.28);
      shard.scale.set(0.65, 1.5, 0.65);
      shard.rotation.z = angle;
      shardGroup.add(shard);
    }
    portalGroup.add(shardGroup);

    // Floating Islands
    const rockMat = new THREE.MeshStandardMaterial({
      color: 0x16162b,
      roughness: 0.85,
      metalness: 0.12,
      bumpMap: bumpTex,
      bumpScale: 0.08,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      color: 0x26234a,
      roughness: 0.42,
      metalness: 0.65,
    });

    const islandLeft = buildFloatingIsland(rockMat, trimMat, violetGlowMat, true);
    islandLeft.position.set(-4.7, -1.0, -1.8);
    islandLeft.scale.setScalar(0.95);
    scene.add(islandLeft);

    const islandRight = buildFloatingIsland(rockMat, trimMat, blueGlowMat, false);
    islandRight.position.set(4.8, 1.15, -2.5);
    islandRight.scale.setScalar(0.82);
    scene.add(islandRight);

    const islandFar = buildFloatingIsland(rockMat, trimMat, violetGlowMat, false);
    islandFar.position.set(-2.9, 2.35, -5.8);
    islandFar.scale.setScalar(0.55);
    scene.add(islandFar);

    // Instanced Starfield & Dimensional Particles
    const starCount = isSoftwareGl ? 140 : 280;
    const starGeom = new THREE.OctahedronGeometry(0.055, 0);
    const starMat = new THREE.MeshBasicMaterial({ color: 0xf5f3ff });
    const starMesh = new THREE.InstancedMesh(starGeom, starMat, starCount);
    const starData: Array<{ x: number; y: number; z: number; s: number; speed: number }> = [];
    const c = new THREE.Color();

    for (let i = 0; i < starCount; i++) {
      const x = (Math.random() - 0.5) * 36;
      const y = (Math.random() - 0.5) * 22;
      const z = -2 - Math.random() * 28;
      const s = 0.45 + Math.random() * 1.15;
      starData.push({ x, y, z, s, speed: 0.25 + Math.random() * 0.55 });
      _dummy.position.set(x, y, z);
      _dummy.scale.setScalar(s);
      _dummy.updateMatrix();
      starMesh.setMatrixAt(i, _dummy.matrix);
      c.set(i % 3 === 0 ? 0x43b8ff : i % 3 === 1 ? 0x9b5cff : 0xf5f3ff);
      starMesh.setColorAt(i, c);
    }
    starMesh.instanceMatrix.needsUpdate = true;
    if (starMesh.instanceColor) starMesh.instanceColor.needsUpdate = true;
    starMesh.computeBoundingSphere();
    scene.add(starMesh);

    const pointer = { x: 0, y: 0 };
    const onPointerMove = (e: PointerEvent) => {
      pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.y = -(e.clientY / window.innerHeight) * 2 + 1;
    };
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const onContextLost = (ev: Event) => {
      ev.preventDefault();
      setFallbackActive(true);
    };
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);

    let disposed = false;
    let rafId = 0;
    let timerId = 0;
    const startTime = performance.now();
    let prevTime = startTime;

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const renderFrame = () => {
      if (disposed) return;
      const now = performance.now();
      const dt = Math.min((now - prevTime) / 1000, 0.1);
      prevTime = now;
      const t = (now - startTime) / 1000;

      if (!reducedMotion) {
        portalGroup.rotation.y = Math.sin(t * 0.35) * 0.14 + pointer.x * 0.15;
        portalGroup.rotation.x = pointer.y * 0.08;
        innerBlueRing.rotation.z = t * 0.35;
        innerVioletRing.rotation.z = -t * 0.22;
        runicDisc.rotation.z = t * 0.12;
        shardGroup.rotation.z = -t * 0.28;
        irisCore.rotation.y = t * 0.55;

        islandLeft.position.y = -1.0 + Math.sin(t * 0.8) * 0.18;
        islandRight.position.y = 1.15 + Math.cos(t * 0.7) * 0.16;
        islandFar.position.y = 2.35 + Math.sin(t * 0.6 + 1) * 0.12;

        const targetCamX = pointer.x * 0.75;
        const targetCamY = 0.9 + pointer.y * 0.45 - scrollRef.current * 1.4;
        const targetCamZ = 10.5 - scrollRef.current * 2.5;
        camera.position.x = THREE.MathUtils.damp(camera.position.x, targetCamX, 3.5, dt);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, targetCamY, 3.5, dt);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, targetCamZ, 3.5, dt);
        camera.lookAt(0, 0.2 - scrollRef.current * 0.6, -1.2);
      }

      renderer.render(scene, camera);

      if (reducedMotion) return;
      if (isSoftwareGl) {
        afterDraw(renderer, renderFrame, (id) => {
          timerId = id;
        });
      } else {
        rafId = requestAnimationFrame(renderFrame);
      }
    };

    renderFrame();

    return () => {
      disposed = true;
      cancelAnimationFrame(rafId);
      clearTimeout(timerId);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      envTexture.dispose();
      bumpTex.dispose();
      runicTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  if (fallbackActive) {
    return (
      <div className="absolute inset-0 overflow-hidden bg-[#080812]" data-testid="hero-3d-fallback">
        <img
          src={BRAND_IMAGES.celestialShrine}
          alt="THE ANIME WORLD Celestial Universe"
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#080812]/50 via-[#080812]/40 to-[#080812]" />
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      data-testid="hero-3d-canvas"
      className="absolute inset-0 h-full w-full pointer-events-none"
      aria-hidden="true"
    />
  );
}
