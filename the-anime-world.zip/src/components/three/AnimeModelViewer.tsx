import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { Eye, EyeOff, Maximize2, Minimize2, RotateCw, Sparkles, Upload } from 'lucide-react';
import {
  afterDraw,
  createContactShadowTexture,
  createRunicRingTexture,
  createStudioEnvironment,
  createSurfaceMicroTexture,
  detectSoftwareGl,
  isWebGLAvailable,
} from './webglUtils';
import type { Model3DItem } from '../../types/anime';

type MaterialPreset = 'obsidian' | 'chrome' | 'hologram' | 'sakura';
type CameraPreset = 'hero' | 'front' | 'top' | 'closeup';

interface AnimeModelViewerProps {
  model: Model3DItem;
  heightClass?: string;
  compactControls?: boolean;
}

const CAMERA_PRESETS: Record<CameraPreset, { pos: [number, number, number]; target: [number, number, number] }> = {
  hero: { pos: [3.2, 1.8, 4.4], target: [0, 0.25, 0] },
  front: { pos: [0, 0.7, 5.2], target: [0, 0.25, 0] },
  top: { pos: [0.01, 5.4, 1.4], target: [0, 0.1, 0] },
  closeup: { pos: [1.4, 0.9, 2.45], target: [0, 0.45, 0] },
};

function addExplodablePart(
  group: THREE.Group,
  mesh: THREE.Object3D,
  explodeDir: THREE.Vector3
) {
  mesh.userData.basePos = mesh.position.clone();
  mesh.userData.explodeDir = explodeDir.clone();
  group.add(mesh);
}

function buildCompositeAnimeModel(
  modelId: string,
  primaryMat: THREE.Material,
  secondaryMat: THREE.Material,
  accentMat: THREE.Material,
  glassMat: THREE.Material,
  runicTex: THREE.Texture
): THREE.Group {
  const root = new THREE.Group();

  // Shared grounded pedestal (bottom-center at y = -1.55)
  const plinth = new THREE.Mesh(new THREE.CylinderGeometry(1.35, 1.5, 0.22, 8), secondaryMat);
  plinth.position.set(0, -1.44, 0);
  plinth.receiveShadow = true;
  addExplodablePart(root, plinth, new THREE.Vector3(0, -0.45, 0));

  const plinthGlow = new THREE.Mesh(new THREE.TorusGeometry(1.38, 0.028, 12, 48), accentMat);
  plinthGlow.rotation.x = Math.PI / 2;
  plinthGlow.position.set(0, -1.32, 0);
  addExplodablePart(root, plinthGlow, new THREE.Vector3(0, -0.35, 0));

  if (modelId === 'aegis-09-astral-mecha') {
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.45, 1.15, 8), primaryMat);
    torso.position.set(0, -0.25, 0);
    torso.castShadow = true;
    addExplodablePart(root, torso, new THREE.Vector3(0, 0, 0));

    const chestPlate = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.56, 0.68), secondaryMat);
    chestPlate.position.set(0, 0.15, 0.1);
    chestPlate.castShadow = true;
    addExplodablePart(root, chestPlate, new THREE.Vector3(0, 0.15, 0.75));

    const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.24, 1), accentMat);
    core.position.set(0, 0.18, 0.45);
    addExplodablePart(root, core, new THREE.Vector3(0, 0.18, 1.25));

    const head = new THREE.Mesh(new THREE.OctahedronGeometry(0.42, 1), primaryMat);
    head.scale.set(0.92, 1.12, 1.0);
    head.position.set(0, 0.92, 0);
    head.castShadow = true;
    addExplodablePart(root, head, new THREE.Vector3(0, 0.9, 0));

    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.16, 0.32), glassMat);
    visor.position.set(0, 0.94, 0.25);
    addExplodablePart(root, visor, new THREE.Vector3(0, 0.95, 0.8));

    const hornL = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.62, 5), accentMat);
    hornL.position.set(-0.28, 1.28, 0.12);
    hornL.rotation.z = 0.48;
    addExplodablePart(root, hornL, new THREE.Vector3(-0.55, 1.1, 0.3));

    const hornR = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.62, 5), accentMat);
    hornR.position.set(0.28, 1.28, 0.12);
    hornR.rotation.z = -0.48;
    addExplodablePart(root, hornR, new THREE.Vector3(0.55, 1.1, 0.3));

    const pauldronL = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.46, 0.62), secondaryMat);
    pauldronL.position.set(-0.88, 0.38, 0);
    pauldronL.rotation.z = 0.25;
    addExplodablePart(root, pauldronL, new THREE.Vector3(-1.1, 0.3, 0));

    const pauldronR = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.46, 0.62), secondaryMat);
    pauldronR.position.set(0.88, 0.38, 0);
    pauldronR.rotation.z = -0.25;
    addExplodablePart(root, pauldronR, new THREE.Vector3(1.1, 0.3, 0));

    const wingL = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.55, 0.48), accentMat);
    wingL.position.set(-0.78, 0.55, -0.58);
    wingL.rotation.set(-0.2, 0.25, 0.52);
    addExplodablePart(root, wingL, new THREE.Vector3(-1.15, 0.6, -0.9));

    const wingR = new THREE.Mesh(new THREE.BoxGeometry(0.14, 1.55, 0.48), accentMat);
    wingR.position.set(0.78, 0.55, -0.58);
    wingR.rotation.set(-0.2, -0.25, -0.52);
    addExplodablePart(root, wingR, new THREE.Vector3(1.15, 0.6, -0.9));
  } else if (modelId === 'kurogane-celestial-katana') {
    const bladeShape = new THREE.Shape();
    bladeShape.moveTo(0, -1.1);
    bladeShape.quadraticCurveTo(0.14, 0, 0.04, 1.25);
    bladeShape.lineTo(-0.04, 1.15);
    bladeShape.quadraticCurveTo(0.03, 0, -0.05, -1.1);
    bladeShape.closePath();

    const bladeGeo = new THREE.ExtrudeGeometry(bladeShape, { depth: 0.03, bevelEnabled: true, bevelThickness: 0.01, bevelSize: 0.01 });
    bladeGeo.center();
    const blade = new THREE.Mesh(bladeGeo, primaryMat);
    blade.position.set(0, 0.45, 0);
    blade.rotation.z = -0.22;
    blade.castShadow = true;
    addExplodablePart(root, blade, new THREE.Vector3(0, 0.9, 0));

    const tsuba = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.05, 16), accentMat);
    tsuba.position.set(-0.18, -0.52, 0);
    tsuba.rotation.z = -0.22;
    addExplodablePart(root, tsuba, new THREE.Vector3(-0.35, 0.1, 0.55));

    const tsuka = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.06, 0.68, 12), secondaryMat);
    tsuka.position.set(-0.26, -0.88, 0);
    tsuka.rotation.z = -0.22;
    addExplodablePart(root, tsuka, new THREE.Vector3(-0.45, -0.55, 0));

    const pillarL = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.075, 1.9, 10), secondaryMat);
    pillarL.position.set(-0.85, -0.35, -0.35);
    addExplodablePart(root, pillarL, new THREE.Vector3(-0.8, 0, -0.5));

    const pillarR = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.075, 1.9, 10), secondaryMat);
    pillarR.position.set(0.85, -0.35, -0.35);
    addExplodablePart(root, pillarR, new THREE.Vector3(0.8, 0, -0.5));

    const toriiTop = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.12, 0.18), accentMat);
    toriiTop.position.set(0, 0.65, -0.35);
    addExplodablePart(root, toriiTop, new THREE.Vector3(0, 0.95, -0.5));

    const crystalOrb = new THREE.Mesh(new THREE.OctahedronGeometry(0.28, 1), glassMat);
    crystalOrb.position.set(0.65, 0.1, 0.45);
    addExplodablePart(root, crystalOrb, new THREE.Vector3(0.95, 0.4, 0.7));
  } else if (modelId === 'valkyrie-kitsune-mask') {
    const maskFace = new THREE.Mesh(new THREE.ConeGeometry(0.85, 1.25, 6), primaryMat);
    maskFace.rotation.x = Math.PI / 2;
    maskFace.scale.set(0.85, 0.65, 1.15);
    maskFace.position.set(0, 0.28, 0.15);
    maskFace.castShadow = true;
    addExplodablePart(root, maskFace, new THREE.Vector3(0, 0.15, 0.7));

    const brow = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.18, 0.45), secondaryMat);
    brow.position.set(0, 0.56, 0.35);
    addExplodablePart(root, brow, new THREE.Vector3(0, 0.55, 0.95));

    const earL = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.85, 5), accentMat);
    earL.position.set(-0.48, 1.12, 0.05);
    earL.rotation.z = 0.28;
    addExplodablePart(root, earL, new THREE.Vector3(-0.7, 0.95, 0));

    const earR = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.85, 5), accentMat);
    earR.position.set(0.48, 1.12, 0.05);
    earR.rotation.z = -0.28;
    addExplodablePart(root, earR, new THREE.Vector3(0.7, 0.95, 0));

    const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.08, 0.12), glassMat);
    eyeL.position.set(-0.24, 0.36, 0.68);
    eyeL.rotation.z = -0.25;
    addExplodablePart(root, eyeL, new THREE.Vector3(-0.4, 0.3, 1.1));

    const eyeR = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.08, 0.12), glassMat);
    eyeR.position.set(0.24, 0.36, 0.68);
    eyeR.rotation.z = 0.25;
    addExplodablePart(root, eyeR, new THREE.Vector3(0.4, 0.3, 1.1));

    const halo = new THREE.Mesh(new THREE.TorusGeometry(1.18, 0.04, 14, 56), accentMat);
    halo.position.set(0, 0.45, -0.45);
    addExplodablePart(root, halo, new THREE.Vector3(0, 0.4, -1.0));
  } else if (modelId === 'solstice-sky-citadel') {
    const cliff = new THREE.Mesh(new THREE.ConeGeometry(1.18, 1.25, 7), secondaryMat);
    cliff.rotation.x = Math.PI;
    cliff.position.set(0, -0.58, 0);
    addExplodablePart(root, cliff, new THREE.Vector3(0, -0.5, 0));

    const tier1 = new THREE.Mesh(new THREE.CylinderGeometry(1.18, 1.12, 0.22, 8), primaryMat);
    tier1.position.set(0, 0.08, 0);
    addExplodablePart(root, tier1, new THREE.Vector3(0, 0.1, 0));

    const tier2 = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.48, 0.92), primaryMat);
    tier2.position.set(0, 0.42, 0);
    addExplodablePart(root, tier2, new THREE.Vector3(0, 0.45, 0));

    const roof1 = new THREE.Mesh(new THREE.ConeGeometry(0.95, 0.36, 4), accentMat);
    roof1.rotation.y = Math.PI / 4;
    roof1.position.set(0, 0.78, 0);
    addExplodablePart(root, roof1, new THREE.Vector3(0, 0.85, 0));

    const tier3 = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.4, 0.56), secondaryMat);
    tier3.position.set(0, 1.05, 0);
    addExplodablePart(root, tier3, new THREE.Vector3(0, 1.15, 0));

    const spire = new THREE.Mesh(new THREE.ConeGeometry(0.52, 0.65, 4), glassMat);
    spire.rotation.y = Math.PI / 4;
    spire.position.set(0, 1.52, 0);
    addExplodablePart(root, spire, new THREE.Vector3(0, 1.65, 0));

    const orbital = new THREE.Mesh(new THREE.TorusGeometry(1.42, 0.03, 12, 60), accentMat);
    orbital.rotation.set(Math.PI / 2.4, 0.3, 0);
    orbital.position.set(0, 0.55, 0);
    addExplodablePart(root, orbital, new THREE.Vector3(0, 0.8, 0.6));
  } else if (modelId === 'seraphim-resonance-prism') {
    const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.46, 0), glassMat);
    core.scale.set(0.85, 1.6, 0.85);
    core.position.set(0, 0.35, 0);
    addExplodablePart(root, core, new THREE.Vector3(0, 0.2, 0));

    const cage = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.04, 12, 48), primaryMat);
    cage.position.set(0, 0.35, 0);
    addExplodablePart(root, cage, new THREE.Vector3(0, 0.25, 0.7));

    for (let i = 0; i < 6; i++) {
      const side = i < 3 ? -1 : 1;
      const idx = i % 3;
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.18, 0.08), i % 2 === 0 ? accentMat : secondaryMat);
      blade.position.set(side * (0.9 + idx * 0.14), 0.72 - idx * 0.34, -0.15);
      blade.rotation.z = side * (0.45 - idx * 0.25);
      addExplodablePart(root, blade, new THREE.Vector3(side * 1.15, (1 - idx) * 0.45, -0.35));
    }
  } else {
    // chronos-dimensional-eye (default flagship)
    const outerAstrolabe = new THREE.Mesh(new THREE.TorusGeometry(1.22, 0.07, 16, 64), primaryMat);
    outerAstrolabe.position.set(0, 0.3, 0);
    addExplodablePart(root, outerAstrolabe, new THREE.Vector3(0, 0.3, 0.6));

    const midRing = new THREE.Mesh(new THREE.TorusGeometry(0.96, 0.04, 14, 56), accentMat);
    midRing.position.set(0, 0.3, 0);
    midRing.rotation.y = Math.PI / 5;
    addExplodablePart(root, midRing, new THREE.Vector3(0, 0.3, -0.6));

    const runicPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(2.3, 2.3),
      new THREE.MeshBasicMaterial({ map: runicTex, transparent: true, opacity: 0.7, side: THREE.DoubleSide, depthWrite: false })
    );
    runicPlane.position.set(0, 0.3, -0.08);
    addExplodablePart(root, runicPlane, new THREE.Vector3(0, 0.3, -0.9));

    const iris = new THREE.Mesh(new THREE.OctahedronGeometry(0.48, 2), glassMat);
    iris.scale.set(1.15, 0.8, 0.58);
    iris.position.set(0, 0.3, 0);
    addExplodablePart(root, iris, new THREE.Vector3(0, 0.3, 0));

    const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.18, 24, 24), secondaryMat);
    pupil.position.set(0, 0.3, 0.22);
    addExplodablePart(root, pupil, new THREE.Vector3(0, 0.3, 0.8));

    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.07, 0.85, 6), secondaryMat);
      pillar.position.set(Math.cos(a) * 1.1, -0.65, Math.sin(a) * 1.1);
      addExplodablePart(root, pillar, new THREE.Vector3(Math.cos(a) * 0.8, -0.2, Math.sin(a) * 0.8));
    }
  }

  return root;
}

export function AnimeModelViewer({
  model,
  heightClass = 'h-[540px]',
  compactControls = false,
}: AnimeModelViewerProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [materialPreset, setMaterialPreset] = useState<MaterialPreset>(model.materialPreset);
  const [explodeFactor, setExplodeFactor] = useState(0);
  const [autoRotate, setAutoRotate] = useState(true);
  const [wireframe, setWireframe] = useState(false);
  const [controlsCollapsed, setControlsCollapsed] = useState(compactControls);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [customModelLoading, setCustomModelLoading] = useState(false);
  const [customModelError, setCustomModelError] = useState<string | null>(null);
  const [webglFallback, setWebglFallback] = useState(false);

  const stateRef = useRef({
    explodeTarget: 0,
    explodeCurrent: 0,
    autoRotate: true,
    wireframe: false,
    materialPreset: model.materialPreset as MaterialPreset,
    cameraTargetPos: null as THREE.Vector3 | null,
    cameraTargetLook: null as THREE.Vector3 | null,
  });

  const sceneControllerRef = useRef<{
    rebuildModel: (modelId: string, preset: MaterialPreset, wire: boolean) => void;
    loadGlbFile: (file: File) => void;
    requestRender: () => void;
    setCameraPreset: (preset: CameraPreset) => void;
  } | null>(null);

  useEffect(() => {
    setMaterialPreset(model.materialPreset);
    setExplodeFactor(0);
    stateRef.current.explodeTarget = 0;
    stateRef.current.materialPreset = model.materialPreset;
    sceneControllerRef.current?.rebuildModel(model.id, model.materialPreset, stateRef.current.wireframe);
  }, [model.id, model.materialPreset]);

  useEffect(() => {
    stateRef.current.explodeTarget = explodeFactor;
    sceneControllerRef.current?.requestRender();
  }, [explodeFactor]);

  useEffect(() => {
    stateRef.current.autoRotate = autoRotate;
    sceneControllerRef.current?.requestRender();
  }, [autoRotate]);

  useEffect(() => {
    stateRef.current.wireframe = wireframe;
    stateRef.current.materialPreset = materialPreset;
    sceneControllerRef.current?.rebuildModel(model.id, materialPreset, wireframe);
  }, [materialPreset, wireframe, model.id]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    if (!isWebGLAvailable()) {
      setWebglFallback(true);
      return;
    }

    const isSoftwareGl = detectSoftwareGl();
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (isSoftwareGl || reducedMotion) {
      setAutoRotate(false);
      stateRef.current.autoRotate = false;
    }

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 540;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a18);
    scene.fog = new THREE.FogExp2(0x0a0a18, 0.095);

    const camera = new THREE.PerspectiveCamera(44, width / height, 0.1, 100);
    camera.position.set(...CAMERA_PRESETS.hero.pos);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    const envTex = createStudioEnvironment(renderer);
    scene.environment = envTex;

    const bumpTex = createSurfaceMicroTexture(renderer);
    const runicTex = createRunicRingTexture(renderer);
    const shadowTex = createContactShadowTexture();

    const hemiLight = new THREE.HemisphereLight(0x43b8ff, 0x10101f, 0.7);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff6ed, 2.0);
    keyLight.position.set(4.5, 6.5, 5);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.left = -4;
    keyLight.shadow.camera.right = 4;
    keyLight.shadow.camera.top = 4;
    keyLight.shadow.camera.bottom = -4;
    keyLight.shadow.bias = -0.0005;
    scene.add(keyLight);

    const rimLight = new THREE.PointLight(0x9b5cff, 6.5, 18, 1.6);
    rimLight.position.set(-3.5, 2.2, -3.5);
    scene.add(rimLight);

    const fillLight = new THREE.PointLight(0x43b8ff, 4.5, 16, 1.6);
    fillLight.position.set(3.2, -0.5, 3.0);
    scene.add(fillLight);

    // Studio floor + contact shadow disc (offset to prevent Z-fighting)
    const floor = new THREE.Mesh(
      new THREE.CircleGeometry(28, 48),
      new THREE.MeshStandardMaterial({ color: 0x0b0b19, roughness: 0.78, metalness: 0.15 })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -1.58;
    floor.receiveShadow = true;
    scene.add(floor);

    const contactShadow = new THREE.Mesh(
      new THREE.CircleGeometry(2.3, 32),
      new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false, opacity: 0.65 })
    );
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.y = -1.555;
    scene.add(contactShadow);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(...CAMERA_PRESETS.hero.target);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.minDistance = 2.0;
    controls.maxDistance = 11.0;
    controls.maxPolarAngle = Math.PI / 1.95;

    let activeGroup: THREE.Group | null = null;
    let disposed = false;
    let rafId = 0;
    let timerId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let prevTime = performance.now();

    const makeMaterials = (preset: MaterialPreset, wire: boolean) => {
      if (preset === 'chrome') {
        return {
          primary: new THREE.MeshPhysicalMaterial({ color: 0xd8dcff, metalness: 0.94, roughness: 0.16, clearcoat: 1, wireframe: wire }),
          secondary: new THREE.MeshStandardMaterial({ color: 0x1c1c36, metalness: 0.6, roughness: 0.65, bumpMap: bumpTex, bumpScale: 0.02, wireframe: wire }),
          accent: new THREE.MeshStandardMaterial({ color: 0x43b8ff, emissive: 0x43b8ff, emissiveIntensity: 1.4, roughness: 0.22, metalness: 0.3, wireframe: wire }),
          glass: new THREE.MeshPhysicalMaterial({ color: 0x9b5cff, emissive: 0x5126a8, emissiveIntensity: 0.6, roughness: 0.1, transmission: isSoftwareGl ? 0 : 0.85, transparent: true, opacity: isSoftwareGl ? 0.55 : 0.95, wireframe: wire }),
        };
      }
      if (preset === 'hologram') {
        return {
          primary: new THREE.MeshStandardMaterial({ color: 0x43b8ff, emissive: 0x1b4e8c, emissiveIntensity: 0.75, roughness: 0.25, metalness: 0.4, transparent: true, opacity: 0.72, wireframe: wire }),
          secondary: new THREE.MeshStandardMaterial({ color: 0x9b5cff, emissive: 0x5126a8, emissiveIntensity: 0.7, roughness: 0.5, metalness: 0.2, transparent: true, opacity: 0.78, wireframe: wire }),
          accent: new THREE.MeshStandardMaterial({ color: 0xf5f3ff, emissive: 0x43b8ff, emissiveIntensity: 1.8, roughness: 0.15, wireframe: wire }),
          glass: new THREE.MeshStandardMaterial({ color: 0x9b5cff, emissive: 0x9b5cff, emissiveIntensity: 1.2, transparent: true, opacity: 0.5, wireframe: wire }),
        };
      }
      if (preset === 'sakura') {
        return {
          primary: new THREE.MeshPhysicalMaterial({ color: 0xf5e9ff, metalness: 0.2, roughness: 0.25, clearcoat: 1, wireframe: wire }),
          secondary: new THREE.MeshStandardMaterial({ color: 0x2a1b4a, metalness: 0.55, roughness: 0.62, bumpMap: bumpTex, bumpScale: 0.02, wireframe: wire }),
          accent: new THREE.MeshStandardMaterial({ color: 0x9b5cff, emissive: 0x9b5cff, emissiveIntensity: 1.3, roughness: 0.22, wireframe: wire }),
          glass: new THREE.MeshPhysicalMaterial({ color: 0x43b8ff, emissive: 0x43b8ff, emissiveIntensity: 0.8, roughness: 0.12, transparent: true, opacity: 0.78, wireframe: wire }),
        };
      }
      return {
        primary: new THREE.MeshPhysicalMaterial({ color: 0x181830, metalness: 0.75, roughness: 0.24, clearcoat: 0.8, bumpMap: bumpTex, bumpScale: 0.02, wireframe: wire }),
        secondary: new THREE.MeshStandardMaterial({ color: 0x2b2556, metalness: 0.35, roughness: 0.68, wireframe: wire }),
        accent: new THREE.MeshStandardMaterial({ color: 0x9b5cff, emissive: 0x9b5cff, emissiveIntensity: 1.4, roughness: 0.2, metalness: 0.35, wireframe: wire }),
        glass: new THREE.MeshPhysicalMaterial({ color: 0x43b8ff, emissive: 0x43b8ff, emissiveIntensity: 0.85, roughness: 0.1, transmission: isSoftwareGl ? 0 : 0.8, transparent: true, opacity: isSoftwareGl ? 0.58 : 0.92, wireframe: wire }),
      };
    };

    const rebuildModel = (modelId: string, preset: MaterialPreset, wire: boolean) => {
      if (activeGroup) {
        scene.remove(activeGroup);
      }
      const mats = makeMaterials(preset, wire);
      activeGroup = buildCompositeAnimeModel(modelId, mats.primary, mats.secondary, mats.accent, mats.glass, runicTex);
      scene.add(activeGroup);
      requestRender();
    };

    const stepScene = (dt: number): boolean => {
      let needsAnotherFrame = false;

      if (activeGroup) {
        const expDiff = Math.abs(stateRef.current.explodeCurrent - stateRef.current.explodeTarget);
        if (expDiff > 0.001) {
          stateRef.current.explodeCurrent = THREE.MathUtils.damp(
            stateRef.current.explodeCurrent,
            stateRef.current.explodeTarget,
            7,
            dt
          );
          activeGroup.children.forEach((child) => {
            const base = child.userData.basePos as THREE.Vector3 | undefined;
            const dir = child.userData.explodeDir as THREE.Vector3 | undefined;
            if (base && dir) {
              child.position.copy(base).addScaledVector(dir, stateRef.current.explodeCurrent);
            }
          });
          needsAnotherFrame = true;
        }
        if (stateRef.current.autoRotate && !isSoftwareGl && !reducedMotion) {
          activeGroup.rotation.y += dt * 0.45;
          needsAnotherFrame = true;
        }
      }

      if (stateRef.current.cameraTargetPos && stateRef.current.cameraTargetLook) {
        camera.position.lerp(stateRef.current.cameraTargetPos, 1 - Math.exp(-6 * dt));
        controls.target.lerp(stateRef.current.cameraTargetLook, 1 - Math.exp(-6 * dt));
        if (
          camera.position.distanceTo(stateRef.current.cameraTargetPos) < 0.02 &&
          controls.target.distanceTo(stateRef.current.cameraTargetLook) < 0.02
        ) {
          stateRef.current.cameraTargetPos = null;
          stateRef.current.cameraTargetLook = null;
        } else {
          needsAnotherFrame = true;
        }
      }

      controls.update();
      return needsAnotherFrame;
    };

    const requestRender = () => {
      if (disposed) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      rafId = requestAnimationFrame(() => {
        if (disposed) return;
        renderDirty = false;
        const now = performance.now();
        const dt = Math.min((now - prevTime) / 1000, 0.08) || 0.016;
        prevTime = now;
        const more = stepScene(dt);
        renderer.render(scene, camera);
        const done = () => {
          renderBusy = false;
          if (renderDirty || more) requestRender();
        };
        if (isSoftwareGl) {
          afterDraw(renderer, done, (id) => {
            timerId = id;
          });
        } else {
          done();
        }
      });
    };

    controls.addEventListener('change', requestRender);
    controls.addEventListener('start', () => {
      stateRef.current.cameraTargetPos = null;
      stateRef.current.cameraTargetLook = null;
    });

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || 800;
      const h = container.clientHeight || 540;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    };
    window.addEventListener('resize', onResize);

    const onContextLost = (ev: Event) => {
      ev.preventDefault();
      setWebglFallback(true);
    };
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);

    sceneControllerRef.current = {
      rebuildModel,
      requestRender,
      setCameraPreset: (preset) => {
        const cfg = CAMERA_PRESETS[preset];
        stateRef.current.cameraTargetPos = new THREE.Vector3(...cfg.pos);
        stateRef.current.cameraTargetLook = new THREE.Vector3(...cfg.target);
        requestRender();
      },
      loadGlbFile: (file: File) => {
        setCustomModelLoading(true);
        setCustomModelError(null);
        const url = URL.createObjectURL(file);
        const loader = new GLTFLoader();
        loader.load(
          url,
          (gltf) => {
            URL.revokeObjectURL(url);
            if (activeGroup) scene.remove(activeGroup);
            const box = new THREE.Box3().setFromObject(gltf.scene);
            const size = box.getSize(new THREE.Vector3());
            const maxDim = Math.max(size.x, size.y, size.z) || 1;
            const scale = 2.4 / maxDim;
            gltf.scene.scale.setScalar(scale);
            const center = box.getCenter(new THREE.Vector3());
            gltf.scene.position.set(-center.x * scale, -box.min.y * scale - 1.55, -center.z * scale);
            activeGroup = new THREE.Group();
            activeGroup.add(gltf.scene);
            scene.add(activeGroup);
            setCustomModelLoading(false);
            requestRender();
          },
          undefined,
          () => {
            URL.revokeObjectURL(url);
            setCustomModelLoading(false);
            setCustomModelError('Could not parse .glb/.gltf file. Showing procedural showcase model instead.');
          }
        );
      },
    };

    rebuildModel(model.id, stateRef.current.materialPreset, stateRef.current.wireframe);
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    return () => {
      disposed = true;
      cancelAnimationFrame(rafId);
      clearTimeout(timerId);
      window.removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      controls.dispose();
      envTex.dispose();
      bumpTex.dispose();
      runicTex.dispose();
      shadowTex.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [model.id]);

  return (
    <div
      className={`relative w-full overflow-hidden rounded-xl border border-[#9B5CFF]/20 bg-[#0A0A18] ${
        isFullscreen ? 'fixed inset-0 z-50 h-screen rounded-none' : heightClass
      }`}
    >
      {webglFallback ? (
        <div className="relative h-full w-full flex flex-col items-center justify-center p-6 text-center">
          <img
            src={model.previewImage}
            alt={model.title}
            referrerPolicy="no-referrer"
            className="absolute inset-0 h-full w-full object-cover opacity-40"
          />
          <div className="relative z-10 max-w-md rounded-xl bg-[#080812]/90 p-6 border border-[#9B5CFF]/30">
            <h3 className="font-display text-xl font-semibold text-[#F5F3FF]">{model.title}</h3>
            <p className="mt-2 text-sm text-[#AAA7BC]">
              WebGL hardware context is unavailable on this browser session. Displaying high-resolution reference render.
            </p>
          </div>
        </div>
      ) : (
        <div ref={mountRef} data-testid="model-3d-canvas" className="h-full w-full" />
      )}

      {/* Minimal Top-Left Title Badge (solid/rgba surface, no backdrop-blur over WebGL) */}
      <div className="pointer-events-none absolute top-4 left-4 z-10 rounded-lg border border-white/10 bg-[#080812]/85 px-3.5 py-2">
        <div className="text-xs font-medium text-[#43B8FF]">{model.category}</div>
        <div className="font-display text-sm font-semibold text-[#F5F3FF]">{model.title}</div>
      </div>

      {/* Top-Right Fullscreen & GLB Upload Action */}
      <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
        <input
          ref={fileInputRef}
          type="file"
          accept=".glb,.gltf"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) sceneControllerRef.current?.loadGlbFile(f);
          }}
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#080812]/90 px-3 py-2 text-xs font-medium text-[#F5F3FF] hover:border-[#9B5CFF] transition-colors whitespace-nowrap shrink-0"
        >
          <Upload className="h-3.5 w-3.5 text-[#43B8FF]" />
          Load GLB/GLTF
        </button>
        <button
          type="button"
          onClick={() => setIsFullscreen((v) => !v)}
          aria-label={isFullscreen ? 'Exit fullscreen 3D view' : 'Enter fullscreen 3D view'}
          className="inline-flex items-center justify-center rounded-lg border border-white/15 bg-[#080812]/90 p-2 text-[#F5F3FF] hover:border-[#9B5CFF] transition-colors"
        >
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </button>
      </div>

      {customModelLoading && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-[#080812]/80">
          <div className="rounded-lg border border-[#9B5CFF]/40 bg-[#10101F] px-5 py-3 text-sm text-[#F5F3FF]">
            Loading 3D GLB/GLTF geometry...
          </div>
        </div>
      )}

      {customModelError && (
        <div className="absolute top-16 right-4 z-20 rounded-lg border border-amber-500/40 bg-[#10101F] px-3 py-2 text-xs text-amber-200">
          {customModelError}
        </div>
      )}

      {/* Collapsible Unified Bottom Control Dock */}
      <div className="pointer-events-none absolute inset-x-0 bottom-3 z-10 flex flex-col items-center px-3">
        <button
          type="button"
          onClick={() => setControlsCollapsed((v) => !v)}
          className="pointer-events-auto mb-1.5 inline-flex items-center gap-1.5 rounded-md border border-white/15 bg-[#080812]/90 px-3 py-1 text-xs font-medium text-[#AAA7BC] hover:text-[#F5F3FF] transition-colors"
        >
          {controlsCollapsed ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
          {controlsCollapsed ? 'Show Controls' : 'Hide Controls'}
        </button>

        {!controlsCollapsed && (
          <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-3 rounded-xl border border-white/15 bg-[#080812]/92 px-4 py-2.5 max-w-[94vw]">
            <div className="flex items-center gap-1">
              {(['obsidian', 'chrome', 'hologram', 'sakura'] as MaterialPreset[]).map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setMaterialPreset(preset)}
                  className={`rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors whitespace-nowrap shrink-0 ${
                    materialPreset === preset
                      ? 'bg-[#9B5CFF] text-[#080812]'
                      : 'bg-[#10101F] text-[#AAA7BC] hover:text-[#F5F3FF]'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>

            <label className="flex items-center gap-2 text-xs text-[#AAA7BC]">
              <span className="whitespace-nowrap">Explode</span>
              <input
                type="range"
                min={0}
                max={1}
                step={0.02}
                value={explodeFactor}
                onChange={(e) => setExplodeFactor(Number(e.target.value))}
                aria-label="Exploded view separation"
                className="w-20 accent-[#43B8FF]"
              />
            </label>

            <div className="flex items-center gap-1">
              {(['hero', 'front', 'top', 'closeup'] as CameraPreset[]).map((cam) => (
                <button
                  key={cam}
                  type="button"
                  onClick={() => sceneControllerRef.current?.setCameraPreset(cam)}
                  className="rounded-md bg-[#10101F] px-2.5 py-1 text-xs font-medium capitalize text-[#AAA7BC] hover:text-[#F5F3FF] transition-colors whitespace-nowrap shrink-0"
                >
                  {cam}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setAutoRotate((v) => !v)}
              className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                autoRotate ? 'bg-[#43B8FF]/20 text-[#43B8FF]' : 'bg-[#10101F] text-[#AAA7BC]'
              }`}
            >
              <RotateCw className="h-3.5 w-3.5" />
              Spin
            </button>

            <button
              type="button"
              onClick={() => setWireframe((v) => !v)}
              className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                wireframe ? 'bg-[#9B5CFF]/25 text-[#F5F3FF]' : 'bg-[#10101F] text-[#AAA7BC]'
              }`}
            >
              <Sparkles className="h-3.5 w-3.5" />
              Mesh
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
