import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Star } from 'lucide-react';
import type { AnimeSummary } from '../types/anime';
import { buildAnimeUrl } from '../lib/validation';
import { useAuth } from '../context/AuthContext';

export function AnimeCard({ anime }: { anime: AnimeSummary }) {
  const { isFavorited, toggleFavorite } = useAuth();
  const [imgError, setImgError] = useState(false);
  const [busy, setBusy] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const fav = isFavorited('anime', String(anime.id));
  const detailUrl = buildAnimeUrl(anime.id, anime.displayTitle);
  const coverSrc = anime.coverImage.extraLarge || anime.coverImage.large || '';
  const scoreOutOfTen = anime.averageScore ? (anime.averageScore / 10).toFixed(1) : null;

  const handleFavorite = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (busy) return;
    setBusy(true);
    setFeedbackMsg(null);
    try {
      const saved = await toggleFavorite({
        itemType: 'anime',
        itemId: String(anime.id),
        title: anime.displayTitle,
        imageUrl: coverSrc,
        subtitle: [anime.format, anime.seasonYear].filter(Boolean).join(' · '),
      });
      setFeedbackMsg(saved ? 'Saved to favorites.' : 'Removed from favorites.');
      setTimeout(() => setFeedbackMsg(null), 2500);
    } catch (err) {
      setFeedbackMsg(err instanceof Error ? err.message : 'Sign in required');
      setTimeout(() => setFeedbackMsg(null), 3200);
    } finally {
      setBusy(false);
    }
  };

  return (
    <article className="group relative flex flex-col rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 overflow-hidden transition-all duration-200 hover:-translate-y-1 hover:border-[#6D38E8]/55 dark:hover:border-[#9B5CFF]/55 shadow-xs">
      <Link to={detailUrl} className="relative block aspect-[3/4] w-full overflow-hidden bg-[var(--aw-surface-elevated)]">
        {coverSrc && !imgError ? (
          <img
            src={coverSrc}
            alt={anime.displayTitle}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-[#5126A8]/30 via-[var(--aw-surface-elevated)] to-[#43B8FF]/20 p-4 text-center">
            <span className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] line-clamp-3">
              {anime.displayTitle}
            </span>
          </div>
        )}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-[#080812]/70 via-[#080812]/20 to-transparent" />
      </Link>

      <button
        type="button"
        onClick={handleFavorite}
        aria-label={fav ? `Remove ${anime.displayTitle} from favorites` : `Save ${anime.displayTitle} to favorites`}
        className={`absolute top-2.5 right-2.5 z-10 flex h-9 w-9 items-center justify-center rounded-lg border transition-colors ${
          fav
            ? 'border-[#9B5CFF] bg-[#5126A8]/90 text-[#F5F3FF]'
            : 'border-white/20 bg-[#080812]/75 text-white/85 hover:text-white'
        }`}
      >
        <Heart className={`h-4 w-4 ${fav ? 'fill-current' : ''}`} />
      </button>

      {feedbackMsg && (
        <div className="absolute inset-x-2 top-13 z-20 rounded-md bg-white dark:bg-[#080812] px-2.5 py-1.5 text-[11px] text-[#141229] dark:text-[#F5F3FF] border border-[#6D38E8]/40 dark:border-[#9B5CFF]/40 shadow-md">
          {feedbackMsg}
        </div>
      )}

      <div className="flex flex-1 flex-col justify-between p-3.5">
        <div>
          <Link to={detailUrl} className="block">
            <h3 className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] line-clamp-2 group-hover:text-[#0284C7] dark:group-hover:text-[#43B8FF] transition-colors">
              {anime.displayTitle}
            </h3>
          </Link>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
            {anime.format && <span>{anime.format}</span>}
            {anime.format && anime.seasonYear && <span aria-hidden="true">·</span>}
            {anime.seasonYear && <span className="font-mono-tabular">{anime.seasonYear}</span>}
            {scoreOutOfTen && (
              <>
                <span aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1 font-mono-tabular text-[#0284C7] dark:text-[#43B8FF]">
                  <Star className="h-3 w-3 fill-current" />
                  {scoreOutOfTen}
                </span>
              </>
            )}
          </div>
        </div>

        {anime.genres.length > 0 && (
          <p className="mt-2.5 truncate text-xs text-[#524E6B]/85 dark:text-[#AAA7BC]/80">
            {anime.genres.slice(0, 3).join(' · ')}
          </p>
        )}
      </div>
    </article>
  );
}
