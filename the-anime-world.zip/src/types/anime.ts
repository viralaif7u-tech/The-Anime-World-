export type ItemType = 'anime' | 'character' | 'wallpaper' | 'model3d' | 'animation';

export interface AnimeSummary {
  id: number;
  slug: string;
  title: {
    english: string | null;
    romaji: string;
    native: string | null;
  };
  displayTitle: string;
  coverImage: {
    extraLarge: string | null;
    large: string | null;
    color: string | null;
  };
  bannerImage: string | null;
  format: string | null;
  status: string | null;
  episodes: number | null;
  duration: number | null;
  season: string | null;
  seasonYear: number | null;
  averageScore: number | null;
  popularity: number | null;
  genres: string[];
  countryOfOrigin: string | null;
  source: string | null;
  studios: string[];
  synopsis: string;
  nextAiringEpisode?: {
    episode: number;
    airingAt: number;
  } | null;
}

export interface AnimeCharacterRef {
  id: number;
  name: string;
  nativeName: string | null;
  role: string;
  image: string | null;
  voiceActor?: {
    id: number;
    name: string;
    language: string;
    image: string | null;
  } | null;
}

export interface AnimeStaffRef {
  id: number;
  name: string;
  role: string;
  image: string | null;
}

export interface AnimeDetail extends AnimeSummary {
  synonyms: string[];
  trailer: {
    id: string;
    site: string;
    thumbnail: string | null;
  } | null;
  characters: AnimeCharacterRef[];
  staff: AnimeStaffRef[];
  relations: Array<{
    relationType: string;
    media: AnimeSummary;
  }>;
  recommendations: AnimeSummary[];
  externalSource: 'AniList' | 'Jikan' | 'Catalog';
}

export interface CharacterSummary {
  id: number;
  name: string;
  nativeName: string | null;
  image: string | null;
  favourites: number;
  description: string;
  media: Array<{
    id: number;
    title: string;
    coverImage: string | null;
    format: string | null;
  }>;
}

export interface WallpaperItem {
  id: string;
  title: string;
  artist: string;
  category:
    | '4K Anime'
    | '2K'
    | 'Full HD'
    | 'Mobile'
    | 'Desktop'
    | 'Dark'
    | 'Aesthetic'
    | 'Fantasy'
    | 'Landscape'
    | 'Minimal'
    | 'Cyberpunk'
    | 'AI Artwork';
  resolution: '3840x2160' | '2560x1440' | '1920x1080' | '1440x2560' | '2160x3840';
  orientation: 'landscape' | 'portrait';
  imageUrl: string;
  tags: string[];
  likes: number;
  downloads: number;
  license: string;
  description: string;
}

export interface Model3DItem {
  id: string;
  title: string;
  category: 'Character Sculpture' | 'Mecha Frame' | 'Dimensional Relic' | 'Floating Citadel' | 'Weapon Artifact';
  artist: string;
  description: string;
  partsCount: number;
  materialPreset: 'obsidian' | 'chrome' | 'hologram' | 'sakura';
  accentColor: string;
  secondaryColor: string;
  previewImage: string;
  specs: {
    architecture: string;
    lightingRig: string;
    interactiveFeatures: string[];
  };
  likes: number;
}

export interface AnimationItem {
  id: string;
  title: string;
  creator: string;
  category: 'Motion Artwork' | 'Animated Wallpaper' | 'Short Cinematic' | 'Shader Loop' | 'Authorized Trailer';
  durationLabel: string;
  resolution: string;
  previewImage: string;
  mode: 'procedural-portal' | 'procedural-sakura' | 'procedural-cyber' | 'youtube-embed';
  youtubeId?: string;
  description: string;
  views: number;
  likes: number;
}

export interface DiscoverParams {
  category?: string;
  search?: string;
  genre?: string;
  year?: string;
  season?: string;
  country?: string;
  format?: string;
  status?: string;
  sort?: string;
  page?: number;
  perPage?: number;
}

export interface DiscoverResponse {
  items: AnimeSummary[];
  pageInfo: {
    total: number;
    currentPage: number;
    lastPage: number;
    hasNextPage: boolean;
    perPage: number;
  };
  source: 'AniList GraphQL API' | 'Jikan REST API' | 'Cached Archive';
}

export interface PublicProfile {
  uid: string;
  username: string;
  displayName: string;
  bio?: string;
  avatarUrl?: string;
  coverUrl?: string;
  isPublic: boolean;
  role: 'user' | 'creator' | 'admin';
  isSuspended: boolean;
  followersCount: number;
  followingCount: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface PrivateUser {
  uid: string;
  email: string;
  fullName: string;
  favoriteGenres?: string[];
  newsletterOptIn?: boolean;
  themePreference?: 'dark' | 'light';
  saveDownloadHistory?: boolean;
  hideViewingActivity?: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface FavoriteRecord {
  id: string;
  userId: string;
  itemId: string;
  itemType: ItemType;
  title: string;
  imageUrl?: string;
  subtitle?: string;
  createdAt?: unknown;
}

export interface CollectionRecord {
  id: string;
  userId: string;
  name: string;
  description?: string;
  isPublic: boolean;
  itemsCount: number;
  coverImage?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface CollectionItemRecord {
  id: string;
  collectionId: string;
  userId: string;
  isCollectionPublic: boolean;
  itemId: string;
  itemType: ItemType;
  title: string;
  imageUrl?: string;
  addedAt?: unknown;
}

export interface CommunityArtworkRecord {
  id: string;
  authorId: string;
  authorName: string;
  authorUsername: string;
  title: string;
  description?: string;
  category: 'Wallpaper' | 'Illustration' | '3D Render' | 'Motion' | 'Character Fanart';
  imageUrl: string;
  likesCount: number;
  isFeatured: boolean;
  status: 'published' | 'flagged' | 'removed';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface FeedbackRecord {
  id: string;
  userId: string;
  name: string;
  email: string;
  category: 'Bug Report' | 'Website Suggestion' | 'Content Request' | 'Technical Issue' | 'General Feedback';
  subject: string;
  message: string;
  rating: number;
  status: 'open' | 'in_review' | 'resolved';
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface NotificationRecord {
  id: string;
  userId: string;
  type: 'content' | 'follower' | 'like' | 'comment' | 'announcement' | 'alert';
  title: string;
  message: string;
  link?: string;
  isRead: boolean;
  createdAt?: unknown;
}

export interface SiteConfigRecord {
  id: string;
  title: string;
  message?: string;
  bannerUrl?: string;
  isPublished: boolean;
  updatedAt?: unknown;
}

export type DownloadStatus = 'downloading' | 'completed' | 'failed';

export interface DownloadRecord {
  id: string;
  userId: string;
  videoId: string;
  title: string;
  thumbnailUrl?: string;
  format: 'MP4';
  fileSizeBytes: number;
  downloadedBytes: number;
  status: DownloadStatus;
  saveLocation?: string;
  errorMessage?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}
