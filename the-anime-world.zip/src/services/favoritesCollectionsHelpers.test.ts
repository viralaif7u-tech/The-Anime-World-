import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildCollectionDocId,
  buildCollectionItemDocId,
  buildFavoriteDocId,
  formatFriendlyFirestoreMessage,
  validateCollectionItemPayload,
  validateCollectionPayload,
  validateFavoritePayload,
} from './favoritesCollectionsHelpers';

test('buildFavoriteDocId produces deterministic rules-compliant IDs', () => {
  const id = buildFavoriteDocId('user123', 'anime', '154587/frieren');
  assert.equal(id, 'user123_anime_154587_frieren');
  assert.match(id, /^[a-zA-Z0-9_-]+$/);
  assert.ok(id.length <= 128);
});

test('validateFavoritePayload accepts valid anime favorite and trims volumetric bounds', () => {
  const res = validateFavoritePayload('uid_abc_1', {
    itemType: 'anime',
    itemId: '154587',
    title: '  Frieren: Beyond Journey’s End  ',
    imageUrl: 'https://example.com/poster.jpg',
    subtitle: 'TV · 2023',
  });
  assert.equal(res.valid, true);
  if (res.valid) {
    assert.equal(res.favoriteId, 'uid_abc_1_anime_154587');
    assert.equal(res.payload.title, 'Frieren: Beyond Journey’s End');
    assert.equal(res.payload.userId, 'uid_abc_1');
  }
});

test('validateFavoritePayload rejects missing userId or empty title cleanly', () => {
  const noUser = validateFavoritePayload('', {
    itemType: 'anime',
    itemId: '1',
    title: 'One Piece',
  });
  assert.equal(noUser.valid, false);

  const noTitle = validateFavoritePayload('uid_1', {
    itemType: 'anime',
    itemId: '1',
    title: '   ',
  });
  assert.equal(noTitle.valid, false);
});

test('validateCollectionPayload creates deterministic ID and rejects >100 char names', () => {
  const ok = validateCollectionPayload(
    'user_999',
    {
      name: 'Cyberpunk Classics',
      description: 'Dystopian sci-fi essentials',
      isPublic: true,
    },
    1700000000000
  );
  assert.equal(ok.valid, true);
  if (ok.valid) {
    assert.equal(ok.isUpdate, false);
    assert.equal(ok.collectionId, buildCollectionDocId('user_999', 1700000000000));
    assert.equal(ok.name, 'Cyberpunk Classics');
  }

  const tooLong = validateCollectionPayload('user_999', {
    name: 'x'.repeat(101),
    isPublic: false,
  });
  assert.equal(tooLong.valid, false);
});

test('validateCollectionItemPayload validates parent collectionId and builds safe itemDocId', () => {
  const badCol = validateCollectionItemPayload('user_1', 'bad/id!', {
    itemType: 'wallpaper',
    itemId: 'wp-1',
    title: 'Horizon',
  });
  assert.equal(badCol.valid, false);

  const good = validateCollectionItemPayload('user_1', 'col_user_1_123', {
    itemType: 'wallpaper',
    itemId: 'wp-1',
    title: 'Horizon',
    imageUrl: '/wp.jpg',
  });
  assert.equal(good.valid, true);
  if (good.valid) {
    assert.equal(good.itemDocId, buildCollectionItemDocId('wallpaper', 'wp-1'));
  }
});

test('formatFriendlyFirestoreMessage maps permission, offline, and quota errors clearly', () => {
  assert.match(
    formatFriendlyFirestoreMessage(new Error('Missing or insufficient permissions.'), 'save favorite'),
    /verified email/i
  );
  assert.match(
    formatFriendlyFirestoreMessage(new Error('Failed to get document because the client is offline.'), 'load collections'),
    /internet connection/i
  );
  assert.match(
    formatFriendlyFirestoreMessage(new Error('Quota exceeded.'), 'create collection'),
    /quota exceeded/i
  );
});
