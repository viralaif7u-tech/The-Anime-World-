import test from 'node:test';
import assert from 'node:assert/strict';
import {
  WORKSPACE_SCOPES,
  buildDriveSearchQuery,
  buildRawMimeEmail,
  decodeBase64UrlUtf8,
  encodeBase64UrlUtf8,
  parseGmailMessage,
  sanitizeDriveDisplayType,
} from './googleWorkspaceHelpers';

test('WORKSPACE_SCOPES includes requested Gmail and Google Drive scopes', () => {
  assert.equal(WORKSPACE_SCOPES.includes('https://mail.google.com/'), true);
  assert.equal(WORKSPACE_SCOPES.includes('https://www.googleapis.com/auth/gmail.readonly'), true);
  assert.equal(WORKSPACE_SCOPES.includes('https://www.googleapis.com/auth/gmail.send'), true);
  assert.equal(WORKSPACE_SCOPES.includes('https://www.googleapis.com/auth/drive'), true);
  assert.equal(WORKSPACE_SCOPES.includes('https://www.googleapis.com/auth/drive.file'), true);
  assert.equal(WORKSPACE_SCOPES.length, 27);
});

test('encodeBase64UrlUtf8 and decodeBase64UrlUtf8 round-trip Unicode anime titles cleanly', () => {
  const original = 'Frieren: Beyond Journey’s End — 葬送のフリーレン';
  const encoded = encodeBase64UrlUtf8(original);
  assert.equal(encoded.includes('+'), false);
  assert.equal(encoded.includes('/'), false);
  assert.equal(encoded.includes('='), false);
  assert.equal(decodeBase64UrlUtf8(encoded), original);
});

test('buildRawMimeEmail validates recipients and builds safe RFC 2822 payload', () => {
  const bad = buildRawMimeEmail({ to: 'invalid-email', subject: 'Hello', body: 'Test' });
  assert.equal(bad.ok, false);

  const emptySubj = buildRawMimeEmail({ to: 'friend@example.com', subject: '   ', body: 'Test' });
  assert.equal(emptySubj.ok, false);

  const injectedRecipient = buildRawMimeEmail({
    to: 'friend@example.com\r\nBcc: evil@attacker.com',
    subject: 'Watchlist Share',
    body: 'Hello',
  });
  assert.equal(injectedRecipient.ok, false);

  const valid = buildRawMimeEmail({
    to: 'friend@example.com',
    subject: 'Watchlist\r\nBcc: evil@attacker.com',
    body: 'Check out Solo Leveling on THE ANIME WORLD!',
  });
  assert.equal(valid.ok, true);
  if (valid.ok) {
    const decoded = decodeBase64UrlUtf8(valid.raw);
    assert.match(decoded, /To: friend@example\.com/);
    assert.equal(decoded.includes('\r\nBcc:'), false);
    assert.match(decoded, /Subject: Watchlist Bcc: evil@attacker\.com/);
    assert.match(decoded, /Check out Solo Leveling/);
  }
});

test('parseGmailMessage extracts headers, body text, unread flag, and attachments', () => {
  const parsed = parseGmailMessage({
    id: 'msg_123',
    threadId: 'thr_123',
    labelIds: ['INBOX', 'UNREAD'],
    snippet: 'Preview snippet',
    payload: {
      headers: [
        { name: 'Subject', value: 'Weekly Anime Digest' },
        { name: 'From', value: 'Studio Alerts <alerts@example.com>' },
        { name: 'Date', value: 'Sat, 14 Nov 2026 10:00:00 +0000' },
      ],
      parts: [
        {
          mimeType: 'text/plain',
          body: { data: encodeBase64UrlUtf8('New episode airs tonight!') },
        },
        {
          filename: 'poster.png',
          mimeType: 'image/png',
          body: { attachmentId: 'att_1', size: 20480 },
        },
      ],
    },
  });

  assert.equal(parsed.subject, 'Weekly Anime Digest');
  assert.equal(parsed.isUnread, true);
  assert.equal(parsed.textBody, 'New episode airs tonight!');
  assert.equal(parsed.attachments.length, 1);
  assert.equal(parsed.attachments[0].filename, 'poster.png');
});

test('buildDriveSearchQuery safely escapes quotes and filters MIME types', () => {
  const q = buildDriveSearchQuery({
    searchText: "O'Brien's Clip",
    filter: 'videos',
    folderId: 'folder_abc',
  });
  assert.equal(
    q,
    "trashed = false and 'folder_abc' in parents and mimeType contains 'video/' and name contains 'O\\'Brien\\'s Clip'"
  );
  assert.equal(sanitizeDriveDisplayType('application/vnd.google-apps.folder'), 'Folder');
  assert.equal(sanitizeDriveDisplayType('video/mp4'), 'Video (MP4)');
});
