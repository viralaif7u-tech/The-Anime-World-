import { getApp, getApps, initializeApp } from 'firebase/app';
import {
  FacebookAuthProvider,
  getAuth,
  GithubAuthProvider,
  GoogleAuthProvider,
  OAuthProvider,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  getFirestore,
  initializeFirestore,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import type {
  CollectionItemRecord,
  CollectionRecord,
  DownloadRecord,
  DownloadStatus,
  FavoriteRecord,
} from '../types/anime';
import {
  formatFriendlyFirestoreMessage,
  validateCollectionItemPayload,
  validateCollectionPayload,
  validateFavoritePayload,
  type CollectionInput,
  type CollectionItemInput,
  type FavoriteInput,
} from './favoritesCollectionsHelpers';

import { WORKSPACE_SCOPES } from './googleWorkspaceHelpers';

// Initialize Firebase App and named Firestore database using credentials from firebase-applet-config.json
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
function createFirestoreClient() {
  try {
    return initializeFirestore(
      app,
      { experimentalAutoDetectLongPolling: true },
      firebaseConfig.firestoreDatabaseId
    );
  } catch {
    return getFirestore(app, firebaseConfig.firestoreDatabaseId);
  }
}
export const db = createFirestoreClient();
export const auth = getAuth(app);

export const googleProvider = new GoogleAuthProvider();
WORKSPACE_SCOPES.forEach((scope) => {
  googleProvider.addScope(scope);
});
googleProvider.setCustomParameters({ prompt: 'select_account' });

export const googleWorkspaceProvider = new GoogleAuthProvider();
WORKSPACE_SCOPES.forEach((scope) => {
  googleWorkspaceProvider.addScope(scope);
});
googleWorkspaceProvider.setCustomParameters({ prompt: 'consent select_account' });

export const facebookProvider = new FacebookAuthProvider();
export const githubProvider = new GithubAuthProvider();

export const appleProvider = new OAuthProvider('apple.com');
appleProvider.addScope('email');
appleProvider.addScope('name');

export const microsoftProvider = new OAuthProvider('microsoft.com');
microsoftProvider.setCustomParameters({ prompt: 'select_account' });

export const OperationType = {
  CREATE: 'create',
  UPDATE: 'update',
  DELETE: 'delete',
  LIST: 'list',
  GET: 'get',
  WRITE: 'write',
} as const;

export type OperationTypeValue = (typeof OperationType)[keyof typeof OperationType];

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationTypeValue;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: Array<{
      providerId?: string | null;
      email?: string | null;
    }>;
  };
}

export type ServiceResult<T = void> =
  | { ok: true; data: T; message: string }
  | { ok: false; error: string; message: string };

export function buildFirestoreErrorInfo(
  error: unknown,
  operationType: OperationTypeValue,
  path: string | null
): FirestoreErrorInfo {
  return {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
}

export function logFirestoreError(
  error: unknown,
  operationType: OperationTypeValue,
  path: string | null
): FirestoreErrorInfo {
  const errInfo = buildFirestoreErrorInfo(error, operationType, path);
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return errInfo;
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationTypeValue,
  path: string | null
): never {
  const errInfo = logFirestoreError(error, operationType, path);
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
    return false;
  }
}

if (typeof window !== 'undefined') {
  void testFirestoreConnection();
}

function requireVerifiedAuth(actionLabel: string): { ok: true; uid: string } | { ok: false; message: string } {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    return { ok: false, message: `Please sign in to ${actionLabel}.` };
  }
  if (!currentUser.emailVerified) {
    return {
      ok: false,
      message: `Please verify your email address before trying to ${actionLabel}.`,
    };
  }
  return { ok: true, uid: currentUser.uid };
}

/**
 * Save (or upsert) a user favorite item into Cloud Firestore.
 */
export async function saveUserFavorite(
  item: FavoriteInput,
  userIdOverride?: string
): Promise<ServiceResult<{ favoriteId: string }>> {
  const authCheck = requireVerifiedAuth('save favorites');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const uid = userIdOverride || authCheck.uid;

  const validated = validateFavoritePayload(uid, item);
  if (!validated.valid) {
    return { ok: false, error: 'validation/invalid-favorite', message: validated.message };
  }

  const path = `favorites/${validated.favoriteId}`;
  try {
    await setDoc(doc(db, 'favorites', validated.favoriteId), {
      ...validated.payload,
      createdAt: serverTimestamp(),
    });
    return {
      ok: true,
      data: { favoriteId: validated.favoriteId },
      message: `"${validated.payload.title}" saved to your favorites.`,
    };
  } catch (err) {
    logFirestoreError(err, OperationType.CREATE, path);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, `save "${validated.payload.title}" to favorites`),
    };
  }
}

/**
 * Remove a favorite item from Cloud Firestore.
 */
export async function removeUserFavorite(
  itemType: FavoriteInput['itemType'],
  itemId: string,
  title?: string,
  userIdOverride?: string
): Promise<ServiceResult<{ favoriteId: string }>> {
  const authCheck = requireVerifiedAuth('remove favorites');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const uid = userIdOverride || authCheck.uid;

  const validated = validateFavoritePayload(uid, {
    itemType,
    itemId,
    title: title || 'Selected item',
  });
  if (!validated.valid) {
    return { ok: false, error: 'validation/invalid-favorite', message: validated.message };
  }

  const path = `favorites/${validated.favoriteId}`;
  try {
    await deleteDoc(doc(db, 'favorites', validated.favoriteId));
    return {
      ok: true,
      data: { favoriteId: validated.favoriteId },
      message: title
        ? `"${title}" removed from your favorites.`
        : 'Removed item from your favorites.',
    };
  } catch (err) {
    logFirestoreError(err, OperationType.DELETE, path);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'remove this item from favorites'),
    };
  }
}

/**
 * Toggle a user favorite item (saves if missing, removes if already saved).
 */
export async function toggleUserFavorite(
  item: FavoriteInput,
  knownExists?: boolean,
  userIdOverride?: string
): Promise<ServiceResult<{ saved: boolean; favoriteId: string }>> {
  const authCheck = requireVerifiedAuth('save favorites');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const uid = userIdOverride || authCheck.uid;
  const validated = validateFavoritePayload(uid, item);
  if (!validated.valid) {
    return { ok: false, error: 'validation/invalid-favorite', message: validated.message };
  }

  let exists = knownExists;
  if (exists === undefined) {
    try {
      const snap = await getDoc(doc(db, 'favorites', validated.favoriteId));
      exists = snap.exists();
    } catch (err) {
      logFirestoreError(err, OperationType.GET, `favorites/${validated.favoriteId}`);
      return {
        ok: false,
        error: err instanceof Error ? err.message : String(err),
        message: formatFriendlyFirestoreMessage(err, 'check favorite status'),
      };
    }
  }

  if (exists) {
    const removed = await removeUserFavorite(item.itemType, item.itemId, item.title, uid);
    if (!removed.ok) return removed;
    return {
      ok: true,
      data: { saved: false, favoriteId: removed.data.favoriteId },
      message: removed.message,
    };
  }

  const saved = await saveUserFavorite(item, uid);
  if (!saved.ok) return saved;
  return {
    ok: true,
    data: { saved: true, favoriteId: saved.data.favoriteId },
    message: saved.message,
  };
}

/**
 * Fetch all favorites owned by a signed-in user.
 */
export async function getUserFavorites(userId?: string): Promise<ServiceResult<FavoriteRecord[]>> {
  const targetUid = userId || auth.currentUser?.uid;
  if (!targetUid) {
    return { ok: false, error: 'auth/required', message: 'Please sign in to view your favorites.' };
  }

  try {
    const snap = await getDocs(query(collection(db, 'favorites'), where('userId', '==', targetUid)));
    const list = snap.docs.map((d) => d.data() as FavoriteRecord);
    return {
      ok: true,
      data: list,
      message: `Loaded ${list.length} saved favorite${list.length === 1 ? '' : 's'}.`,
    };
  } catch (err) {
    logFirestoreError(err, OperationType.LIST, 'favorites');
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'load your favorites'),
    };
  }
}

/**
 * Create a new collection or update an existing collection in Cloud Firestore.
 */
export async function saveUserCollection(
  input: CollectionInput,
  userIdOverride?: string
): Promise<ServiceResult<{ collectionId: string }>> {
  const authCheck = requireVerifiedAuth('save collections');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const uid = userIdOverride || authCheck.uid;

  const validated = validateCollectionPayload(uid, input);
  if (!validated.valid) {
    return { ok: false, error: 'validation/invalid-collection', message: validated.message };
  }

  const path = `collections/${validated.collectionId}`;
  try {
    if (validated.isUpdate) {
      const updates: Record<string, unknown> = {
        name: validated.name,
        description: validated.description,
        isPublic: validated.isPublic,
        updatedAt: serverTimestamp(),
      };
      if (validated.coverImage) {
        updates.coverImage = validated.coverImage;
      }
      await updateDoc(doc(db, 'collections', validated.collectionId), updates);
      return {
        ok: true,
        data: { collectionId: validated.collectionId },
        message: `Collection "${validated.name}" updated successfully.`,
      };
    }

    await setDoc(doc(db, 'collections', validated.collectionId), {
      id: validated.collectionId,
      userId: uid,
      name: validated.name,
      description: validated.description,
      isPublic: validated.isPublic,
      itemsCount: 0,
      coverImage: validated.coverImage,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return {
      ok: true,
      data: { collectionId: validated.collectionId },
      message: `Collection "${validated.name}" created successfully.`,
    };
  } catch (err) {
    logFirestoreError(err, validated.isUpdate ? OperationType.UPDATE : OperationType.CREATE, path);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(
        err,
        validated.isUpdate ? `update collection "${validated.name}"` : `create collection "${validated.name}"`
      ),
    };
  }
}

/**
 * Delete a user collection document from Cloud Firestore.
 */
export async function deleteUserCollection(
  collectionId: string,
  collectionName?: string
): Promise<ServiceResult<{ collectionId: string }>> {
  const authCheck = requireVerifiedAuth('delete collections');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }

  const path = `collections/${collectionId}`;
  try {
    await deleteDoc(doc(db, 'collections', collectionId));
    return {
      ok: true,
      data: { collectionId },
      message: collectionName
        ? `Collection "${collectionName}" deleted.`
        : 'Collection deleted successfully.',
    };
  } catch (err) {
    logFirestoreError(err, OperationType.DELETE, path);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'delete this collection'),
    };
  }
}

/**
 * Save an anime/character/wallpaper/3D item into a specific user collection and update parent metadata.
 */
export async function saveItemToCollection(
  collectionId: string,
  item: CollectionItemInput,
  collectionContext?: Pick<CollectionRecord, 'name' | 'isPublic' | 'itemsCount' | 'coverImage'>,
  userIdOverride?: string
): Promise<ServiceResult<{ collectionId: string; itemDocId: string; alreadyPresent: boolean }>> {
  const authCheck = requireVerifiedAuth('save items to collections');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const uid = userIdOverride || authCheck.uid;

  const validated = validateCollectionItemPayload(uid, collectionId, item);
  if (!validated.valid) {
    return { ok: false, error: 'validation/invalid-item', message: validated.message };
  }

  let targetCol = collectionContext;
  if (!targetCol) {
    try {
      const colSnap = await getDoc(doc(db, 'collections', collectionId));
      if (!colSnap.exists()) {
        return {
          ok: false,
          error: 'collection/not-found',
          message: 'Target collection was not found.',
        };
      }
      targetCol = colSnap.data() as CollectionRecord;
    } catch (err) {
      logFirestoreError(err, OperationType.GET, `collections/${collectionId}`);
      return {
        ok: false,
        error: err instanceof Error ? err.message : String(err),
        message: formatFriendlyFirestoreMessage(err, 'verify the target collection'),
      };
    }
  }

  const itemPath = `collections/${collectionId}/items/${validated.itemDocId}`;
  try {
    const existingSnap = await getDoc(doc(db, 'collections', collectionId, 'items', validated.itemDocId));
    if (existingSnap.exists()) {
      return {
        ok: true,
        data: { collectionId, itemDocId: validated.itemDocId, alreadyPresent: true },
        message: `"${validated.title}" is already in "${targetCol.name}".`,
      };
    }

    await setDoc(doc(db, 'collections', collectionId, 'items', validated.itemDocId), {
      id: validated.itemDocId,
      collectionId,
      userId: uid,
      isCollectionPublic: targetCol.isPublic,
      itemId: validated.itemId,
      itemType: validated.itemType,
      title: validated.title,
      imageUrl: validated.imageUrl,
      addedAt: serverTimestamp(),
    });

    await updateDoc(doc(db, 'collections', collectionId), {
      itemsCount: (targetCol.itemsCount || 0) + 1,
      coverImage: targetCol.coverImage || validated.imageUrl,
      updatedAt: serverTimestamp(),
    });

    return {
      ok: true,
      data: { collectionId, itemDocId: validated.itemDocId, alreadyPresent: false },
      message: `"${validated.title}" added to "${targetCol.name}".`,
    };
  } catch (err) {
    logFirestoreError(err, OperationType.WRITE, itemPath);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, `save "${validated.title}" to "${targetCol.name}"`),
    };
  }
}

/**
 * Remove an item from a user collection and decrement itemsCount safely.
 */
export async function removeItemFromCollection(
  collectionId: string,
  itemDocId: string,
  currentItemsCount: number,
  itemTitle?: string
): Promise<ServiceResult<{ collectionId: string; itemDocId: string }>> {
  const authCheck = requireVerifiedAuth('update collections');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }

  const itemPath = `collections/${collectionId}/items/${itemDocId}`;
  try {
    await deleteDoc(doc(db, 'collections', collectionId, 'items', itemDocId));
    await updateDoc(doc(db, 'collections', collectionId), {
      itemsCount: Math.max(0, (currentItemsCount || 0) - 1),
      updatedAt: serverTimestamp(),
    });
    return {
      ok: true,
      data: { collectionId, itemDocId },
      message: itemTitle
        ? `"${itemTitle}" removed from collection.`
        : 'Item removed from collection.',
    };
  } catch (err) {
    logFirestoreError(err, OperationType.DELETE, itemPath);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'remove item from collection'),
    };
  }
}

/**
 * Fetch all collections owned by a user.
 */
export async function getUserCollections(userId?: string): Promise<ServiceResult<CollectionRecord[]>> {
  const targetUid = userId || auth.currentUser?.uid;
  if (!targetUid) {
    return { ok: false, error: 'auth/required', message: 'Please sign in to view your collections.' };
  }

  try {
    const snap = await getDocs(query(collection(db, 'collections'), where('userId', '==', targetUid)));
    const list = snap.docs.map((d) => d.data() as CollectionRecord);
    return {
      ok: true,
      data: list,
      message: `Loaded ${list.length} collection${list.length === 1 ? '' : 's'}.`,
    };
  } catch (err) {
    logFirestoreError(err, OperationType.LIST, 'collections');
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'load your collections'),
    };
  }
}

/**
 * Fetch all items inside a user's collection.
 */
export async function getCollectionItems(
  collectionId: string,
  userId?: string
): Promise<ServiceResult<CollectionItemRecord[]>> {
  const targetUid = userId || auth.currentUser?.uid;
  if (!targetUid) {
    return { ok: false, error: 'auth/required', message: 'Please sign in to inspect collection items.' };
  }

  try {
    const snap = await getDocs(
      query(collection(db, 'collections', collectionId, 'items'), where('userId', '==', targetUid))
    );
    const items = snap.docs.map((d) => d.data() as CollectionItemRecord);
    return {
      ok: true,
      data: items,
      message: `Loaded ${items.length} item${items.length === 1 ? '' : 's'}.`,
    };
  } catch (err) {
    logFirestoreError(err, OperationType.LIST, `collections/${collectionId}/items`);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'load collection items'),
    };
  }
}

export async function createDownloadHistoryEntry(params: {
  downloadId: string;
  videoId: string;
  title: string;
  thumbnailUrl?: string;
  fileSizeBytes: number;
  saveLocation?: string;
}): Promise<ServiceResult<{ downloadId: string }>> {
  const authCheck = requireVerifiedAuth('save download history');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const uid = authCheck.uid;
  const path = `downloads/${params.downloadId}`;
  try {
    await setDoc(doc(db, 'downloads', params.downloadId), {
      id: params.downloadId,
      userId: uid,
      videoId: params.videoId.slice(0, 128),
      title: params.title.trim().slice(0, 200) || 'Anime Video',
      thumbnailUrl: (params.thumbnailUrl || '').slice(0, 500),
      format: 'MP4',
      fileSizeBytes: Math.max(0, Math.round(params.fileSizeBytes || 0)),
      downloadedBytes: 0,
      status: 'downloading' as DownloadStatus,
      saveLocation: (params.saveLocation || 'Downloads').slice(0, 200),
      errorMessage: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return {
      ok: true,
      data: { downloadId: params.downloadId },
      message: 'Download tracking initialized.',
    };
  } catch (err) {
    logFirestoreError(err, OperationType.CREATE, path);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'record download entry'),
    };
  }
}

export async function updateDownloadHistoryEntry(
  downloadId: string,
  updates: {
    fileSizeBytes: number;
    downloadedBytes: number;
    status: DownloadStatus;
    saveLocation?: string;
    errorMessage?: string;
  }
): Promise<ServiceResult<{ downloadId: string }>> {
  const authCheck = requireVerifiedAuth('update download status');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const path = `downloads/${downloadId}`;
  try {
    await updateDoc(doc(db, 'downloads', downloadId), {
      fileSizeBytes: Math.max(0, Math.round(updates.fileSizeBytes || 0)),
      downloadedBytes: Math.max(0, Math.round(updates.downloadedBytes || 0)),
      status: updates.status,
      saveLocation: (updates.saveLocation || 'Downloads').slice(0, 200),
      errorMessage: (updates.errorMessage || '').slice(0, 300),
      updatedAt: serverTimestamp(),
    });
    return {
      ok: true,
      data: { downloadId },
      message: `Download status updated to ${updates.status}.`,
    };
  } catch (err) {
    logFirestoreError(err, OperationType.UPDATE, path);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'update download status'),
    };
  }
}

export async function deleteDownloadHistoryEntry(downloadId: string): Promise<ServiceResult<{ downloadId: string }>> {
  const authCheck = requireVerifiedAuth('remove download history');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const path = `downloads/${downloadId}`;
  try {
    await deleteDoc(doc(db, 'downloads', downloadId));
    return {
      ok: true,
      data: { downloadId },
      message: 'Removed entry from My Downloads.',
    };
  } catch (err) {
    logFirestoreError(err, OperationType.DELETE, path);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'remove download entry'),
    };
  }
}

export async function clearUserDownloadHistory(userId?: string): Promise<ServiceResult<{ removedCount: number }>> {
  const authCheck = requireVerifiedAuth('clear download history');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const targetUid = userId || authCheck.uid;
  try {
    const snap = await getDocs(query(collection(db, 'downloads'), where('userId', '==', targetUid)));
    await Promise.all(snap.docs.map((d) => deleteDoc(d.ref)));
    return {
      ok: true,
      data: { removedCount: snap.size },
      message: `Cleared ${snap.size} download record${snap.size === 1 ? '' : 's'}.`,
    };
  } catch (err) {
    logFirestoreError(err, OperationType.DELETE, 'downloads');
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'clear download history'),
    };
  }
}

export async function getUserDownloads(userId?: string): Promise<ServiceResult<DownloadRecord[]>> {
  const targetUid = userId || auth.currentUser?.uid;
  if (!targetUid) {
    return { ok: false, error: 'auth/required', message: 'Please sign in to view your downloads.' };
  }
  try {
    const snap = await getDocs(query(collection(db, 'downloads'), where('userId', '==', targetUid)));
    const items = snap.docs.map((d) => d.data() as DownloadRecord);
    return {
      ok: true,
      data: items,
      message: `Loaded ${items.length} download${items.length === 1 ? '' : 's'}.`,
    };
  } catch (err) {
    logFirestoreError(err, OperationType.LIST, 'downloads');
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'load your downloads'),
    };
  }
}

export async function updateUserPrivacyPreferences(prefs: {
  isPublic?: boolean;
  saveDownloadHistory?: boolean;
  hideViewingActivity?: boolean;
}): Promise<ServiceResult<void>> {
  const authCheck = requireVerifiedAuth('update privacy settings');
  if (!authCheck.ok) {
    return { ok: false, error: 'auth/required', message: authCheck.message };
  }
  const uid = authCheck.uid;
  try {
    if (prefs.isPublic !== undefined) {
      await updateDoc(doc(db, 'publicProfiles', uid), {
        isPublic: prefs.isPublic,
        updatedAt: serverTimestamp(),
      });
    }
    const privUpdates: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (prefs.saveDownloadHistory !== undefined) {
      privUpdates.saveDownloadHistory = prefs.saveDownloadHistory;
    }
    if (prefs.hideViewingActivity !== undefined) {
      privUpdates.hideViewingActivity = prefs.hideViewingActivity;
    }
    if (Object.keys(privUpdates).length > 1) {
      await updateDoc(doc(db, 'privateUsers', uid), privUpdates);
    }
    return {
      ok: true,
      data: undefined,
      message: 'Privacy settings saved securely.',
    };
  } catch (err) {
    logFirestoreError(err, OperationType.UPDATE, `privateUsers/${uid}`);
    return {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
      message: formatFriendlyFirestoreMessage(err, 'save privacy settings'),
    };
  }
}
