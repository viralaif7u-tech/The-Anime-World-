import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildSafeMp4Filename,
  calculateDownloadProgress,
  detectDeviceDownloadGuidance,
  formatBytes,
  isValidMp4Buffer,
} from './videoDownloadHelpers';

test('isValidMp4Buffer validates real ISO BMFF ftyp header and rejects HTML/empty payloads', () => {
  const validMp4 = new Uint8Array([
    0x00, 0x00, 0x00, 0x20,
    0x66, 0x74, 0x79, 0x70,
    0x69, 0x73, 0x6f, 0x6d,
    0x00, 0x00, 0x02, 0x00,
  ]);
  assert.equal(isValidMp4Buffer(validMp4), true);

  const htmlPayload = new TextEncoder().encode('<!DOCTYPE html><html><body>404</body></html>');
  assert.equal(isValidMp4Buffer(htmlPayload), false);

  const jsonError = new TextEncoder().encode('{"error":"Not found"}');
  assert.equal(isValidMp4Buffer(jsonError), false);

  assert.equal(isValidMp4Buffer(new Uint8Array(0)), false);
  assert.equal(isValidMp4Buffer(new Uint8Array([1, 2, 3, 4])), false);
});

test('calculateDownloadProgress never reports 100% before stream verification completes', () => {
  assert.equal(calculateDownloadProgress(0, 1000), 0);
  assert.equal(calculateDownloadProgress(500, 1000), 50);
  assert.equal(calculateDownloadProgress(1000, 1000), 99);
  assert.ok(calculateDownloadProgress(250_000, 0) < 100);
});

test('formatBytes formats byte sizes cleanly', () => {
  assert.equal(formatBytes(0), '0 B');
  assert.equal(formatBytes(512), '512 B');
  assert.equal(formatBytes(2048), '2.0 KB');
  assert.equal(formatBytes(1_572_864), '1.50 MB');
});

test('buildSafeMp4Filename produces clean .mp4 filename', () => {
  assert.equal(
    buildSafeMp4Filename('Dimensional Iris Portal: 4K?!', 'anim-1'),
    'AnimeWorld_Dimensional_Iris_Portal_4K.mp4'
  );
  assert.equal(buildSafeMp4Filename('!!!', 'anim-2'), 'AnimeWorld_anim-2.mp4');
});

test('detectDeviceDownloadGuidance identifies Android, iOS, and Desktop accurately', () => {
  const android = detectDeviceDownloadGuidance({
    userAgent: 'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36',
    hasFileSystemPicker: false,
    hasFileShare: true,
  });
  assert.equal(android.platformLabel, 'Android');
  assert.match(android.explanation, /Android/i);

  const ios = detectDeviceDownloadGuidance({
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)',
    hasFileSystemPicker: false,
    hasFileShare: true,
  });
  assert.equal(ios.platformLabel, 'iOS');

  const desktop = detectDeviceDownloadGuidance({
    userAgent: 'Mozilla/5.0 (X11; Linux x86_64) Chrome/120.0.0.0',
    hasFileSystemPicker: true,
    hasFileShare: false,
  });
  assert.equal(desktop.platformLabel, 'Desktop');
});
