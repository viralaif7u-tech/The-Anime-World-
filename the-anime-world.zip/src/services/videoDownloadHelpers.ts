export function isValidMp4Buffer(bytes: Uint8Array): boolean {
  if (!bytes || bytes.length < 16) return false;
  if (bytes[0] === 0x3c || bytes[0] === 0x7b) return false;
  return (
    bytes[4] === 0x66 &&
    bytes[5] === 0x74 &&
    bytes[6] === 0x79 &&
    bytes[7] === 0x70
  );
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  if (bytes < 1024) return `${Math.round(bytes)} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(2)} MB`;
  return `${(mb / 1024).toFixed(2)} GB`;
}

export function calculateDownloadProgress(loadedBytes: number, totalBytes: number): number {
  if (!Number.isFinite(loadedBytes) || loadedBytes <= 0) return 0;
  if (!Number.isFinite(totalBytes) || totalBytes <= 0) {
    return Math.min(95, Math.max(5, Math.round((loadedBytes / (loadedBytes + 256 * 1024)) * 95)));
  }
  const pct = Math.floor((loadedBytes / totalBytes) * 100);
  return Math.max(0, Math.min(99, pct));
}

export function buildSafeMp4Filename(title: string, fallbackId: string): string {
  const cleaned = title
    .replace(/[^a-zA-Z0-9\s_-]+/g, '')
    .trim()
    .replace(/\s+/g, '_')
    .slice(0, 64);
  const base = cleaned || fallbackId.replace(/[^a-zA-Z0-9_-]+/g, '_') || 'anime_video';
  return `AnimeWorld_${base}.mp4`;
}

export function detectDeviceDownloadGuidance(params: {
  userAgent: string;
  hasFileSystemPicker: boolean;
  hasFileShare: boolean;
}): {
  platformLabel: 'Android' | 'iOS' | 'Desktop';
  targetFolderLabel: string;
  explanation: string;
} {
  const ua = params.userAgent.toLowerCase();
  const isAndroid = /android/.test(ua);
  const isIos = /iphone|ipad|ipod/.test(ua);

  if (isAndroid) {
    return {
      platformLabel: 'Android',
      targetFolderLabel: 'Downloads / Movies (Gallery)',
      explanation: params.hasFileShare
        ? 'Saved to your Android Downloads folder as a playable MP4. Tap "Save to Gallery / Share" to store directly into Photos or an Anime World album.'
        : 'Saved to your Android device Downloads folder as a playable MP4 file visible in Files & video players.',
    };
  }

  if (isIos) {
    return {
      platformLabel: 'iOS',
      targetFolderLabel: 'Files App / Photos',
      explanation: params.hasFileShare
        ? 'Saved as a playable MP4. Tap "Save to Photos / Share" -> "Save Video" to add directly to your iPhone/iPad Photos library.'
        : 'Saved to your Safari Downloads folder in the Apple Files app.',
    };
  }

  return {
    platformLabel: 'Desktop',
    targetFolderLabel: params.hasFileSystemPicker ? 'Chosen Folder (or Downloads)' : 'Downloads Folder',
    explanation: params.hasFileSystemPicker
      ? 'Choose your Movies or Anime World folder directly, or save automatically to your browser Downloads folder.'
      : 'Saved directly to your device Downloads folder as a playable H.264 MP4 video.',
  };
}
