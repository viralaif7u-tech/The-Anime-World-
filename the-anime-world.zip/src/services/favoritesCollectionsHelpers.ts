import type { ItemType } from '../types/anime';

export const ALLOWED_ITEM_TYPES: ReadonlyArray<ItemType> = [
  'anime',
  'character',
  'wallpaper',
  'model3d',
  'animation',
];

const SAFE_ID_REGEX = /^[a-zA-Z0-9_-]+$/;

export interface FavoriteInput {
  itemType: ItemType;
  itemId: string;
  title: string;
  imageUrl?: string;
  subtitle?: string;
}

export interface CollectionInput {
  collectionId?: string;
  name: string;
  description?: string;
  isPublic: boolean;
  coverImage?: string;
}

export interface CollectionItemInput {
  itemType: ItemType;
  itemId: string;
  title: string;
  imageUrl?: string;
}

export function sanitizeFirestoreDocId(raw: string, maxLen = 128): string {
  const cleaned = String(raw || '')
    .trim()
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .slice(0, maxLen);
  return cleaned;
}

export function buildFavoriteDocId(userId: string, itemType: ItemType, itemId: string): string {
  const uidPart = sanitizeFirestoreDocId(userId, 48);
  const itemPart = sanitizeFirestoreDocId(itemId, 60);
  return `${uidPart}_${itemType}_${itemPart}`.slice(0, 128);
}

export function buildCollectionDocId(userId: string, nowMs = Date.now()): string {
  const uidPart = sanitizeFirestoreDocId(userId, 16).slice(0, 8) || 'user';
  return `col_${uidPart}_${Math.max(0, Math.floor(nowMs))}`.slice(0, 128);
}

export function buildCollectionItemDocId(itemType: ItemType, itemId: string): string {
  const itemPart = sanitizeFirestoreDocId(itemId, 60);
  return `${itemType}_${itemPart}`.slice(0, 128);
}

export function validateFavoritePayload(
  userId: string,
  input: FavoriteInput
):
  | {
      valid: true;
      favoriteId: string;
      payload: {
        id: string;
        userId: string;
        itemId: string;
        itemType: ItemType;
        title: string;
        imageUrl: string;
        subtitle: string;
      };
    }
  | { valid: false; message: string } {
  const cleanUid = String(userId || '').trim();
  if (!cleanUid || !SAFE_ID_REGEX.test(cleanUid) || cleanUid.length > 128) {
    return { valid: false, message: 'Please sign in with a valid account to save favorites.' };
  }
  if (!ALLOWED_ITEM_TYPES.includes(input.itemType)) {
    return { valid: false, message: 'Unsupported item type for favorites.' };
  }
  const cleanItemId = String(input.itemId || '').trim().slice(0, 128);
  if (!cleanItemId) {
    return { valid: false, message: 'Item identifier is missing.' };
  }
  const cleanTitle = String(input.title || '').trim().slice(0, 200);
  if (!cleanTitle) {
    return { valid: false, message: 'Item title is required before saving to favorites.' };
  }
  const favoriteId = buildFavoriteDocId(cleanUid, input.itemType, cleanItemId);
  if (!favoriteId || !SAFE_ID_REGEX.test(favoriteId)) {
    return { valid: false, message: 'Unable to generate a valid favorite identifier.' };
  }

  return {
    valid: true,
    favoriteId,
    payload: {
      id: favoriteId,
      userId: cleanUid,
      itemId: cleanItemId,
      itemType: input.itemType,
      title: cleanTitle,
      imageUrl: String(input.imageUrl || '').trim().slice(0, 500),
      subtitle: String(input.subtitle || '').trim().slice(0, 200),
    },
  };
}

export function validateCollectionPayload(
  userId: string,
  input: CollectionInput,
  nowMs = Date.now()
):
  | {
      valid: true;
      isUpdate: boolean;
      collectionId: string;
      name: string;
      description: string;
      isPublic: boolean;
      coverImage: string;
    }
  | { valid: false; message: string } {
  const cleanUid = String(userId || '').trim();
  if (!cleanUid || !SAFE_ID_REGEX.test(cleanUid) || cleanUid.length > 128) {
    return { valid: false, message: 'Please sign in with a valid account to manage collections.' };
  }
  const cleanName = String(input.name || '').trim();
  if (!cleanName) {
    return { valid: false, message: 'Collection name cannot be empty.' };
  }
  if (cleanName.length > 100) {
    return { valid: false, message: 'Collection name must be 100 characters or fewer.' };
  }
  const cleanDesc = String(input.description || '').trim().slice(0, 500);
  const cleanCover = String(input.coverImage || '').trim().slice(0, 500);

  const isUpdate = Boolean(input.collectionId && input.collectionId.trim().length > 0);
  const collectionId = isUpdate
    ? String(input.collectionId).trim()
    : buildCollectionDocId(cleanUid, nowMs);

  if (!collectionId || collectionId.length > 128 || !SAFE_ID_REGEX.test(collectionId)) {
    return { valid: false, message: 'Invalid collection identifier.' };
  }

  return {
    valid: true,
    isUpdate,
    collectionId,
    name: cleanName,
    description: cleanDesc,
    isPublic: Boolean(input.isPublic),
    coverImage: cleanCover,
  };
}

export function validateCollectionItemPayload(
  userId: string,
  collectionId: string,
  item: CollectionItemInput
):
  | {
      valid: true;
      itemDocId: string;
      itemId: string;
      itemType: ItemType;
      title: string;
      imageUrl: string;
    }
  | { valid: false; message: string } {
  const cleanUid = String(userId || '').trim();
  if (!cleanUid || !SAFE_ID_REGEX.test(cleanUid)) {
    return { valid: false, message: 'Please sign in to save items into collections.' };
  }
  const cleanColId = String(collectionId || '').trim();
  if (!cleanColId || cleanColId.length > 128 || !SAFE_ID_REGEX.test(cleanColId)) {
    return { valid: false, message: 'Select a valid collection before saving.' };
  }
  if (!ALLOWED_ITEM_TYPES.includes(item.itemType)) {
    return { valid: false, message: 'Unsupported item type for collections.' };
  }
  const cleanItemId = String(item.itemId || '').trim().slice(0, 128);
  const cleanTitle = String(item.title || '').trim().slice(0, 200);
  if (!cleanItemId || !cleanTitle) {
    return { valid: false, message: 'Item title and ID are required.' };
  }
  const itemDocId = buildCollectionItemDocId(item.itemType, cleanItemId);
  if (!itemDocId || !SAFE_ID_REGEX.test(itemDocId)) {
    return { valid: false, message: 'Invalid collection item identifier.' };
  }

  return {
    valid: true,
    itemDocId,
    itemId: cleanItemId,
    itemType: item.itemType,
    title: cleanTitle,
    imageUrl: String(item.imageUrl || '').trim().slice(0, 500),
  };
}

export function formatFriendlyFirestoreMessage(err: unknown, fallbackAction: string): string {
  const raw = err instanceof Error ? err.message : String(err);
  const lower = raw.toLowerCase();

  if (lower.includes('missing or insufficient permissions') || lower.includes('permission-denied')) {
    return `Permission denied while trying to ${fallbackAction}. Make sure you are signed in with a verified email address and own this item.`;
  }
  if (lower.includes('the client is offline') || lower.includes('unavailable') || lower.includes('network')) {
    return `Could not reach Cloud Firestore while trying to ${fallbackAction}. Check your internet connection and try again.`;
  }
  if (lower.includes('quota exceeded')) {
    return 'Daily Firestore free-tier quota exceeded. Please try again tomorrow or upgrade the Firebase plan.';
  }
  if (lower.includes('not-found') || lower.includes('not found')) {
    return `The requested record could not be found while trying to ${fallbackAction}.`;
  }
  if (lower.includes('unauthenticated')) {
    return `Please sign in to ${fallbackAction}.`;
  }
  if (raw && raw.length <= 180 && !raw.startsWith('{')) {
    return raw;
  }
  return `Unable to ${fallbackAction}. Please try again.`;
}
