export const WORKSPACE_SCOPES = [
  'https://mail.google.com/',
  'https://www.googleapis.com/auth/gmail.addons.current.action.compose',
  'https://www.googleapis.com/auth/gmail.addons.current.message.action',
  'https://www.googleapis.com/auth/gmail.addons.current.message.metadata',
  'https://www.googleapis.com/auth/gmail.addons.current.message.readonly',
  'https://www.googleapis.com/auth/gmail.compose',
  'https://www.googleapis.com/auth/gmail.insert',
  'https://www.googleapis.com/auth/gmail.labels',
  'https://www.googleapis.com/auth/gmail.metadata',
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/gmail.readonly',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.settings.basic',
  'https://www.googleapis.com/auth/gmail.settings.sharing',
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/drive.activity',
  'https://www.googleapis.com/auth/drive.activity.readonly',
  'https://www.googleapis.com/auth/drive.appdata',
  'https://www.googleapis.com/auth/drive.apps.readonly',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/drive.install',
  'https://www.googleapis.com/auth/drive.meet.readonly',
  'https://www.googleapis.com/auth/drive.metadata',
  'https://www.googleapis.com/auth/drive.metadata.readonly',
  'https://www.googleapis.com/auth/drive.photos.readonly',
  'https://www.googleapis.com/auth/drive.readonly',
  'https://www.googleapis.com/auth/drive.scripts',
] as const;

export interface GmailHeader {
  name: string;
  value: string;
}

export interface GmailPayloadPart {
  partId?: string;
  mimeType?: string;
  filename?: string;
  headers?: GmailHeader[];
  body?: {
    attachmentId?: string;
    size?: number;
    data?: string;
  };
  parts?: GmailPayloadPart[];
}

export interface RawGmailMessage {
  id: string;
  threadId?: string;
  labelIds?: string[];
  snippet?: string;
  internalDate?: string;
  payload?: GmailPayloadPart;
}

export interface ParsedGmailMessage {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  to: string;
  date: string;
  snippet: string;
  labelIds: string[];
  isUnread: boolean;
  textBody: string;
  htmlBody: string;
  attachments: Array<{ filename: string; mimeType: string; size: number; attachmentId?: string }>;
}

export type DriveFilterKind = 'all' | 'folders' | 'videos' | 'images' | 'documents';

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  modifiedTime?: string;
  webViewLink?: string;
  thumbnailLink?: string;
  iconLink?: string;
  parents?: string[];
}

export function encodeBase64UrlUtf8(input: string): string {
  const bytes = new TextEncoder().encode(input);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function decodeBase64UrlUtf8(base64Url: string): string {
  if (!base64Url) return '';
  const padded = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  const padLen = (4 - (padded.length % 4)) % 4;
  const binary = atob(padded + '='.repeat(padLen));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

export function isValidEmailAddress(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function stripHeaderNewlines(value: string): string {
  return value.replace(/[\r\n]+/g, ' ').trim();
}

export function buildRawMimeEmail(params: {
  to: string;
  subject: string;
  body: string;
  cc?: string;
  replyTo?: string;
}): { ok: true; raw: string } | { ok: false; error: string } {
  const cleanTo = stripHeaderNewlines(params.to);
  if (!cleanTo || !isValidEmailAddress(cleanTo)) {
    return { ok: false, error: 'Please enter a valid recipient email address.' };
  }
  const cleanSubject = stripHeaderNewlines(params.subject);
  if (!cleanSubject) {
    return { ok: false, error: 'Email subject cannot be empty.' };
  }
  const cleanBody = params.body.trim();
  if (!cleanBody) {
    return { ok: false, error: 'Email message body cannot be empty.' };
  }

  const lines = [`To: ${cleanTo}`];
  if (params.cc && params.cc.trim()) {
    const cleanCc = stripHeaderNewlines(params.cc);
    if (!isValidEmailAddress(cleanCc)) {
      return { ok: false, error: 'Please enter a valid CC email address.' };
    }
    lines.push(`Cc: ${cleanCc}`);
  }
  if (params.replyTo && params.replyTo.trim()) {
    lines.push(`Reply-To: ${stripHeaderNewlines(params.replyTo)}`);
  }

  lines.push(
    `Subject: ${cleanSubject}`,
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset="UTF-8"',
    'Content-Transfer-Encoding: 8bit',
    '',
    cleanBody
  );

  return { ok: true, raw: encodeBase64UrlUtf8(lines.join('\r\n')) };
}

export function extractGmailHeader(headers: GmailHeader[] | undefined, targetName: string): string {
  if (!Array.isArray(headers)) return '';
  const needle = targetName.toLowerCase();
  const match = headers.find((h) => h.name.toLowerCase() === needle);
  return match?.value || '';
}

export function parseGmailMessage(msg: RawGmailMessage): ParsedGmailMessage {
  const headers = msg.payload?.headers;
  const subject = extractGmailHeader(headers, 'Subject') || '(No Subject)';
  const from = extractGmailHeader(headers, 'From') || 'Unknown Sender';
  const to = extractGmailHeader(headers, 'To') || '';
  const date = extractGmailHeader(headers, 'Date') || '';
  const labelIds = Array.isArray(msg.labelIds) ? msg.labelIds : [];

  let textBody = '';
  let htmlBody = '';
  const attachments: ParsedGmailMessage['attachments'] = [];

  const walk = (part?: GmailPayloadPart) => {
    if (!part) return;
    if (part.filename && part.filename.length > 0 && part.body?.attachmentId) {
      attachments.push({
        filename: part.filename,
        mimeType: part.mimeType || 'application/octet-stream',
        size: part.body.size || 0,
        attachmentId: part.body.attachmentId,
      });
    }
    if (part.mimeType === 'text/plain' && part.body?.data && !textBody) {
      textBody = decodeBase64UrlUtf8(part.body.data);
    } else if (part.mimeType === 'text/html' && part.body?.data && !htmlBody) {
      htmlBody = decodeBase64UrlUtf8(part.body.data);
    } else if (!part.parts && part.body?.data && !textBody && (!part.mimeType || part.mimeType.startsWith('text/'))) {
      textBody = decodeBase64UrlUtf8(part.body.data);
    }
    if (Array.isArray(part.parts)) {
      for (const child of part.parts) {
        walk(child);
      }
    }
  };

  walk(msg.payload);

  if (!textBody && htmlBody) {
    textBody = htmlBody
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  return {
    id: msg.id,
    threadId: msg.threadId || msg.id,
    subject,
    from,
    to,
    date,
    snippet: msg.snippet || '',
    labelIds,
    isUnread: labelIds.includes('UNREAD'),
    textBody: textBody || msg.snippet || '',
    htmlBody,
    attachments,
  };
}

export function buildDriveSearchQuery(options: {
  searchText?: string;
  filter?: DriveFilterKind;
  folderId?: string | null;
}): string {
  const clauses = ['trashed = false'];
  if (options.folderId) {
    const safeFolder = options.folderId.replace(/['\\]/g, '');
    clauses.push(`'${safeFolder}' in parents`);
  }
  if (options.filter === 'folders') {
    clauses.push("mimeType = 'application/vnd.google-apps.folder'");
  } else if (options.filter === 'videos') {
    clauses.push("mimeType contains 'video/'");
  } else if (options.filter === 'images') {
    clauses.push("mimeType contains 'image/'");
  } else if (options.filter === 'documents') {
    clauses.push(
      "(mimeType contains 'application/vnd.google-apps.' or mimeType = 'application/pdf' or mimeType = 'application/json' or mimeType contains 'text/')"
    );
  }
  const cleanSearch = (options.searchText || '').trim();
  if (cleanSearch) {
    const escaped = cleanSearch.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
    clauses.push(`name contains '${escaped}'`);
  }
  return clauses.join(' and ');
}

export function sanitizeDriveDisplayType(mimeType: string): string {
  if (mimeType === 'application/vnd.google-apps.folder') return 'Folder';
  if (mimeType === 'application/vnd.google-apps.document') return 'Google Doc';
  if (mimeType === 'application/vnd.google-apps.spreadsheet') return 'Google Sheet';
  if (mimeType === 'application/vnd.google-apps.presentation') return 'Google Slides';
  if (mimeType.startsWith('video/')) return `Video (${mimeType.replace('video/', '').toUpperCase()})`;
  if (mimeType.startsWith('image/')) return `Image (${mimeType.replace('image/', '').toUpperCase()})`;
  if (mimeType === 'application/json') return 'JSON';
  if (mimeType === 'application/pdf') return 'PDF';
  return mimeType.split('/').pop()?.toUpperCase() || 'File';
}
