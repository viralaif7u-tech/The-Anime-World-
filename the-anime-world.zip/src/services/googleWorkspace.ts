import {
  buildDriveSearchQuery,
  buildRawMimeEmail,
  parseGmailMessage,
  type DriveFileItem,
  type DriveFilterKind,
  type ParsedGmailMessage,
  type RawGmailMessage,
} from './googleWorkspaceHelpers';

const GMAIL_API_BASE = 'https://gmail.googleapis.com/gmail/v1/users/me';
const DRIVE_API_BASE = 'https://www.googleapis.com/drive/v3';
const DRIVE_UPLOAD_BASE = 'https://www.googleapis.com/upload/drive/v3/files';

// Strict in-memory token cache (never stored in localStorage or sessionStorage)
let cachedWorkspaceAccessToken: string | null = null;
let cachedWorkspaceEmail: string | null = null;
const tokenListeners = new Set<(token: string | null) => void>();

export class WorkspaceAuthError extends Error {
  constructor(message = 'Google Workspace authorization is required. Please sign in with Google.') {
    super(message);
    this.name = 'WorkspaceAuthError';
  }
}

export function setWorkspaceAccessToken(token: string | null, email?: string | null): void {
  cachedWorkspaceAccessToken = token;
  cachedWorkspaceEmail = token ? email ?? cachedWorkspaceEmail : null;
  tokenListeners.forEach((cb) => cb(cachedWorkspaceAccessToken));
}

export function clearWorkspaceAccessToken(): void {
  setWorkspaceAccessToken(null, null);
}

export function getWorkspaceAccessToken(): string | null {
  return cachedWorkspaceAccessToken;
}

export function getWorkspaceAccountEmail(): string | null {
  return cachedWorkspaceEmail;
}

export function subscribeWorkspaceToken(listener: (token: string | null) => void): () => void {
  tokenListeners.add(listener);
  return () => {
    tokenListeners.delete(listener);
  };
}

async function workspaceFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const token = cachedWorkspaceAccessToken;
  if (!token) {
    throw new WorkspaceAuthError();
  }

  const headers = new Headers(init.headers || {});
  headers.set('Authorization', `Bearer ${token}`);

  const res = await fetch(url, { ...init, headers });
  if (res.status === 401) {
    clearWorkspaceAccessToken();
    throw new WorkspaceAuthError('Your Google session expired. Please click "Sign in with Google" to reconnect.');
  }

  if (!res.ok) {
    let detail = `Google API request failed (${res.status}).`;
    try {
      const errJson = (await res.json()) as { error?: { message?: string } };
      if (errJson?.error?.message) {
        detail = errJson.error.message;
      }
    } catch {
      // Ignore parse errors on non-JSON bodies
    }
    throw new Error(detail);
  }

  return res;
}

/* ============================================================================
 * GMAIL API CLIENT
 * ========================================================================== */

export interface GmailLabel {
  id: string;
  name: string;
  type?: string;
}

export async function listGmailLabels(): Promise<GmailLabel[]> {
  const res = await workspaceFetch(`${GMAIL_API_BASE}/labels`);
  const data = (await res.json()) as { labels?: GmailLabel[] };
  return Array.isArray(data.labels) ? data.labels : [];
}

export async function listGmailMessages(params?: {
  q?: string;
  labelIds?: string[];
  maxResults?: number;
}): Promise<ParsedGmailMessage[]> {
  const search = new URLSearchParams();
  search.set('maxResults', String(params?.maxResults ?? 15));
  if (params?.q && params.q.trim()) {
    search.set('q', params.q.trim());
  }
  if (params?.labelIds && params.labelIds.length > 0) {
    for (const lid of params.labelIds) {
      search.append('labelIds', lid);
    }
  }

  const listRes = await workspaceFetch(`${GMAIL_API_BASE}/messages?${search.toString()}`);
  const listData = (await listRes.json()) as { messages?: Array<{ id: string }> };
  const stubs = Array.isArray(listData.messages) ? listData.messages : [];
  if (stubs.length === 0) return [];

  const details = await Promise.all(
    stubs.slice(0, 15).map(async (stub) => {
      const msgRes = await workspaceFetch(`${GMAIL_API_BASE}/messages/${encodeURIComponent(stub.id)}?format=full`);
      const rawMsg = (await msgRes.json()) as RawGmailMessage;
      return parseGmailMessage(rawMsg);
    })
  );

  return details;
}

export async function sendGmailMessage(params: {
  to: string;
  subject: string;
  body: string;
  cc?: string;
}): Promise<{ id: string; threadId?: string }> {
  const mime = buildRawMimeEmail(params);
  if (!mime.ok) {
    throw new Error(mime.error);
  }

  const res = await workspaceFetch(`${GMAIL_API_BASE}/messages/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ raw: mime.raw }),
  });

  return (await res.json()) as { id: string; threadId?: string };
}

export async function trashGmailMessage(messageId: string): Promise<void> {
  await workspaceFetch(`${GMAIL_API_BASE}/messages/${encodeURIComponent(messageId)}/trash`, {
    method: 'POST',
  });
}

export async function modifyGmailMessageLabels(
  messageId: string,
  changes: { addLabelIds?: string[]; removeLabelIds?: string[] }
): Promise<ParsedGmailMessage> {
  const res = await workspaceFetch(`${GMAIL_API_BASE}/messages/${encodeURIComponent(messageId)}/modify`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(changes),
  });
  const raw = (await res.json()) as RawGmailMessage;
  return parseGmailMessage(raw);
}

/* ============================================================================
 * GOOGLE DRIVE API CLIENT
 * ========================================================================== */

export async function listDriveFiles(params?: {
  searchText?: string;
  filter?: DriveFilterKind;
  folderId?: string | null;
  pageSize?: number;
}): Promise<DriveFileItem[]> {
  const q = buildDriveSearchQuery({
    searchText: params?.searchText,
    filter: params?.filter,
    folderId: params?.folderId,
  });

  const search = new URLSearchParams({
    q,
    pageSize: String(params?.pageSize ?? 25),
    orderBy: 'folder,modifiedTime desc',
    fields: 'files(id,name,mimeType,size,modifiedTime,webViewLink,thumbnailLink,iconLink,parents)',
  });

  const res = await workspaceFetch(`${DRIVE_API_BASE}/files?${search.toString()}`);
  const data = (await res.json()) as { files?: DriveFileItem[] };
  return Array.isArray(data.files) ? data.files : [];
}

export async function createDriveFolder(name: string, parentId?: string | null): Promise<DriveFileItem> {
  const cleanName = name.trim();
  if (!cleanName) {
    throw new Error('Folder name cannot be empty.');
  }

  const metadata: Record<string, unknown> = {
    name: cleanName.slice(0, 120),
    mimeType: 'application/vnd.google-apps.folder',
  };
  if (parentId) {
    metadata.parents = [parentId];
  }

  const res = await workspaceFetch(`${DRIVE_API_BASE}/files?fields=id,name,mimeType,modifiedTime,webViewLink`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(metadata),
  });
  return (await res.json()) as DriveFileItem;
}

export async function ensureAnimeWorldDriveFolder(): Promise<DriveFileItem> {
  const existing = await listDriveFiles({
    searchText: 'THE ANIME WORLD Library',
    filter: 'folders',
    pageSize: 5,
  });
  const exact = existing.find((f) => f.name === 'THE ANIME WORLD Library');
  if (exact) return exact;
  return createDriveFolder('THE ANIME WORLD Library');
}

export async function uploadFileToDrive(params: {
  name: string;
  mimeType: string;
  content: Blob | string;
  parentId?: string | null;
}): Promise<DriveFileItem> {
  const metadata: Record<string, unknown> = {
    name: params.name.trim().slice(0, 180) || 'anime-world-export',
    mimeType: params.mimeType || 'application/octet-stream',
  };
  if (params.parentId) {
    metadata.parents = [params.parentId];
  }

  const boundary = `aw_drive_boundary_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const contentBlob =
    typeof params.content === 'string'
      ? new Blob([params.content], { type: params.mimeType || 'text/plain;charset=utf-8' })
      : params.content;

  const multipartBody = new Blob([
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n`,
    JSON.stringify(metadata),
    `\r\n--${boundary}\r\nContent-Type: ${params.mimeType || 'application/octet-stream'}\r\n\r\n`,
    contentBlob,
    `\r\n--${boundary}--`,
  ]);

  const res = await workspaceFetch(
    `${DRIVE_UPLOAD_BASE}?uploadType=multipart&fields=id,name,mimeType,size,modifiedTime,webViewLink`,
    {
      method: 'POST',
      headers: {
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartBody,
    }
  );

  return (await res.json()) as DriveFileItem;
}

export async function downloadDriveFileToDevice(file: DriveFileItem): Promise<string> {
  let targetUrl = `${DRIVE_API_BASE}/files/${encodeURIComponent(file.id)}?alt=media`;
  let outputName = file.name;

  if (file.mimeType === 'application/vnd.google-apps.document') {
    targetUrl = `${DRIVE_API_BASE}/files/${encodeURIComponent(file.id)}/export?mimeType=application/pdf`;
    outputName = outputName.endsWith('.pdf') ? outputName : `${outputName}.pdf`;
  } else if (file.mimeType === 'application/vnd.google-apps.spreadsheet') {
    targetUrl = `${DRIVE_API_BASE}/files/${encodeURIComponent(file.id)}/export?mimeType=text/csv`;
    outputName = outputName.endsWith('.csv') ? outputName : `${outputName}.csv`;
  } else if (file.mimeType === 'application/vnd.google-apps.presentation') {
    targetUrl = `${DRIVE_API_BASE}/files/${encodeURIComponent(file.id)}/export?mimeType=application/pdf`;
    outputName = outputName.endsWith('.pdf') ? outputName : `${outputName}.pdf`;
  }

  const res = await workspaceFetch(targetUrl);
  const blob = await res.blob();
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = objectUrl;
  link.download = outputName;
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    URL.revokeObjectURL(objectUrl);
    link.remove();
  }, 1500);
  return outputName;
}

export async function trashDriveFile(fileId: string): Promise<void> {
  await workspaceFetch(`${DRIVE_API_BASE}/files/${encodeURIComponent(fileId)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ trashed: true }),
  });
}

export async function deleteDriveFilePermanently(fileId: string): Promise<void> {
  await workspaceFetch(`${DRIVE_API_BASE}/files/${encodeURIComponent(fileId)}`, {
    method: 'DELETE',
  });
}
