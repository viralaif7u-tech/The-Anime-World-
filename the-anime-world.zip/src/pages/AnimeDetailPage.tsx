import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { BookmarkPlus, Check, Heart, Share2, Star } from 'lucide-react';
import { SeoHead } from '../components/SeoHead';
import { LoadingPortalLogo } from '../components/BrandLogo';
import { AnimeCard } from '../components/AnimeCard';
import { useAuth } from '../context/AuthContext';
import { buildAnimeUrl, parseIdFromSlug } from '../lib/validation';
import type { AnimeDetail } from '../types/anime';

export function AnimeDetailPage() {
  const { id: slugParam } = useParams<{ id: string }>();
  const animeId = parseIdFromSlug(slugParam || '');
  const { user, collections, isFavorited, toggleFavorite, addToCollection, createCollection } = useAuth();

  const [detail, setDetail] = useState<AnimeDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [showColPicker, setShowColPicker] = useState(false);
  const [newColName, setNewColName] = useState('');

  useEffect(() => {
    if (!animeId) {
      setError('Invalid anime identifier.');
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    fetch(`/api/anime/${animeId}`)
      .then(async (res) => {
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Failed to load anime details.');
        return json as AnimeDetail;
      })
      .then((data) => {
        setDetail(data);
        try {
          const prev = JSON.parse(localStorage.getItem('aw_recently_viewed') || '[]') as Array<{
            id: number;
            title: string;
            image: string | null;
            url: string;
          }>;
          const next = [
            {
              id: data.id,
              title: data.displayTitle,
              image: data.coverImage.large,
              url: buildAnimeUrl(data.id, data.displayTitle),
            },
            ...prev.filter((x) => x.id !== data.id),
          ].slice(0, 12);
          localStorage.setItem('aw_recently_viewed', JSON.stringify(next));
        } catch {
          // Ignore storage error
        }
      })
      .catch((err) => setError(err instanceof Error ? err.message : 'Unable to load anime.'))
      .finally(() => setLoading(false));
  }, [animeId]);

  if (loading) return <LoadingPortalLogo />;

  if (error || !detail) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">Anime Entry Unavailable</h1>
        <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">{error || 'Entry not found.'}</p>
        <Link to="/explore" className="mt-6 inline-block rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#080812]">
          Back to Explore
        </Link>
      </div>
    );
  }

  const fav = isFavorited('anime', String(detail.id));
  const poster = detail.coverImage.extraLarge || detail.coverImage.large || '';
  const score = detail.averageScore ? (detail.averageScore / 10).toFixed(1) : 'N/A';

  const handleFav = async () => {
    try {
      const saved = await toggleFavorite({
        itemType: 'anime',
        itemId: String(detail.id),
        title: detail.displayTitle,
        imageUrl: poster,
        subtitle: [detail.format, detail.seasonYear].filter(Boolean).join(' · '),
      });
      setStatusMsg(saved ? 'Saved to favorites.' : 'Removed from favorites.');
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Sign in required.');
    }
  };

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setStatusMsg('Link copied to clipboard.');
    } catch {
      setStatusMsg('Share URL ready in your browser address bar.');
    }
  };

  const handleAddCollection = async (colId: string) => {
    try {
      await addToCollection(colId, {
        itemType: 'anime',
        itemId: String(detail.id),
        title: detail.displayTitle,
        imageUrl: poster,
      });
      setShowColPicker(false);
      setStatusMsg('Added to collection.');
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Could not add to collection.');
    }
  };

  const handleCreateAndAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColName.trim()) return;
    try {
      const colId = await createCollection(newColName.trim(), '', true);
      await addToCollection(colId, {
        itemType: 'anime',
        itemId: String(detail.id),
        title: detail.displayTitle,
        imageUrl: poster,
      });
      setNewColName('');
      setShowColPicker(false);
      setStatusMsg('Created collection and saved anime.');
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Could not create collection.');
    }
  };

  return (
    <div className="pb-16">
      <SeoHead
        title={detail.displayTitle}
        description={detail.synopsis.slice(0, 155)}
      />

      {/* Banner */}
      <div
        className={`relative w-full overflow-hidden border-b border-[var(--aw-border)] bg-[#10101F] ${
          detail.bannerImage ? 'h-56 sm:h-72' : 'h-32 sm:h-40'
        }`}
      >
        {detail.bannerImage ? (
          <img
            src={detail.bannerImage}
            alt={detail.displayTitle}
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover opacity-55"
          />
        ) : poster ? (
          <img
            src={poster}
            alt=""
            aria-hidden="true"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover opacity-25 scale-110"
          />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--aw-bg)] via-[var(--aw-bg)]/55 to-transparent" />
      </div>

      <div className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10 ${detail.bannerImage ? '-mt-28' : '-mt-20'}`}>
        <div className="grid grid-cols-1 gap-8 md:grid-cols-[240px_1fr]">
          {/* Poster + Actions */}
          <div className="space-y-4">
            <div className="overflow-hidden rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#10101F] aspect-[3/4] shadow-lg">
              {poster ? (
                <img
                  src={poster}
                  alt={detail.displayTitle}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full items-center justify-center p-4 text-center font-display text-lg">
                  {detail.displayTitle}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleFav}
                className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2.5 text-xs font-semibold transition-colors ${
                  fav
                    ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                    : 'border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF]'
                }`}
              >
                <Heart className={`h-4 w-4 ${fav ? 'fill-current' : ''}`} />
                {fav ? 'Favorited' : 'Favorite'}
              </button>

              <button
                type="button"
                onClick={() => void handleShare()}
                className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-3 py-2.5 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF]"
              >
                <Share2 className="h-4 w-4" />
                Share
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowColPicker((v) => !v)}
              className="flex w-full items-center justify-center gap-2 rounded-lg border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white/90 dark:bg-[#10101F]/90 px-4 py-2.5 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:bg-[#0284C7]/10 dark:hover:bg-[#43B8FF]/10"
            >
              <BookmarkPlus className="h-4 w-4" />
              Add to Collection
            </button>

            {showColPicker && (
              <div className="rounded-xl border border-[var(--aw-border-strong)] bg-white/95 dark:bg-[#10101F]/95 p-3.5 space-y-2.5">
                {!user ? (
                  <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                    <Link to="/login" className="text-[#0284C7] dark:text-[#43B8FF] underline">Sign in</Link> to organize anime into collections.
                  </p>
                ) : (
                  <>
                    {collections.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => void handleAddCollection(c.id)}
                        className="flex w-full items-center justify-between rounded-lg bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3 py-2 text-left text-xs text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] border border-[var(--aw-border)]"
                      >
                        <span className="truncate">{c.name}</span>
                        <span className="font-mono-tabular text-[#524E6B] dark:text-[#AAA7BC]">{c.itemsCount}</span>
                      </button>
                    ))}
                    <form onSubmit={handleCreateAndAdd} className="flex gap-1.5 pt-1">
                      <input
                        type="text"
                        value={newColName}
                        onChange={(e) => setNewColName(e.target.value)}
                        placeholder="New collection..."
                        className="min-w-0 flex-1 rounded-lg border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-2.5 py-1.5 text-xs text-[#141229] dark:text-[#F5F3FF]"
                      />
                      <button
                        type="submit"
                        className="rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-2.5 py-1.5 text-xs font-semibold text-white dark:text-[#080812]"
                      >
                        <Check className="h-3.5 w-3.5" />
                      </button>
                    </form>
                  </>
                )}
              </div>
            )}

            {statusMsg && (
              <p className="rounded-lg border border-[#0284C7]/30 dark:border-[#43B8FF]/30 bg-white/90 dark:bg-[#10101F]/90 px-3 py-2 text-xs text-[#0284C7] dark:text-[#43B8FF]">
                {statusMsg}
              </p>
            )}
          </div>

          {/* Main Metadata */}
          <div className="space-y-6 pt-2 md:pt-10">
            <div>
              <h1 className="font-display text-3xl font-extrabold text-[#141229] dark:text-[#F5F3FF] sm:text-4xl [text-wrap:balance]">
                {detail.displayTitle}
              </h1>
              <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
                {detail.title.romaji && detail.title.romaji !== detail.displayTitle && (
                  <span>{detail.title.romaji}</span>
                )}
                {detail.title.native && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>{detail.title.native}</span>
                  </>
                )}
              </div>

              <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                <span className="inline-flex items-center gap-1 font-mono-tabular text-[#0284C7] dark:text-[#43B8FF] font-semibold">
                  <Star className="h-3.5 w-3.5 fill-current" />
                  {score}/10
                </span>
                <span aria-hidden="true">·</span>
                <span>{detail.genres.join(' · ') || 'General'}</span>
                <span aria-hidden="true">·</span>
                <span>Source: {detail.externalSource}</span>
              </div>
            </div>

            <p className="text-sm leading-relaxed text-[#141229]/90 dark:text-[#F5F3FF]/90 whitespace-pre-line">
              {detail.synopsis}
            </p>

            {/* Specs Grid */}
            <div className="grid grid-cols-2 gap-4 rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-5 sm:grid-cols-4">
              <div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Format</div>
                <div className="mt-1 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{detail.format || 'N/A'}</div>
              </div>
              <div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Episodes</div>
                <div className="mt-1 font-mono-tabular text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">
                  {detail.episodes ?? 'Ongoing'}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Duration</div>
                <div className="mt-1 font-mono-tabular text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">
                  {detail.duration ? `${detail.duration} min` : 'N/A'}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Season</div>
                <div className="mt-1 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">
                  {[detail.season, detail.seasonYear].filter(Boolean).join(' ') || 'TBA'}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Status</div>
                <div className="mt-1 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] capitalize">
                  {detail.status ? detail.status.replace(/_/g, ' ').toLowerCase() : 'N/A'}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Studio</div>
                <div className="mt-1 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">
                  {detail.studios.join(', ') || 'Unknown'}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Source Material</div>
                <div className="mt-1 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] capitalize">
                  {detail.source ? detail.source.replace(/_/g, ' ').toLowerCase() : 'Original'}
                </div>
              </div>
              <div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Origin</div>
                <div className="mt-1 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">
                  {detail.countryOfOrigin === 'JP'
                    ? 'Japan'
                    : detail.countryOfOrigin === 'CN'
                    ? 'China'
                    : detail.countryOfOrigin === 'KR'
                    ? 'South Korea'
                    : detail.countryOfOrigin || 'Japan'}
                </div>
              </div>
            </div>

            {/* Trailer */}
            {detail.trailer?.site === 'youtube' && detail.trailer.id && (
              <div>
                <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Authorized Official Trailer</h2>
                <div className="mt-3 aspect-video overflow-hidden rounded-xl border border-[var(--aw-border)] bg-[#10101F]">
                  <iframe
                    src={`https://www.youtube-nocookie.com/embed/${detail.trailer.id}`}
                    title={`${detail.displayTitle} Official Trailer`}
                    allowFullScreen
                    className="h-full w-full"
                  />
                </div>
              </div>
            )}

            {/* Characters */}
            {detail.characters.length > 0 && (
              <div>
                <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Characters &amp; Cast</h2>
                <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {detail.characters.slice(0, 10).map((ch) => (
                    <Link
                      key={ch.id}
                      to={`/characters/${ch.id}`}
                      className="flex items-center justify-between gap-3 rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-2.5 hover:border-[#6D38E8]/50 dark:hover:border-[#9B5CFF]/50 transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {ch.image && (
                          <img
                            src={ch.image}
                            alt={ch.name}
                            referrerPolicy="no-referrer"
                            className="h-14 w-11 rounded-lg object-cover shrink-0"
                          />
                        )}
                        <div className="min-w-0">
                          <div className="truncate text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{ch.name}</div>
                          <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">{ch.role}</div>
                        </div>
                      </div>
                      {ch.voiceActor && (
                        <div className="text-right min-w-0 shrink-0">
                          <div className="truncate text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">{ch.voiceActor.name}</div>
                          <div className="text-[11px] text-[#524E6B] dark:text-[#AAA7BC]">{ch.voiceActor.language}</div>
                        </div>
                      )}
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Staff */}
            {detail.staff.length > 0 && (
              <div>
                <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Key Staff</h2>
                <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {detail.staff.map((st) => (
                    <div key={`${st.id}-${st.role}`} className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-3">
                      <div className="truncate text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{st.name}</div>
                      <div className="mt-0.5 truncate text-xs text-[#524E6B] dark:text-[#AAA7BC]">{st.role}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Recommendations */}
        {detail.recommendations.length > 0 && (
          <section className="mt-14 border-t border-[var(--aw-border)] pt-10">
            <h2 className="font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">Similar &amp; Recommended Anime</h2>
            <div className="mt-6 grid grid-cols-2 gap-5 sm:grid-cols-4">
              {detail.recommendations.slice(0, 4).map((rec) => (
                <AnimeCard key={rec.id} anime={rec} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
