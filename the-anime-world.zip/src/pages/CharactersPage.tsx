import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Heart, Search, Users } from 'lucide-react';
import { SeoHead } from '../components/SeoHead';
import { LoadingPortalLogo } from '../components/BrandLogo';
import { useAuth } from '../context/AuthContext';
import { buildAnimeUrl } from '../lib/validation';
import type { CharacterSummary } from '../types/anime';

export function CharactersPage() {
  const [search, setSearch] = useState('');
  const [debounced, setDebounced] = useState('');
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<CharacterSummary[]>([]);
  const [pageInfo, setPageInfo] = useState({ currentPage: 1, lastPage: 1, hasNextPage: false });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const t = setTimeout(() => {
      setDebounced(search.trim());
      setPage(1);
    }, 350);
    return () => clearTimeout(t);
  }, [search]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const qs = new URLSearchParams({ page: String(page), perPage: '24' });
    if (debounced) qs.set('search', debounced);
    try {
      const res = await fetch(`/api/characters?${qs.toString()}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to load characters.');
      setItems(json.items || []);
      setPageInfo(json.pageInfo || { currentPage: page, lastPage: 1, hasNextPage: false });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load characters.');
    } finally {
      setLoading(false);
    }
  }, [debounced, page]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead
        title="Anime Characters Directory"
        description="Search thousands of iconic anime characters, view profiles, favorites, and associated anime series."
      />

      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">
            <Users className="h-4 w-4" />
            <span>Global Character Archive</span>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Anime Characters Directory</h1>
        </div>
        <div className="relative w-full sm:w-80">
          <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search character name..."
            aria-label="Search characters"
            className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 py-2.5 pr-4 pl-10 text-sm text-[#141229] dark:text-[#F5F3FF] placeholder:text-[#524E6B]/60 dark:placeholder:text-[#AAA7BC]/60 focus:border-[#0284C7] dark:focus:border-[#43B8FF] focus:outline-none"
          />
        </div>
      </div>

      {loading ? (
        <LoadingPortalLogo />
      ) : error ? (
        <div className="mt-10 rounded-xl border border-red-500/40 bg-white/90 dark:bg-[#10101F]/90 p-8 text-center">
          <p className="text-sm text-red-700 dark:text-red-200">{error}</p>
        </div>
      ) : (
        <>
          <div className="mt-8 grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {items.map((ch) => (
              <Link
                key={ch.id}
                to={`/characters/${ch.id}`}
                className="group flex flex-col overflow-hidden rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 hover:border-[#6D38E8]/50 dark:hover:border-[#9B5CFF]/50 transition-colors"
              >
                <div className="aspect-[3/4] w-full overflow-hidden bg-[var(--aw-surface-elevated)] dark:bg-[#141428]">
                  {ch.image ? (
                    <img
                      src={ch.image}
                      alt={ch.name}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center p-3 text-center text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                      {ch.name}
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h2 className="truncate font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] group-hover:text-[#0284C7] dark:group-hover:text-[#43B8FF]">
                    {ch.name}
                  </h2>
                  <p className="mt-1 truncate text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                    {ch.media[0]?.title || ch.nativeName || 'Anime Character'}
                  </p>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-10 flex items-center justify-between border-t border-[var(--aw-border)] pt-6">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-4 py-2 text-xs font-medium text-[#141229] dark:text-[#F5F3FF] disabled:opacity-40"
            >
              <ChevronLeft className="h-4 w-4" /> Previous
            </button>
            <span className="font-mono-tabular text-xs text-[#524E6B] dark:text-[#AAA7BC]">
              Page {pageInfo.currentPage}
            </span>
            <button
              type="button"
              disabled={!pageInfo.hasNextPage}
              onClick={() => setPage((p) => p + 1)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-4 py-2 text-xs font-medium text-[#141229] dark:text-[#F5F3FF] disabled:opacity-40"
            >
              Next <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export function CharacterDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { isFavorited, toggleFavorite } = useAuth();
  const [character, setCharacter] = useState<CharacterSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    fetch(`/api/characters/${id}`)
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error('Character not found'))))
      .then((data) => setCharacter(data))
      .catch(() => setCharacter(null))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <LoadingPortalLogo />;
  if (!character) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <h1 className="font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">Character Not Found</h1>
        <Link to="/characters" className="mt-5 inline-block rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#080812]">
          Back to Characters
        </Link>
      </div>
    );
  }

  const fav = isFavorited('character', String(character.id));

  const handleBookmark = async () => {
    try {
      const saved = await toggleFavorite({
        itemType: 'character',
        itemId: String(character.id),
        title: character.name,
        imageUrl: character.image || '',
        subtitle: character.media[0]?.title || '',
      });
      setMsg(saved ? 'Character bookmarked to favorites.' : 'Removed from favorites.');
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Sign in required.');
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
      <SeoHead title={character.name} description={character.description.slice(0, 150)} />

      <div className="grid grid-cols-1 gap-8 md:grid-cols-[260px_1fr]">
        <div className="space-y-4">
          <div className="overflow-hidden rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#10101F] aspect-[3/4]">
            {character.image && (
              <img src={character.image} alt={character.name} referrerPolicy="no-referrer" className="h-full w-full object-cover" />
            )}
          </div>
          <button
            type="button"
            onClick={() => void handleBookmark()}
            className={`flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-xs font-semibold ${
              fav
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF]'
            }`}
          >
            <Heart className={`h-4 w-4 ${fav ? 'fill-current' : ''}`} />
            {fav ? 'Bookmarked' : 'Bookmark Character'}
          </button>
          {msg && <p className="text-xs text-[#0284C7] dark:text-[#43B8FF]">{msg}</p>}
        </div>

        <div>
          <h1 className="font-display text-3xl font-extrabold text-[#141229] dark:text-[#F5F3FF]">{character.name}</h1>
          {character.nativeName && <p className="mt-1 text-sm text-[#524E6B] dark:text-[#AAA7BC]">{character.nativeName}</p>}
          <p className="mt-2 font-mono-tabular text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF]">
            {character.favourites.toLocaleString()} AniList Favorites
          </p>
          <p className="mt-5 text-sm leading-relaxed text-[#141229]/90 dark:text-[#F5F3FF]/90 whitespace-pre-line">
            {character.description}
          </p>

          {character.media.length > 0 && (
            <div className="mt-8">
              <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Appears In</h2>
              <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
                {character.media.map((m) => (
                  <Link
                    key={m.id}
                    to={buildAnimeUrl(m.id, m.title)}
                    className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 overflow-hidden hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors"
                  >
                    {m.coverImage && (
                      <img src={m.coverImage} alt={m.title} referrerPolicy="no-referrer" className="aspect-[3/4] w-full object-cover" />
                    )}
                    <div className="p-2.5">
                      <div className="truncate text-xs font-semibold text-[#141229] dark:text-[#F5F3FF]">{m.title}</div>
                      {m.format && <div className="text-[11px] text-[#524E6B] dark:text-[#AAA7BC]">{m.format}</div>}
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
