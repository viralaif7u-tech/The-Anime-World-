import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Eye, Lock, Shield, Trash2, User as UserIcon } from 'lucide-react';
import { SeoHead } from '../components/SeoHead';
import { LoadingPortalLogo } from '../components/BrandLogo';
import { useAuth } from '../context/AuthContext';
import { useDownloads } from '../context/DownloadContext';
import { updateUserPrivacyPreferences } from '../services/firebase';

export function PrivacySettingsPage() {
  const { user, authReady, publicProfile, privateUser, showFeedback } = useAuth();
  const { clearAllSavedDownloads, savedDownloads } = useDownloads();

  const [isPublic, setIsPublic] = useState(true);
  const [saveDownloadHistory, setSaveDownloadHistory] = useState(true);
  const [hideViewingActivity, setHideViewingActivity] = useState(false);
  const [saving, setSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    if (publicProfile) {
      setIsPublic(publicProfile.isPublic);
    }
    if (privateUser) {
      setSaveDownloadHistory(privateUser.saveDownloadHistory !== false);
      setHideViewingActivity(Boolean(privateUser.hideViewingActivity));
    }
  }, [publicProfile, privateUser]);

  if (!authReady) return <LoadingPortalLogo />;

  if (!user) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <SeoHead title="Privacy Settings" description="Manage your THE ANIME WORLD privacy controls." />
        <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-8 shadow-xl">
          <Shield className="mx-auto h-10 w-10 text-[#6D38E8] dark:text-[#9B5CFF]" />
          <h1 className="mt-4 font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">
            Sign In to Manage Privacy Settings
          </h1>
          <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Every user account keeps favorites, download records, and private email isolated under strict ownership rules.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link
              to="/login"
              className="inline-flex min-h-[44px] items-center rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#080812]"
            >
              Login
            </Link>
            <Link
              to="/register"
              className="inline-flex min-h-[44px] items-center rounded-xl border border-[var(--aw-border-strong)] px-5 py-2.5 text-sm font-medium text-[#141229] dark:text-[#F5F3FF]"
            >
              Sign Up
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleSavePrivacy = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setStatusMsg(null);
    const res = await updateUserPrivacyPreferences({
      isPublic,
      saveDownloadHistory,
      hideViewingActivity,
    });
    setSaving(false);
    setStatusMsg(res.message);
    showFeedback(res.ok ? 'success' : 'error', res.message);
  };

  const handleClearRecentBrowsing = () => {
    try {
      localStorage.removeItem('aw_recently_viewed');
      setStatusMsg('Local recently viewed anime history cleared from this device.');
      showFeedback('success', 'Recently viewed anime history cleared.');
    } catch {
      setStatusMsg('Unable to clear local storage on this browser.');
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
      <SeoHead
        title="Privacy Settings"
        description="Control profile visibility, download history recording, and private data isolation."
      />

      <div className="border-b border-[var(--aw-border)] pb-5">
        <p className="text-xs font-semibold uppercase tracking-wider text-[#0284C7] dark:text-[#43B8FF]">
          Data Protection &amp; Isolation
        </p>
        <h1 className="mt-1 font-display text-3xl font-extrabold text-[#141229] dark:text-[#F5F3FF]">
          Privacy Settings
        </h1>
        <p className="mt-1 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
          Your email, downloads, favorites, and private collections are accessible only to your authenticated account.
        </p>
      </div>

      {statusMsg && (
        <div
          role="status"
          className="rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white/95 dark:bg-[#10101F]/95 px-4 py-3 text-xs text-[#0284C7] dark:text-[#43B8FF]"
        >
          {statusMsg}
        </div>
      )}

      <form
        onSubmit={(e) => void handleSavePrivacy(e)}
        className="rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-6 space-y-5"
      >
        <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">
          Visibility &amp; History Controls
        </h2>

        <label className="flex items-start gap-3.5 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/50 dark:bg-[#080812]/80 p-4 cursor-pointer">
          <input
            type="checkbox"
            checked={isPublic}
            onChange={(e) => setIsPublic(e.target.checked)}
            className="mt-1 h-4 w-4 accent-[#6D38E8] dark:accent-[#9B5CFF]"
          />
          <div>
            <div className="flex items-center gap-1.5 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">
              <Eye className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
              Public Creator Profile Discoverability
            </div>
            <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
              When enabled, your display name, username, and public collections can appear in Community Creator pages. Your email address and private data remain hidden.
            </p>
          </div>
        </label>

        <label className="flex items-start gap-3.5 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/50 dark:bg-[#080812]/80 p-4 cursor-pointer">
          <input
            type="checkbox"
            checked={saveDownloadHistory}
            onChange={(e) => setSaveDownloadHistory(e.target.checked)}
            className="mt-1 h-4 w-4 accent-[#6D38E8] dark:accent-[#9B5CFF]"
          />
          <div>
            <div className="flex items-center gap-1.5 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">
              <Lock className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
              Save Private Video Download History
            </div>
            <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
              Record completed and failed MP4 downloads in your private My Downloads library so you can re-download videos across sessions. Never visible to other users.
            </p>
          </div>
        </label>

        <label className="flex items-start gap-3.5 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/50 dark:bg-[#080812]/80 p-4 cursor-pointer">
          <input
            type="checkbox"
            checked={hideViewingActivity}
            onChange={(e) => setHideViewingActivity(e.target.checked)}
            className="mt-1 h-4 w-4 accent-[#6D38E8] dark:accent-[#9B5CFF]"
          />
          <div>
            <div className="flex items-center gap-1.5 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">
              <UserIcon className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
              Hide Recent Viewing Activity on Dashboard
            </div>
            <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
              Hides the local recently viewed anime strip on your dashboard overview.
            </p>
          </div>
        </label>

        <button
          type="submit"
          disabled={saving}
          className="inline-flex min-h-[44px] items-center justify-center rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-5 py-2.5 text-xs font-bold text-white dark:text-[#080812] disabled:opacity-60"
        >
          {saving ? 'Saving Preferences...' : 'Save Privacy Preferences'}
        </button>
      </form>

      {/* Data Cleanup Controls */}
      <div className="rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-6 space-y-4">
        <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">
          Clear Stored Activity
        </h2>
        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => void clearAllSavedDownloads()}
            disabled={savedDownloads.length === 0}
            className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-red-500/35 px-4 py-2 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-500/10 disabled:opacity-50"
          >
            <Trash2 className="h-4 w-4" />
            Clear My Downloads History ({savedDownloads.length})
          </button>

          <button
            type="button"
            onClick={handleClearRecentBrowsing}
            className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-[var(--aw-border-strong)] px-4 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8]"
          >
            <Trash2 className="h-4 w-4" />
            Clear Device Viewing History
          </button>
        </div>
      </div>

      {/* Security Verification Status */}
      <div className="rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-6 flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="h-4 w-4" />
            Zero-Trust Ownership Isolation Active
          </div>
          <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">
            PII ({user.email}) is stored separately from public profiles, and Firestore rules restrict downloads and favorites strictly to your UID.
          </p>
        </div>
        <Link
          to="/settings"
          className="inline-flex min-h-[44px] items-center rounded-xl border border-[var(--aw-border-strong)] px-4 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7]"
        >
          Security &amp; Password →
        </Link>
      </div>
    </div>
  );
}
