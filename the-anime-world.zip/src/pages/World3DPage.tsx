import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Box, Heart } from 'lucide-react';
import { AnimeModelViewer } from '../components/three/AnimeModelViewer';
import { SeoHead } from '../components/SeoHead';
import { MODELS_3D_CATALOG } from '../data/catalog';
import { useAuth } from '../context/AuthContext';

export function World3DPage() {
  const [selectedId, setSelectedId] = useState(MODELS_3D_CATALOG[0].id);
  const active = MODELS_3D_CATALOG.find((m) => m.id === selectedId) || MODELS_3D_CATALOG[0];

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead
        title="3D Anime World Museum"
        description="Explore interactive 360-degree 3D anime characters, mecha frames, dimensional relics, and custom GLB/GLTF models."
      />

      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-[#6D38E8] dark:text-[#9B5CFF]">
            <Box className="h-4 w-4" />
            <span>Interactive Digital Museum</span>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">3D Anime World</h1>
          <p className="mt-2 max-w-2xl text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Inspect procedural multi-part 3D anime sculptures with physically-based finishes, exploded layer controls, or load your own authorized GLB/GLTF model.
          </p>
        </div>
        <Link
          to={`/3d-world/${active.id}`}
          className="rounded-lg border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-4 py-2 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF]"
        >
          Open Dedicated Model Page
        </Link>
      </div>

      <div className="mt-6">
        <AnimeModelViewer model={active} heightClass="h-[520px] sm:h-[580px]" />
      </div>

      <h2 className="mt-12 font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Featured 3D Collections</h2>
      <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {MODELS_3D_CATALOG.map((m) => (
          <div
            key={m.id}
            className={`rounded-xl border bg-white/90 dark:bg-[#10101F]/90 overflow-hidden transition-colors ${
              m.id === active.id
                ? 'border-[#6D38E8] dark:border-[#9B5CFF]'
                : 'border-[var(--aw-border)] hover:border-[var(--aw-border-strong)]'
            }`}
          >
            <div className="aspect-video w-full overflow-hidden bg-[#080812]">
              <img src={m.previewImage} alt={m.title} referrerPolicy="no-referrer" className="h-full w-full object-cover opacity-90" />
            </div>
            <div className="p-4 space-y-2">
              <div className="text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">{m.category} · {m.partsCount} composite parts</div>
              <h3 className="font-display text-base font-semibold text-[#141229] dark:text-[#F5F3FF]">{m.title}</h3>
              <p className="text-xs leading-relaxed text-[#524E6B] dark:text-[#AAA7BC] line-clamp-2">{m.description}</p>
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedId(m.id)}
                  className="rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-3.5 py-2 text-xs font-semibold text-white dark:text-[#080812] hover:bg-[#5b2cd1] dark:hover:bg-[#8a46f7]"
                >
                  Load in Viewport
                </button>
                <Link
                  to={`/3d-world/${m.id}`}
                  className="rounded-lg border border-[var(--aw-border-strong)] px-3.5 py-2 text-xs font-medium text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF]"
                >
                  Details
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Model3DDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { isFavorited, toggleFavorite } = useAuth();
  const [msg, setMsg] = useState<string | null>(null);

  const model = MODELS_3D_CATALOG.find((m) => m.id === id) || MODELS_3D_CATALOG[0];
  const fav = isFavorited('model3d', model.id);

  const handleSave = async () => {
    try {
      const saved = await toggleFavorite({
        itemType: 'model3d',
        itemId: model.id,
        title: model.title,
        imageUrl: model.previewImage,
        subtitle: model.category,
      });
      setMsg(saved ? '3D model saved to favorites.' : 'Removed from favorites.');
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Sign in required.');
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title={model.title} description={model.description} />

      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <Link to="/3d-world" className="text-xs font-medium text-[#0284C7] dark:text-[#43B8FF] hover:underline">
            ← Back to 3D Anime World
          </Link>
          <h1 className="mt-2 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">{model.title}</h1>
          <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">{model.category} · Created by {model.artist}</p>
        </div>

        <button
          type="button"
          onClick={() => void handleSave()}
          className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-xs font-semibold ${
            fav
              ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
              : 'border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 text-[#141229] dark:text-[#F5F3FF]'
          }`}
        >
          <Heart className={`h-4 w-4 ${fav ? 'fill-current' : ''}`} />
          {fav ? 'Saved 3D Model' : 'Save 3D Model'}
        </button>
      </div>

      {msg && <p className="mb-4 text-xs text-[#0284C7] dark:text-[#43B8FF]">{msg}</p>}

      <AnimeModelViewer model={model} heightClass="h-[560px]" />

      <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
          <h2 className="font-display text-lg font-semibold text-[#141229] dark:text-[#F5F3FF]">About This 3D Showcase</h2>
          <p className="mt-2 text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">{model.description}</p>
        </div>
        <div className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-2 text-sm">
          <h2 className="font-display text-lg font-semibold text-[#141229] dark:text-[#F5F3FF]">Technical Specifications</h2>
          <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]"><strong className="text-[#141229] dark:text-[#F5F3FF]">Architecture:</strong> {model.specs.architecture}</p>
          <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]"><strong className="text-[#141229] dark:text-[#F5F3FF]">Lighting:</strong> {model.specs.lightingRig}</p>
          <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]"><strong className="text-[#141229] dark:text-[#F5F3FF]">Features:</strong> {model.specs.interactiveFeatures.join(' · ')}</p>
        </div>
      </div>
    </div>
  );
}
