import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  AlertCircle,
  CheckCircle2,
  ChevronRight,
  Download,
  ExternalLink,
  FileText,
  Film,
  Folder,
  FolderPlus,
  HardDrive,
  Image as ImageIcon,
  Inbox,
  Loader2,
  LogOut,
  Mail,
  MailOpen,
  PenSquare,
  RefreshCw,
  Search,
  Send,
  Sparkles,
  Trash2,
  Upload,
} from 'lucide-react';
import { SeoHead } from '../components/SeoHead';
import { GoogleSignInButton } from '../components/GoogleSignInButton';
import {
  WorkspaceConfirmModal,
  type WorkspaceConfirmRequest,
} from '../components/WorkspaceConfirmModal';
import { useAuth } from '../context/AuthContext';
import {
  createDriveFolder,
  deleteDriveFilePermanently,
  downloadDriveFileToDevice,
  ensureAnimeWorldDriveFolder,
  getWorkspaceAccountEmail,
  listDriveFiles,
  listGmailMessages,
  modifyGmailMessageLabels,
  sendGmailMessage,
  trashDriveFile,
  trashGmailMessage,
  uploadFileToDrive,
  WorkspaceAuthError,
} from '../services/googleWorkspace';
import {
  sanitizeDriveDisplayType,
  type DriveFileItem,
  type DriveFilterKind,
  type ParsedGmailMessage,
} from '../services/googleWorkspaceHelpers';
import { formatBytes } from '../services/videoDownloadHelpers';

const GMAIL_FILTERS = [
  { id: 'INBOX', label: 'Inbox' },
  { id: 'UNREAD', label: 'Unread' },
  { id: 'STARRED', label: 'Starred' },
  { id: 'SENT', label: 'Sent' },
] as const;

const DRIVE_FILTERS: Array<{ id: DriveFilterKind; label: string }> = [
  { id: 'all', label: 'All Files' },
  { id: 'folders', label: 'Folders' },
  { id: 'videos', label: 'Videos' },
  { id: 'images', label: 'Images' },
  { id: 'documents', label: 'Docs & JSON' },
];

function formatDateShort(raw?: string): string {
  if (!raw) return '';
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return raw.slice(0, 16);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

export function WorkspaceHubPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialTab = searchParams.get('tab') === 'drive' ? 'drive' : 'gmail';

  const {
    user,
    favorites,
    collections,
    workspaceAccessToken,
    needsWorkspaceAuth,
    connectGoogleWorkspace,
    disconnectGoogleWorkspace,
    showFeedback,
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'gmail' | 'drive'>(initialTab);
  const [connecting, setConnecting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Confirmation modal state (gates ALL Gmail & Drive mutations/deletions)
  const [confirmRequest, setConfirmRequest] = useState<WorkspaceConfirmRequest | null>(null);
  const [confirmBusy, setConfirmBusy] = useState(false);

  // Gmail state
  const [gmailLabel, setGmailLabel] = useState<string>('INBOX');
  const [gmailQuery, setGmailQuery] = useState('');
  const [gmailMessages, setGmailMessages] = useState<ParsedGmailMessage[]>([]);
  const [gmailLoading, setGmailLoading] = useState(false);
  const [gmailError, setGmailError] = useState<string | null>(null);
  const [selectedEmail, setSelectedEmail] = useState<ParsedGmailMessage | null>(null);
  const [showCompose, setShowCompose] = useState(false);
  const [composeTo, setComposeTo] = useState('');
  const [composeCc, setComposeCc] = useState('');
  const [composeSubject, setComposeSubject] = useState('');
  const [composeBody, setComposeBody] = useState('');

  // Drive state
  const [driveFilter, setDriveFilter] = useState<DriveFilterKind>('all');
  const [driveSearch, setDriveSearch] = useState('');
  const [driveFiles, setDriveFiles] = useState<DriveFileItem[]>([]);
  const [driveLoading, setDriveLoading] = useState(false);
  const [driveError, setDriveError] = useState<string | null>(null);
  const [folderTrail, setFolderTrail] = useState<Array<{ id: string | null; name: string }>>([
    { id: null, name: 'My Drive' },
  ]);
  const [newFolderName, setNewFolderName] = useState('');
  const [showNewFolderInput, setShowNewFolderInput] = useState(false);
  const [busyFileId, setBusyFileId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const currentFolder = folderTrail[folderTrail.length - 1];

  useEffect(() => {
    const t = searchParams.get('tab');
    if (t === 'drive' || t === 'gmail') {
      setActiveTab(t);
    }
    const shareTitle = searchParams.get('shareTitle');
    if (shareTitle) {
      setActiveTab('gmail');
      setShowCompose(true);
      setComposeSubject(`Anime Recommendation: ${shareTitle}`);
      setComposeBody(
        `Hey!\n\nI discovered "${shareTitle}" on THE ANIME WORLD and wanted to share it with you.\n\nWatch & explore more: ${window.location.origin}`
      );
    }
  }, [searchParams]);

  const switchTab = (next: 'gmail' | 'drive') => {
    setActiveTab(next);
    setSearchParams({ tab: next }, { replace: true });
  };

  const handleConnectGoogle = async () => {
    setAuthError(null);
    setConnecting(true);
    try {
      await connectGoogleWorkspace();
      showFeedback('success', 'Connected Gmail and Google Drive for this session.');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to connect Google Workspace.';
      setAuthError(msg);
      showFeedback('error', msg);
    } finally {
      setConnecting(false);
    }
  };

  const loadEmails = useCallback(async () => {
    if (!workspaceAccessToken) return;
    setGmailLoading(true);
    setGmailError(null);
    try {
      const list = await listGmailMessages({
        q: gmailQuery,
        labelIds: gmailQuery.trim() ? undefined : [gmailLabel],
        maxResults: 15,
      });
      setGmailMessages(list);
      setSelectedEmail((prev) => (prev ? list.find((m) => m.id === prev.id) || list[0] || null : list[0] || null));
    } catch (err) {
      if (err instanceof WorkspaceAuthError) {
        setAuthError(err.message);
      } else {
        setGmailError(err instanceof Error ? err.message : 'Could not load Gmail messages.');
      }
    } finally {
      setGmailLoading(false);
    }
  }, [workspaceAccessToken, gmailQuery, gmailLabel]);

  const loadDrive = useCallback(async () => {
    if (!workspaceAccessToken) return;
    setDriveLoading(true);
    setDriveError(null);
    try {
      const files = await listDriveFiles({
        searchText: driveSearch,
        filter: driveFilter,
        folderId: driveSearch.trim() ? null : currentFolder.id,
        pageSize: 30,
      });
      setDriveFiles(files);
    } catch (err) {
      if (err instanceof WorkspaceAuthError) {
        setAuthError(err.message);
      } else {
        setDriveError(err instanceof Error ? err.message : 'Could not load Google Drive files.');
      }
    } finally {
      setDriveLoading(false);
    }
  }, [workspaceAccessToken, driveSearch, driveFilter, currentFolder.id]);

  useEffect(() => {
    if (!workspaceAccessToken) return;
    if (activeTab === 'gmail') {
      void loadEmails();
    } else {
      void loadDrive();
    }
  }, [workspaceAccessToken, activeTab, loadEmails, loadDrive]);

  const runConfirmedAction = async () => {
    if (!confirmRequest) return;
    setConfirmBusy(true);
    try {
      await confirmRequest.onConfirm();
      setConfirmRequest(null);
    } catch (err) {
      showFeedback('error', err instanceof Error ? err.message : 'Operation failed.');
    } finally {
      setConfirmBusy(false);
    }
  };

  /* -------------------- GMAIL ACTIONS -------------------- */

  const handleRequestSendEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!composeTo.trim() || !composeSubject.trim() || !composeBody.trim()) {
      showFeedback('error', 'Please fill in recipient email, subject, and message body.');
      return;
    }
    setConfirmRequest({
      title: 'Send Email via Gmail?',
      description: 'Confirm sending this email from your connected Gmail account.',
      details: [
        `To: ${composeTo.trim()}`,
        ...(composeCc.trim() ? [`CC: ${composeCc.trim()}`] : []),
        `Subject: ${composeSubject.trim()}`,
        `Preview: ${composeBody.trim().slice(0, 110)}${composeBody.trim().length > 110 ? '...' : ''}`,
      ],
      confirmLabel: 'Send Email',
      tone: 'primary',
      onConfirm: async () => {
        await sendGmailMessage({
          to: composeTo.trim(),
          cc: composeCc.trim() || undefined,
          subject: composeSubject.trim(),
          body: composeBody.trim(),
        });
        showFeedback('success', `Email sent to ${composeTo.trim()} via Gmail.`);
        setComposeTo('');
        setComposeCc('');
        setComposeSubject('');
        setComposeBody('');
        setShowCompose(false);
        await loadEmails();
      },
    });
  };

  const handleInsertWatchlistInEmail = () => {
    const topFavs = favorites
      .slice(0, 8)
      .map((f, i) => `${i + 1}. ${f.title} (${f.itemType})`)
      .join('\n');
    const colLines = collections
      .slice(0, 4)
      .map((c) => `• ${c.name} (${c.itemsCount} items)`)
      .join('\n');

    setComposeSubject((prev) => prev || 'My Anime World Watchlist & Favorites');
    setComposeBody(
      [
        'Here is my curated anime watchlist from THE ANIME WORLD:',
        '',
        topFavs || 'No saved favorites yet — explore trending titles at THE ANIME WORLD!',
        colLines ? `\nCollections:\n${colLines}` : '',
        `\nExplore more: ${window.location.origin}`,
      ]
        .filter(Boolean)
        .join('\n')
    );
  };

  const handleToggleUnread = (msg: ParsedGmailMessage) => {
    const markingRead = msg.isUnread;
    setConfirmRequest({
      title: markingRead ? 'Mark Email as Read?' : 'Mark Email as Unread?',
      description: `Update Gmail status for "${msg.subject}".`,
      details: [`From: ${msg.from}`],
      confirmLabel: markingRead ? 'Mark Read' : 'Mark Unread',
      tone: 'primary',
      onConfirm: async () => {
        const updated = await modifyGmailMessageLabels(
          msg.id,
          markingRead ? { removeLabelIds: ['UNREAD'] } : { addLabelIds: ['UNREAD'] }
        );
        setGmailMessages((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
        setSelectedEmail(updated);
        showFeedback('success', markingRead ? 'Marked email as read.' : 'Marked email as unread.');
      },
    });
  };

  const handleTrashEmail = (msg: ParsedGmailMessage) => {
    setConfirmRequest({
      title: 'Move Email to Gmail Trash?',
      description: 'This email will be moved to Trash in your Gmail account.',
      details: [`Subject: ${msg.subject}`, `From: ${msg.from}`],
      confirmLabel: 'Move to Trash',
      tone: 'danger',
      onConfirm: async () => {
        await trashGmailMessage(msg.id);
        setGmailMessages((prev) => prev.filter((m) => m.id !== msg.id));
        setSelectedEmail((prev) => (prev?.id === msg.id ? null : prev));
        showFeedback('success', `Moved "${msg.subject}" to Gmail Trash.`);
      },
    });
  };

  /* -------------------- GOOGLE DRIVE ACTIONS -------------------- */

  const handleCreateFolderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newFolderName.trim();
    if (!clean) {
      showFeedback('error', 'Please enter a folder name.');
      return;
    }
    setConfirmRequest({
      title: 'Create Folder in Google Drive?',
      description: `Create a new folder inside "${currentFolder.name}".`,
      details: [`Folder Name: ${clean}`],
      confirmLabel: 'Create Folder',
      tone: 'primary',
      onConfirm: async () => {
        await createDriveFolder(clean, currentFolder.id);
        setNewFolderName('');
        setShowNewFolderInput(false);
        showFeedback('success', `Folder "${clean}" created in Google Drive.`);
        await loadDrive();
      },
    });
  };

  const handleLocalFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setConfirmRequest({
      title: 'Upload File to Google Drive?',
      description: `Upload this file from your device into "${currentFolder.name}".`,
      details: [
        `File: ${file.name}`,
        `Type: ${file.type || 'application/octet-stream'}`,
        `Size: ${formatBytes(file.size)}`,
      ],
      confirmLabel: 'Upload File',
      tone: 'primary',
      onConfirm: async () => {
        await uploadFileToDrive({
          name: file.name,
          mimeType: file.type || 'application/octet-stream',
          content: file,
          parentId: currentFolder.id,
        });
        showFeedback('success', `Uploaded "${file.name}" to Google Drive.`);
        await loadDrive();
      },
    });
  };

  const handleBackupFavoritesToDrive = () => {
    const payload = JSON.stringify(
      {
        exportedAt: new Date().toISOString(),
        accountEmail: user?.email || getWorkspaceAccountEmail() || 'guest',
        favorites,
        collections,
      },
      null,
      2
    );
    const filename = `AnimeWorld_Watchlist_${new Date().toISOString().slice(0, 10)}.json`;

    setConfirmRequest({
      title: 'Back Up Watchlist to Google Drive?',
      description:
        'Save your THE ANIME WORLD favorites and collections as a JSON backup inside "THE ANIME WORLD Library" folder in Google Drive.',
      details: [
        `File: ${filename}`,
        `Favorites: ${favorites.length} · Collections: ${collections.length}`,
        `Folder: THE ANIME WORLD Library`,
      ],
      confirmLabel: 'Save Backup to Drive',
      tone: 'primary',
      onConfirm: async () => {
        const folder = await ensureAnimeWorldDriveFolder();
        await uploadFileToDrive({
          name: filename,
          mimeType: 'application/json',
          content: payload,
          parentId: folder.id,
        });
        showFeedback('success', `Saved "${filename}" inside Google Drive → THE ANIME WORLD Library.`);
        await loadDrive();
      },
    });
  };

  const handleDownloadDriveFile = async (file: DriveFileItem) => {
    setBusyFileId(file.id);
    try {
      const savedName = await downloadDriveFileToDevice(file);
      showFeedback('success', `Downloaded "${savedName}" from Google Drive.`);
    } catch (err) {
      showFeedback('error', err instanceof Error ? err.message : 'Unable to download file from Drive.');
    } finally {
      setBusyFileId(null);
    }
  };

  const handleTrashDriveFile = (file: DriveFileItem) => {
    setConfirmRequest({
      title: 'Move Drive File to Trash?',
      description: 'Are you sure you want to move this item to your Google Drive Trash?',
      details: [`Name: ${file.name}`, `Type: ${sanitizeDriveDisplayType(file.mimeType)}`],
      confirmLabel: 'Move to Trash',
      tone: 'danger',
      onConfirm: async () => {
        await trashDriveFile(file.id);
        setDriveFiles((prev) => prev.filter((f) => f.id !== file.id));
        showFeedback('success', `Moved "${file.name}" to Google Drive Trash.`);
      },
    });
  };

  const handleDeleteDriveFileForever = (file: DriveFileItem) => {
    setConfirmRequest({
      title: 'Permanently Delete File from Google Drive?',
      description: 'This permanently deletes the file from Google Drive and skips Trash. This cannot be undone.',
      details: [`Name: ${file.name}`, `Type: ${sanitizeDriveDisplayType(file.mimeType)}`],
      confirmLabel: 'Delete Permanently',
      tone: 'danger',
      onConfirm: async () => {
        await deleteDriveFilePermanently(file.id);
        setDriveFiles((prev) => prev.filter((f) => f.id !== file.id));
        showFeedback('success', `Permanently deleted "${file.name}".`);
      },
    });
  };

  const connectedEmail = getWorkspaceAccountEmail() || user?.email || 'Google Account';

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 space-y-6">
      <SeoHead
        title="Gmail & Google Drive Workspace"
        description="Connect your Google account with permission to read and send Gmail messages and browse, upload, and manage Google Drive files inside THE ANIME WORLD."
      />

      {/* Page Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-5">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#0284C7] dark:text-[#43B8FF]">
            Connected Google Services
          </p>
          <h1 className="mt-1 font-display text-3xl font-extrabold text-[#141229] dark:text-[#F5F3FF]">
            Gmail &amp; Google Drive Hub
          </h1>
          <p className="mt-1.5 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Read and compose Gmail messages, share anime watchlists, and browse or back up files directly to Google Drive.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => switchTab('gmail')}
            data-testid="workspace-tab-gmail"
            className={`inline-flex min-h-[44px] items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-colors ${
              activeTab === 'gmail'
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
            }`}
          >
            <Mail className="h-4 w-4" />
            <span>Gmail</span>
          </button>
          <button
            type="button"
            onClick={() => switchTab('drive')}
            data-testid="workspace-tab-drive"
            className={`inline-flex min-h-[44px] items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold transition-colors ${
              activeTab === 'drive'
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
            }`}
          >
            <HardDrive className="h-4 w-4" />
            <span>Google Drive</span>
          </button>
        </div>
      </div>

      {/* Authentication Gate or Active Session Bar */}
      {needsWorkspaceAuth ? (
        <div className="rounded-2xl border border-[var(--aw-border-strong)] bg-white/95 dark:bg-[#10101F]/95 p-6 sm:p-8 shadow-sm">
          <div className="mx-auto max-w-2xl text-center space-y-4">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#6D38E8]/15 to-[#0284C7]/20 dark:from-[#9B5CFF]/20 dark:to-[#43B8FF]/20 text-[#0284C7] dark:text-[#43B8FF]">
              <Sparkles className="h-7 w-7" />
            </div>
            <h2 className="font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">
              Connect Your Google Account
            </h2>
            <p className="text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
              Sign in with Google to grant session access for Gmail and Google Drive. Access tokens remain strictly in memory for security and are cleared automatically when you log out or close this tab.
            </p>
            {authError && (
              <div
                role="alert"
                className="mx-auto max-w-lg rounded-xl border border-red-500/40 bg-red-50 dark:bg-red-950/30 px-4 py-3 text-xs text-red-700 dark:text-red-200"
              >
                {authError}
              </div>
            )}
            <div className="pt-2 flex justify-center">
              <GoogleSignInButton
                onClick={() => void handleConnectGoogle()}
                loading={connecting}
                label="Sign in with Google"
              />
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-500/35 bg-emerald-50/80 dark:bg-emerald-950/20 px-4 py-3">
          <div className="flex items-center gap-2.5 text-xs">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
            <span className="font-semibold text-emerald-900 dark:text-emerald-200">
              Google Workspace Active ({connectedEmail})
            </span>
          </div>
          <button
            type="button"
            onClick={() => {
              disconnectGoogleWorkspace();
              setGmailMessages([]);
              setDriveFiles([]);
              setSelectedEmail(null);
              showFeedback('success', 'Disconnected Google Workspace session token.');
            }}
            className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-1.5 text-xs font-semibold text-[#524E6B] dark:text-[#AAA7BC] hover:text-red-600 dark:hover:text-red-400"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Disconnect Session</span>
          </button>
        </div>
      )}

      {/* =====================================================================
          GMAIL WORKSPACE TAB
         ===================================================================== */}
      {!needsWorkspaceAuth && activeTab === 'gmail' && (
        <div className="space-y-5">
          {/* Gmail Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-4">
            <div className="flex flex-wrap items-center gap-1.5">
              {GMAIL_FILTERS.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => {
                    setGmailLabel(f.id);
                    setGmailQuery('');
                  }}
                  className={`min-h-[38px] rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                    gmailLabel === f.id && !gmailQuery
                      ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                      : 'border border-[var(--aw-border)] text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void loadEmails();
                }}
                className="relative flex-1 sm:w-64"
              >
                <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]" />
                <input
                  type="search"
                  value={gmailQuery}
                  onChange={(e) => setGmailQuery(e.target.value)}
                  placeholder="Search Gmail messages..."
                  aria-label="Search Gmail messages"
                  className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] py-2.5 pr-3 pl-9 text-xs text-[#141229] dark:text-[#F5F3FF]"
                />
              </form>

              <button
                type="button"
                onClick={() => void loadEmails()}
                disabled={gmailLoading}
                aria-label="Refresh Gmail inbox"
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] px-3.5 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7]"
              >
                <RefreshCw className={`h-4 w-4 ${gmailLoading ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>

              <button
                type="button"
                onClick={() => setShowCompose((prev) => !prev)}
                data-testid="gmail-compose-toggle"
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]"
              >
                <PenSquare className="h-4 w-4" />
                <span>{showCompose ? 'Hide Composer' : 'Compose'}</span>
              </button>
            </div>
          </div>

          {/* Gmail Compose Form */}
          {showCompose && (
            <form
              onSubmit={handleRequestSendEmail}
              data-testid="gmail-compose-form"
              className="rounded-2xl border border-[#6D38E8]/35 dark:border-[#9B5CFF]/35 bg-white/95 dark:bg-[#10101F]/95 p-5 space-y-4 shadow-md"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="font-display text-base font-bold text-[#141229] dark:text-[#F5F3FF]">
                  Compose Gmail Message
                </h2>
                <button
                  type="button"
                  onClick={handleInsertWatchlistInEmail}
                  className="inline-flex min-h-[36px] items-center gap-1.5 rounded-xl border border-[#0284C7]/45 dark:border-[#43B8FF]/45 px-3 py-1.5 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:bg-[#0284C7]/10"
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  <span>Insert My Anime Watchlist</span>
                </button>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label htmlFor="gmail-to" className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">
                    Recipient Email
                  </label>
                  <input
                    id="gmail-to"
                    type="email"
                    required
                    value={composeTo}
                    onChange={(e) => setComposeTo(e.target.value)}
                    placeholder="friend@example.com"
                    className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2.5 text-xs text-[#141229] dark:text-[#F5F3FF]"
                  />
                </div>
                <div>
                  <label htmlFor="gmail-cc" className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">
                    CC (Optional)
                  </label>
                  <input
                    id="gmail-cc"
                    type="email"
                    value={composeCc}
                    onChange={(e) => setComposeCc(e.target.value)}
                    placeholder="optional@example.com"
                    className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2.5 text-xs text-[#141229] dark:text-[#F5F3FF]"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="gmail-subject" className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">
                  Subject
                </label>
                <input
                  id="gmail-subject"
                  type="text"
                  required
                  value={composeSubject}
                  onChange={(e) => setComposeSubject(e.target.value)}
                  placeholder="Check out these anime series..."
                  className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2.5 text-xs text-[#141229] dark:text-[#F5F3FF]"
                />
              </div>

              <div>
                <label htmlFor="gmail-body" className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">
                  Message
                </label>
                <textarea
                  id="gmail-body"
                  required
                  rows={5}
                  value={composeBody}
                  onChange={(e) => setComposeBody(e.target.value)}
                  placeholder="Write your message..."
                  className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] p-3 text-xs text-[#141229] dark:text-[#F5F3FF]"
                />
              </div>

              <div className="flex flex-wrap justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCompose(false)}
                  className="min-h-[42px] rounded-xl border border-[var(--aw-border-strong)] px-4 py-2 text-xs font-semibold text-[#524E6B] dark:text-[#AAA7BC]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-5 py-2 text-xs font-semibold text-white dark:text-[#080812]"
                >
                  <Send className="h-4 w-4" />
                  <span>Review &amp; Send Email</span>
                </button>
              </div>
            </form>
          )}

          {gmailError && (
            <div
              role="alert"
              className="flex items-center gap-2 rounded-xl border border-red-500/40 bg-red-50 dark:bg-red-950/30 px-4 py-3 text-xs text-red-700 dark:text-red-200"
            >
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{gmailError}</span>
            </div>
          )}

          {/* Gmail Split Inbox + Reader */}
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
            {/* Message List */}
            <div className="lg:col-span-5 rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 overflow-hidden">
              <div className="border-b border-[var(--aw-border)] px-4 py-3 flex items-center justify-between">
                <span className="text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] inline-flex items-center gap-2">
                  <Inbox className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
                  Messages ({gmailMessages.length})
                </span>
              </div>

              {gmailLoading ? (
                <div className="flex items-center justify-center py-14 text-xs text-[#524E6B] dark:text-[#AAA7BC] gap-2">
                  <Loader2 className="h-4 w-4 animate-spin text-[#6D38E8] dark:text-[#9B5CFF]" />
                  Loading Gmail...
                </div>
              ) : gmailMessages.length === 0 ? (
                <div className="p-8 text-center text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                  No messages matched this filter.
                </div>
              ) : (
                <div className="divide-y divide-[var(--aw-border)] max-h-[560px] overflow-y-auto">
                  {gmailMessages.map((msg) => {
                    const active = selectedEmail?.id === msg.id;
                    return (
                      <button
                        key={msg.id}
                        type="button"
                        onClick={() => setSelectedEmail(msg)}
                        className={`w-full text-left px-4 py-3.5 transition-colors ${
                          active
                            ? 'bg-[#6D38E8]/10 dark:bg-[#9B5CFF]/15'
                            : 'hover:bg-[var(--aw-surface-elevated)]/60 dark:hover:bg-white/5'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className={`truncate text-xs ${msg.isUnread ? 'font-bold text-[#141229] dark:text-[#F5F3FF]' : 'font-medium text-[#524E6B] dark:text-[#AAA7BC]'}`}>
                            {msg.from}
                          </span>
                          <span className="shrink-0 text-[11px] text-[#524E6B] dark:text-[#AAA7BC]">
                            {formatDateShort(msg.date)}
                          </span>
                        </div>
                        <div className="mt-1 flex items-center gap-2">
                          {msg.isUnread && <span className="h-2 w-2 shrink-0 rounded-full bg-[#0284C7] dark:bg-[#43B8FF]" />}
                          <span className={`truncate text-xs ${msg.isUnread ? 'font-bold text-[#141229] dark:text-[#F5F3FF]' : 'font-semibold text-[#141229] dark:text-[#F5F3FF]'}`}>
                            {msg.subject}
                          </span>
                        </div>
                        <p className="mt-1 line-clamp-2 text-[11px] text-[#524E6B] dark:text-[#AAA7BC]">
                          {msg.snippet}
                        </p>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Email Viewer */}
            <div className="lg:col-span-7 rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-5 min-h-[340px]">
              {!selectedEmail ? (
                <div className="flex h-full flex-col items-center justify-center py-16 text-center text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                  <Mail className="h-8 w-8 mb-2 opacity-50" />
                  Select an email message from the list to inspect its full content.
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[var(--aw-border)] pb-4">
                    <div className="min-w-0 flex-1">
                      <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">
                        {selectedEmail.subject}
                      </h2>
                      <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                        From: <span className="font-semibold text-[#141229] dark:text-[#F5F3FF]">{selectedEmail.from}</span>
                      </p>
                      {selectedEmail.date && (
                        <p className="mt-0.5 text-[11px] text-[#524E6B] dark:text-[#AAA7BC]">{selectedEmail.date}</p>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const replyEmail = selectedEmail.from.match(/<([^>]+)>/)?.[1] || selectedEmail.from;
                          setComposeTo(replyEmail);
                          setComposeSubject(
                            selectedEmail.subject.startsWith('Re:') ? selectedEmail.subject : `Re: ${selectedEmail.subject}`
                          );
                          setComposeBody('');
                          setShowCompose(true);
                        }}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] px-3 py-1.5 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7]"
                      >
                        <Send className="h-3.5 w-3.5 text-[#0284C7] dark:text-[#43B8FF]" />
                        <span>Reply</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleToggleUnread(selectedEmail)}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] px-3 py-1.5 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8]"
                      >
                        <MailOpen className="h-3.5 w-3.5" />
                        <span>{selectedEmail.isUnread ? 'Mark Read' : 'Mark Unread'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleTrashEmail(selectedEmail)}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-red-500/35 px-3 py-1.5 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>Trash</span>
                      </button>
                    </div>
                  </div>

                  {selectedEmail.attachments.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {selectedEmail.attachments.map((att, idx) => (
                        <div
                          key={idx}
                          className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 px-2.5 py-1 text-[11px] text-[#141229] dark:text-[#F5F3FF]"
                        >
                          <FileText className="h-3.5 w-3.5 text-[#0284C7] dark:text-[#43B8FF]" />
                          <span>{att.filename}</span>
                          {att.size > 0 && <span className="opacity-70">({formatBytes(att.size)})</span>}
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="whitespace-pre-wrap rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/35 dark:bg-[#080812]/70 p-4 text-xs leading-relaxed text-[#141229] dark:text-[#F5F3FF] max-h-[420px] overflow-y-auto">
                    {selectedEmail.textBody}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          GOOGLE DRIVE WORKSPACE TAB
         ===================================================================== */}
      {!needsWorkspaceAuth && activeTab === 'drive' && (
        <div className="space-y-5">
          {/* Drive Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-4">
            <div className="flex flex-wrap items-center gap-1.5">
              {DRIVE_FILTERS.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setDriveFilter(f.id)}
                  className={`min-h-[38px] rounded-xl px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                    driveFilter === f.id
                      ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                      : 'border border-[var(--aw-border)] text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void loadDrive();
                }}
                className="relative flex-1 sm:w-56"
              >
                <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]" />
                <input
                  type="search"
                  value={driveSearch}
                  onChange={(e) => setDriveSearch(e.target.value)}
                  placeholder="Search Drive files..."
                  aria-label="Search Drive files"
                  className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] py-2.5 pr-3 pl-9 text-xs text-[#141229] dark:text-[#F5F3FF]"
                />
              </form>

              <button
                type="button"
                onClick={() => setShowNewFolderInput((v) => !v)}
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] px-3.5 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8]"
              >
                <FolderPlus className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
                <span>New Folder</span>
              </button>

              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={handleLocalFileSelected}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] px-3.5 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7]"
              >
                <Upload className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
                <span>Upload File</span>
              </button>

              <button
                type="button"
                onClick={handleBackupFavoritesToDrive}
                className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]"
              >
                <Sparkles className="h-4 w-4" />
                <span>Back Up Watchlist</span>
              </button>

              <button
                type="button"
                onClick={() => void loadDrive()}
                disabled={driveLoading}
                aria-label="Refresh Drive files"
                className="inline-flex min-h-[42px] min-w-[42px] items-center justify-center rounded-xl border border-[var(--aw-border-strong)] text-[#141229] dark:text-[#F5F3FF]"
              >
                <RefreshCw className={`h-4 w-4 ${driveLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>

          {showNewFolderInput && (
            <form
              onSubmit={handleCreateFolderSubmit}
              className="flex flex-wrap items-center gap-2 rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-4"
            >
              <input
                type="text"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder={`New folder inside ${currentFolder.name}...`}
                aria-label="New folder name"
                className="flex-1 min-w-[200px] rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2.5 text-xs text-[#141229] dark:text-[#F5F3FF]"
              />
              <button
                type="submit"
                className="min-h-[40px] rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]"
              >
                Create Folder
              </button>
              <button
                type="button"
                onClick={() => setShowNewFolderInput(false)}
                className="min-h-[40px] rounded-xl border border-[var(--aw-border-strong)] px-3.5 py-2 text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC]"
              >
                Cancel
              </button>
            </form>
          )}

          {/* Breadcrumbs */}
          {!driveSearch.trim() && (
            <nav aria-label="Google Drive folder path" className="flex flex-wrap items-center gap-1 text-xs">
              {folderTrail.map((crumb, idx) => {
                const isLast = idx === folderTrail.length - 1;
                return (
                  <React.Fragment key={crumb.id || 'root'}>
                    {idx > 0 && <ChevronRight className="h-3.5 w-3.5 text-[#524E6B] dark:text-[#AAA7BC]" />}
                    <button
                      type="button"
                      disabled={isLast}
                      onClick={() => setFolderTrail((prev) => prev.slice(0, idx + 1))}
                      className={`rounded-lg px-2 py-1 font-semibold ${
                        isLast
                          ? 'text-[#141229] dark:text-[#F5F3FF]'
                          : 'text-[#0284C7] dark:text-[#43B8FF] hover:underline'
                      }`}
                    >
                      {crumb.name}
                    </button>
                  </React.Fragment>
                );
              })}
            </nav>
          )}

          {driveError && (
            <div
              role="alert"
              className="flex items-center gap-2 rounded-xl border border-red-500/40 bg-red-50 dark:bg-red-950/30 px-4 py-3 text-xs text-red-700 dark:text-red-200"
            >
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{driveError}</span>
            </div>
          )}

          {/* Drive Files List */}
          {driveLoading ? (
            <div className="flex items-center justify-center rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 py-16 text-xs text-[#524E6B] dark:text-[#AAA7BC] gap-2">
              <Loader2 className="h-5 w-5 animate-spin text-[#0284C7] dark:text-[#43B8FF]" />
              Loading Google Drive files...
            </div>
          ) : driveFiles.length === 0 ? (
            <div className="rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-10 text-center">
              <HardDrive className="mx-auto h-9 w-9 text-[#0284C7] dark:text-[#43B8FF]" />
              <h2 className="mt-3 font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">
                No Files Found in This View
              </h2>
              <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                Upload a file, create a folder, or click &ldquo;Back Up Watchlist&rdquo; to save your Anime World data in Google Drive.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {driveFiles.map((file) => {
                const isFolder = file.mimeType === 'application/vnd.google-apps.folder';
                const isVideo = file.mimeType.startsWith('video/');
                const isImage = file.mimeType.startsWith('image/');
                return (
                  <div
                    key={file.id}
                    className="flex flex-col gap-3 rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-4 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]">
                        {isFolder ? (
                          <Folder className="h-5 w-5 text-[#6D38E8] dark:text-[#9B5CFF]" />
                        ) : isVideo ? (
                          <Film className="h-5 w-5 text-[#0284C7] dark:text-[#43B8FF]" />
                        ) : isImage ? (
                          <ImageIcon className="h-5 w-5 text-rose-500" />
                        ) : (
                          <FileText className="h-5 w-5 text-[#0284C7] dark:text-[#43B8FF]" />
                        )}
                      </div>

                      <div className="min-w-0">
                        {isFolder ? (
                          <button
                            type="button"
                            onClick={() => {
                              setDriveSearch('');
                              setFolderTrail((prev) => [...prev, { id: file.id, name: file.name }]);
                            }}
                            className="block truncate text-left font-display text-sm font-bold text-[#141229] dark:text-[#F5F3FF] hover:text-[#6D38E8] dark:hover:text-[#9B5CFF]"
                          >
                            {file.name}
                          </button>
                        ) : (
                          <div className="truncate font-display text-sm font-bold text-[#141229] dark:text-[#F5F3FF]">
                            {file.name}
                          </div>
                        )}
                        <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                          <span>{sanitizeDriveDisplayType(file.mimeType)}</span>
                          {file.size && <span className="font-mono-tabular">{formatBytes(Number(file.size))}</span>}
                          {file.modifiedTime && <span>Modified {formatDateShort(file.modifiedTime)}</span>}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      {isFolder ? (
                        <button
                          type="button"
                          onClick={() => {
                            setDriveSearch('');
                            setFolderTrail((prev) => [...prev, { id: file.id, name: file.name }]);
                          }}
                          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] px-3 py-1.5 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8]"
                        >
                          <Folder className="h-3.5 w-3.5 text-[#6D38E8] dark:text-[#9B5CFF]" />
                          <span>Open</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={busyFileId === file.id}
                          onClick={() => void handleDownloadDriveFile(file)}
                          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[#0284C7]/45 dark:border-[#43B8FF]/45 px-3 py-1.5 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:bg-[#0284C7]/10 disabled:opacity-60"
                        >
                          {busyFileId === file.id ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <Download className="h-3.5 w-3.5" />
                          )}
                          <span>Download</span>
                        </button>
                      )}

                      {file.webViewLink && (
                        <a
                          href={file.webViewLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] px-3 py-1.5 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7]"
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                          <span>Open in Drive</span>
                        </a>
                      )}

                      <button
                        type="button"
                        onClick={() => handleTrashDriveFile(file)}
                        className="inline-flex min-h-[40px] items-center gap-1 rounded-xl border border-amber-500/35 px-3 py-1.5 text-xs font-semibold text-amber-700 dark:text-amber-300 hover:bg-amber-500/10"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>Trash</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeleteDriveFileForever(file)}
                        aria-label={`Permanently delete ${file.name}`}
                        className="inline-flex min-h-[40px] items-center gap-1 rounded-xl border border-red-500/35 px-3 py-1.5 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Mandatory Confirmation Dialog for Every Gmail/Drive Mutation */}
      <WorkspaceConfirmModal
        request={confirmRequest}
        busy={confirmBusy}
        onCancel={() => {
          if (!confirmBusy) setConfirmRequest(null);
        }}
        onProceed={() => void runConfirmedAction()}
      />
    </div>
  );
}
