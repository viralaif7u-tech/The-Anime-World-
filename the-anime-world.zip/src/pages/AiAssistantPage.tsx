import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bot, Send, Sparkles, Trash2 } from 'lucide-react';
import { SeoHead } from '../components/SeoHead';
import { AnimeCard } from '../components/AnimeCard';
import { useAuth } from '../context/AuthContext';
import type { AnimeSummary } from '../types/anime';

interface Turn {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  anime?: AnimeSummary[];
  reasoning?: string;
  error?: boolean;
}

const PROMPTS = [
  'Recommend anime like Attack on Titan with dark mystery',
  'Find action fantasy anime released after 2020',
  'Suggest emotional sci-fi anime movies',
  'Find underrated hidden gem anime with high ratings',
];

export function AiAssistantPage() {
  const { privateUser, favorites } = useAuth();
  const [usePersonalization, setUsePersonalization] = useState(true);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [turns, setTurns] = useState<Turn[]>([
    {
      id: 'intro',
      role: 'assistant',
      text: 'Welcome to the Anime AI Assistant. Ask for recommendations, natural-language searches, or hidden gems—every suggestion is verified live against AniList metadata.',
    },
  ]);

  const submitPrompt = async (textOverride?: string) => {
    const query = (textOverride ?? input).trim();
    if (!query || loading) return;

    const userTurn: Turn = { id: `u_${Date.now()}`, role: 'user', text: query };
    setTurns((prev) => [...prev, userTurn]);
    if (!textOverride) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: turns.slice(-4).map((t) => ({ role: t.role, text: t.text })),
          favoriteGenres: usePersonalization ? privateUser?.favoriteGenres || [] : [],
          favoriteTitles: usePersonalization
            ? favorites.filter((f) => f.itemType === 'anime').map((f) => f.title)
            : [],
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'AI Assistant error.');

      setTurns((prev) => [
        ...prev,
        {
          id: `a_${Date.now()}`,
          role: 'assistant',
          text: data.reply,
          anime: data.anime || [],
          reasoning: data.filters?.reasoning,
        },
      ]);
    } catch (err) {
      setTurns((prev) => [
        ...prev,
        {
          id: `e_${Date.now()}`,
          role: 'assistant',
          text: err instanceof Error ? err.message : 'Unable to reach AI endpoint.',
          error: true,
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead
        title="Anime AI Assistant"
        description="Natural-language anime discovery and personalized recommendations powered by Gemini AI and live AniList metadata."
      />

      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">
            <Bot className="h-4 w-4" />
            <span>Server-Side Gemini Discovery Engine</span>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Anime AI Assistant</h1>
        </div>

        <div className="flex items-center gap-4">
          <label className="flex items-center gap-2 text-xs text-[#524E6B] dark:text-[#AAA7BC] cursor-pointer">
            <input
              type="checkbox"
              checked={usePersonalization}
              onChange={(e) => setUsePersonalization(e.target.checked)}
              className="accent-[#6D38E8] dark:accent-[#9B5CFF]"
            />
            Use my saved genres &amp; favorites
          </label>
          <button
            type="button"
            onClick={() => setTurns([turns[0]])}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-3 py-1.5 text-xs text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]"
          >
            <Trash2 className="h-3.5 w-3.5" /> Clear
          </button>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {PROMPTS.map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => void submitPrompt(p)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 px-3 py-2 text-xs text-[#524E6B] dark:text-[#AAA7BC] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] hover:text-[#141229] dark:hover:text-[#F5F3FF]"
          >
            <Sparkles className="h-3.5 w-3.5 text-[#0284C7] dark:text-[#43B8FF]" />
            {p}
          </button>
        ))}
      </div>

      <div className="mt-6 space-y-6">
        {turns.map((turn) => (
          <div
            key={turn.id}
            className={`rounded-2xl border p-5 ${
              turn.role === 'user'
                ? 'ml-auto max-w-2xl border-[#6D38E8]/35 dark:border-[#9B5CFF]/40 bg-[#6D38E8]/12 dark:bg-[#5126A8]/25'
                : turn.error
                ? 'border-red-500/40 bg-red-50/90 dark:bg-red-950/20'
                : 'border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90'
            }`}
          >
            <div className="text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF]">
              {turn.role === 'user' ? 'You' : 'Anime AI Assistant'}
            </div>
            <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-[#141229] dark:text-[#F5F3FF]">{turn.text}</p>
            {turn.reasoning && (
              <p className="mt-2 text-xs text-[#524E6B] dark:text-[#AAA7BC]">Query mapping: {turn.reasoning}</p>
            )}

            {turn.anime && turn.anime.length > 0 && (
              <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
                {turn.anime.map((a) => (
                  <AnimeCard key={a.id} anime={a} />
                ))}
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-5 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Analyzing request, querying live AniList database, and grounding recommendations...
          </div>
        )}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          void submitPrompt();
        }}
        className="mt-8 flex items-center gap-3 rounded-2xl border border-[var(--aw-border-strong)] bg-white/95 dark:bg-[#10101F]/95 p-3"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask for recommendations or describe what you want to watch..."
          aria-label="AI recommendation prompt"
          className="flex-1 bg-transparent px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF] placeholder:text-[#524E6B]/60 dark:placeholder:text-[#AAA7BC]/60 focus:outline-none"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className="inline-flex items-center gap-2 rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#080812] disabled:opacity-45 hover:bg-[#5b2cd1] dark:hover:bg-[#8a46f7]"
        >
          <Send className="h-4 w-4" />
          Ask AI
        </button>
      </form>

      <p className="mt-3 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
        Want to adjust filters manually? Open the <Link to="/explore" className="text-[#0284C7] dark:text-[#43B8FF] underline">Explore Catalog</Link>.
      </p>
    </div>
  );
}
