import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Flag, Heart, MessageSquare, Plus, Send, Sparkles, UserCheck, UserPlus, Users } from 'lucide-react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  increment,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { SeoHead } from '../components/SeoHead';
import { BRAND_IMAGES, FEATURED_CREATORS } from '../data/catalog';
import type { CollectionRecord, CommunityArtworkRecord, PublicProfile } from '../types/anime';

const ARTWORK_CATEGORIES: CommunityArtworkRecord['category'][] = [
  'Wallpaper',
  'Illustration',
  '3D Render',
  'Motion',
  'Character Fanart',
];

const PRESET_GALLERY_URLS = [
  { label: 'Neo-Tokyo Horizon', url: BRAND_IMAGES.cyberpunkTokyo },
  { label: 'Floating Torii Shrine', url: BRAND_IMAGES.celestialShrine },
  { label: 'Aegis-09 Hangar', url: BRAND_IMAGES.mechaHangar },
  { label: 'Astral Rift Traveler', url: BRAND_IMAGES.astralPortrait },
  { label: 'Sakura Eclipse', url: BRAND_IMAGES.sakuraEclipse },
];

interface CommentItem {
  id: string;
  artworkId: string;
  artworkStatus: string;
  authorId: string;
  authorName: string;
  content: string;
  createdAt?: unknown;
}

export function CommunityPage() {
  const { user, publicProfile } = useAuth();
  const [artworks, setArtworks] = useState<CommunityArtworkRecord[]>([]);
  const [publicCollections, setPublicCollections] = useState<CollectionRecord[]>([]);
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set());
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [loading, setLoading] = useState(true);

  const [showUpload, setShowUpload] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<CommunityArtworkRecord['category']>('Illustration');
  const [imageUrl, setImageUrl] = useState(BRAND_IMAGES.cyberpunkTokyo);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [activeCommentArtId, setActiveCommentArtId] = useState<string | null>(null);
  const [commentsMap, setCommentsMap] = useState<Record<string, CommentItem[]>>({});
  const [commentText, setCommentText] = useState('');
  const [commentStatus, setCommentStatus] = useState<string | null>(null);

  const [reportTarget, setReportTarget] = useState<{ id: string; title: string } | null>(null);
  const [reportReason, setReportReason] = useState('');
  const [reportStatus, setReportStatus] = useState<string | null>(null);

  const loadFeed = async () => {
    setLoading(true);
    try {
      const artSnap = await getDocs(
        query(collection(db, 'communityArtworks'), where('status', '==', 'published'))
      );
      setArtworks(artSnap.docs.map((d) => d.data() as CommunityArtworkRecord));
    } catch (err) {
      console.warn('Could not load community artworks:', err);
    }

    try {
      const colSnap = await getDocs(
        query(collection(db, 'collections'), where('isPublic', '==', true))
      );
      setPublicCollections(colSnap.docs.map((d) => d.data() as CollectionRecord).slice(0, 6));
    } catch {
      // Optional public showcase
    }

    if (user) {
      try {
        const likesSnap = await getDocs(
          query(collection(db, 'artworkLikes'), where('userId', '==', user.uid))
        );
        setLikedIds(new Set(likesSnap.docs.map((d) => (d.data() as { artworkId: string }).artworkId)));
      } catch {
        // Ignore
      }
    }
    setLoading(false);
  };

  useEffect(() => {
    void loadFeed();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.uid]);

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploadStatus(null);
    if (!user || !user.emailVerified) {
      setUploadStatus('Please sign in with a verified account to publish community artwork.');
      return;
    }
    if (!title.trim() || !imageUrl.trim()) {
      setUploadStatus('Title and artwork image URL are required.');
      return;
    }
    setSubmitting(true);
    const artId = `art_${user.uid.slice(0, 8)}_${Date.now()}`;
    try {
      await setDoc(doc(db, 'communityArtworks', artId), {
        id: artId,
        authorId: user.uid,
        authorName: publicProfile?.displayName || user.displayName || 'Anime Creator',
        authorUsername: publicProfile?.username || `user_${user.uid.slice(0, 6)}`,
        title: title.trim().slice(0, 140),
        description: description.trim().slice(0, 1000),
        category,
        imageUrl: imageUrl.trim().slice(0, 500),
        likesCount: 0,
        isFeatured: false,
        status: 'published',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setTitle('');
      setDescription('');
      setShowUpload(false);
      setUploadStatus('Artwork published to the Community Showcase.');
      await loadFeed();
    } catch (err) {
      setUploadStatus(err instanceof Error ? err.message : 'Unable to publish artwork.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleLike = async (art: CommunityArtworkRecord) => {
    if (!user || !user.emailVerified) {
      setUploadStatus('Sign in with a verified account to like community artworks.');
      return;
    }
    const likeId = `${user.uid}_${art.id}`.slice(0, 128);
    const alreadyLiked = likedIds.has(art.id);
    try {
      if (alreadyLiked) {
        await deleteDoc(doc(db, 'artworkLikes', likeId));
        await updateDoc(doc(db, 'communityArtworks', art.id), {
          likesCount: increment(-1),
          updatedAt: serverTimestamp(),
        });
        setLikedIds((prev) => {
          const next = new Set(prev);
          next.delete(art.id);
          return next;
        });
        setArtworks((prev) =>
          prev.map((a) => (a.id === art.id ? { ...a, likesCount: Math.max(0, a.likesCount - 1) } : a))
        );
      } else {
        await setDoc(doc(db, 'artworkLikes', likeId), {
          id: likeId,
          artworkId: art.id,
          userId: user.uid,
          createdAt: serverTimestamp(),
        });
        await updateDoc(doc(db, 'communityArtworks', art.id), {
          likesCount: increment(1),
          updatedAt: serverTimestamp(),
        });
        setLikedIds((prev) => new Set(prev).add(art.id));
        setArtworks((prev) =>
          prev.map((a) => (a.id === art.id ? { ...a, likesCount: a.likesCount + 1 } : a))
        );
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `communityArtworks/${art.id}`);
    }
  };

  const openComments = async (artworkId: string) => {
    if (activeCommentArtId === artworkId) {
      setActiveCommentArtId(null);
      return;
    }
    setActiveCommentArtId(artworkId);
    setCommentStatus(null);
    try {
      const snap = await getDocs(
        query(
          collection(db, 'communityArtworks', artworkId, 'comments'),
          where('artworkStatus', '==', 'published')
        )
      );
      setCommentsMap((prev) => ({
        ...prev,
        [artworkId]: snap.docs.map((d) => d.data() as CommentItem),
      }));
    } catch {
      setCommentsMap((prev) => ({ ...prev, [artworkId]: [] }));
    }
  };

  const handleAddComment = async (artworkId: string) => {
    setCommentStatus(null);
    if (!user || !user.emailVerified) {
      setCommentStatus('Sign in with a verified account to post comments.');
      return;
    }
    const clean = commentText.trim();
    if (!clean) return;
    const commentId = `cmt_${user.uid.slice(0, 6)}_${Date.now()}`;
    try {
      const payload: CommentItem = {
        id: commentId,
        artworkId,
        artworkStatus: 'published',
        authorId: user.uid,
        authorName: publicProfile?.displayName || user.displayName || 'Traveler',
        content: clean.slice(0, 600),
      };
      await setDoc(doc(db, 'communityArtworks', artworkId, 'comments', commentId), {
        ...payload,
        createdAt: serverTimestamp(),
      });
      setCommentsMap((prev) => ({
        ...prev,
        [artworkId]: [...(prev[artworkId] || []), payload],
      }));
      setCommentText('');
    } catch (err) {
      setCommentStatus(err instanceof Error ? err.message : 'Unable to post comment.');
    }
  };

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportTarget) return;
    if (!user || !user.emailVerified) {
      setReportStatus('Please sign in with a verified account to submit a moderation report.');
      return;
    }
    if (reportReason.trim().length < 5) {
      setReportStatus('Please describe the reason in at least 5 characters.');
      return;
    }
    const reportId = `rep_${user.uid.slice(0, 6)}_${Date.now()}`;
    try {
      await setDoc(doc(db, 'reports', reportId), {
        id: reportId,
        reporterId: user.uid,
        targetId: reportTarget.id,
        targetType: 'artwork',
        reason: reportReason.trim().slice(0, 600),
        status: 'pending',
        createdAt: serverTimestamp(),
      });
      setReportStatus('Report submitted to the moderation queue.');
      setReportReason('');
      setTimeout(() => {
        setReportTarget(null);
        setReportStatus(null);
      }, 1500);
    } catch (err) {
      setReportStatus(err instanceof Error ? err.message : 'Unable to submit report.');
    }
  };

  const filteredArtworks =
    categoryFilter === 'All'
      ? artworks
      : artworks.filter((a) => a.category === categoryFilter);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead
        title="Community & Featured Creators"
        description="Explore community anime illustrations, 3D renders, creator profiles, and curated public anime collections."
      />

      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-[#6D38E8] dark:text-[#9B5CFF]">
            <Users className="h-4 w-4" />
            <span>Global Creator Universe</span>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Community Hub</h1>
          <p className="mt-2 max-w-2xl text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Discover featured artists, publish your own original anime illustrations or 3D renders, comment, and explore public collections.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowUpload((v) => !v)}
          className="inline-flex items-center gap-2 rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2.5 text-xs font-semibold text-white dark:text-[#080812] hover:bg-[#5b2cd1] dark:hover:bg-[#8a46f7]"
        >
          <Plus className="h-4 w-4" />
          {showUpload ? 'Close Upload Form' : 'Publish Artwork'}
        </button>
      </div>

      {uploadStatus && (
        <div className="mt-4 rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white/90 dark:bg-[#10101F]/90 px-4 py-3 text-xs text-[#0284C7] dark:text-[#43B8FF]">
          {uploadStatus}
        </div>
      )}

      {showUpload && (
        <form
          onSubmit={(e) => void handleUpload(e)}
          className="mt-6 rounded-2xl border border-[#6D38E8]/35 dark:border-[#9B5CFF]/35 bg-white/92 dark:bg-[#10101F]/92 p-6 space-y-4"
        >
          <h2 className="font-display text-lg font-semibold text-[#141229] dark:text-[#F5F3FF]">Publish Community Artwork</h2>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1.5">Title</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Astral Blade Awakening"
                className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1.5">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as CommunityArtworkRecord['category'])}
                className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
              >
                {ARTWORK_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1.5">Artwork Image URL (HTTPS or Studio Preset)</label>
            <input
              type="text"
              required
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
            />
            <div className="mt-2 flex flex-wrap gap-2">
              {PRESET_GALLERY_URLS.map((preset) => (
                <button
                  key={preset.url}
                  type="button"
                  onClick={() => setImageUrl(preset.url)}
                  className="rounded-lg border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-2.5 py-1 text-[11px] text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]"
                >
                  Use {preset.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1.5">Description</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Share your creative process, lighting rig, or inspiration..."
              className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
            />
          </div>

          <div className="flex items-center justify-between gap-4">
            <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">
              Only original or authorized SFW artworks are permitted.
            </p>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-xs font-semibold text-white dark:text-[#080812] disabled:opacity-50"
            >
              {submitting ? 'Publishing...' : 'Publish to Showcase'}
            </button>
          </div>
        </form>
      )}

      {/* Featured Creators */}
      <section className="mt-10">
        <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Featured Platform Creators</h2>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURED_CREATORS.map((creator) => (
            <Link
              key={creator.uid}
              to={`/creators/${creator.username}`}
              className="group rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-4 hover:border-[#6D38E8]/55 dark:hover:border-[#9B5CFF]/55 transition-colors"
            >
              <div className="flex items-center gap-3">
                <img
                  src={creator.avatarUrl}
                  alt={creator.displayName}
                  referrerPolicy="no-referrer"
                  className="h-12 w-12 rounded-lg object-cover shrink-0"
                />
                <div className="min-w-0">
                  <div className="truncate font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] group-hover:text-[#0284C7] dark:group-hover:text-[#43B8FF]">
                    {creator.displayName}
                  </div>
                  <div className="truncate text-xs text-[#524E6B] dark:text-[#AAA7BC]">@{creator.username}</div>
                </div>
              </div>
              <p className="mt-3 text-xs text-[#524E6B] dark:text-[#AAA7BC] line-clamp-2">{creator.specialty}</p>
              <div className="mt-3 text-[11px] font-mono-tabular text-[#0284C7] dark:text-[#43B8FF]">
                {creator.followers.toLocaleString()} followers · {creator.artworksCount} works
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Community Artworks Showcase */}
      <section className="mt-12">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Community Artworks</h2>
          <div className="flex flex-wrap gap-2">
            {['All', ...ARTWORK_CATEGORIES].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium ${
                  categoryFilter === cat
                    ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                    : 'border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="h-72 rounded-xl bg-white/80 dark:bg-[#10101F]/80 animate-pulse" />
            ))}
          </div>
        ) : filteredArtworks.length === 0 ? (
          <div className="mt-6 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-8 text-center">
            <Sparkles className="mx-auto h-7 w-7 text-[#6D38E8] dark:text-[#9B5CFF]" />
            <h3 className="mt-3 font-display text-base font-semibold text-[#141229] dark:text-[#F5F3FF]">
              No community submissions in this category yet
            </h3>
            <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
              Sign in and publish the first piece in {categoryFilter} using the Publish Artwork button above.
            </p>
          </div>
        ) : (
          <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredArtworks.map((art) => {
              const liked = likedIds.has(art.id);
              const comments = commentsMap[art.id] || [];
              return (
                <article
                  key={art.id}
                  className="overflow-hidden rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 flex flex-col"
                >
                  <div className="aspect-video w-full overflow-hidden bg-[#080812]">
                    <img
                      src={art.imageUrl}
                      alt={art.title}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="flex flex-1 flex-col justify-between p-4">
                    <div>
                      <div className="flex items-center justify-between text-xs text-[#0284C7] dark:text-[#43B8FF]">
                        <span>{art.category}</span>
                        <Link to={`/creators/${art.authorUsername}`} className="text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]">
                          @{art.authorUsername}
                        </Link>
                      </div>
                      <h3 className="mt-1 font-display text-base font-semibold text-[#141229] dark:text-[#F5F3FF]">{art.title}</h3>
                      {art.description && (
                        <p className="mt-1.5 text-xs text-[#524E6B] dark:text-[#AAA7BC] line-clamp-2">{art.description}</p>
                      )}
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t border-[var(--aw-border)] pt-3">
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => void handleToggleLike(art)}
                          className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                            liked ? 'text-[#6D38E8] dark:text-[#9B5CFF]' : 'text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
                          }`}
                        >
                          <Heart className={`h-4 w-4 ${liked ? 'fill-current' : ''}`} />
                          <span className="font-mono-tabular">{art.likesCount}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => void openComments(art.id)}
                          className="inline-flex items-center gap-1.5 text-xs text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]"
                        >
                          <MessageSquare className="h-4 w-4" />
                          <span>Comments</span>
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => setReportTarget({ id: art.id, title: art.title })}
                        className="inline-flex items-center gap-1 text-xs text-[#524E6B] dark:text-[#AAA7BC] hover:text-red-500 dark:hover:text-red-400"
                        title="Report artwork"
                      >
                        <Flag className="h-3.5 w-3.5" /> Report
                      </button>
                    </div>

                    {activeCommentArtId === art.id && (
                      <div className="mt-3 border-t border-[var(--aw-border)] pt-3 space-y-2.5">
                        <div className="max-h-36 overflow-y-auto space-y-2">
                          {comments.length === 0 ? (
                            <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">No comments yet.</p>
                          ) : (
                            comments.map((c) => (
                              <div key={c.id} className="rounded-lg bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-2.5 text-xs">
                                <span className="font-semibold text-[#0284C7] dark:text-[#43B8FF]">{c.authorName}: </span>
                                <span className="text-[#141229] dark:text-[#F5F3FF]">{c.content}</span>
                              </div>
                            ))
                          )}
                        </div>
                        {commentStatus && <p className="text-[11px] text-amber-600 dark:text-amber-300">{commentStatus}</p>}
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={commentText}
                            onChange={(e) => setCommentText(e.target.value)}
                            placeholder="Write a comment..."
                            className="flex-1 rounded-lg border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-2.5 py-1.5 text-xs text-[#141229] dark:text-[#F5F3FF]"
                          />
                          <button
                            type="button"
                            onClick={() => void handleAddComment(art.id)}
                            className="inline-flex items-center rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-3 py-1.5 text-xs font-semibold text-white dark:text-[#080812]"
                          >
                            <Send className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Public Collections Showcase & Community Guidelines */}
      <section className="mt-12 grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
          <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">Public Community Collections</h2>
          {publicCollections.length === 0 ? (
            <p className="mt-2 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
              Create a public anime collection in your Dashboard to feature it here.
            </p>
          ) : (
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              {publicCollections.map((col) => (
                <div key={col.id} className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-4">
                  <h3 className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{col.name}</h3>
                  <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC] line-clamp-2">{col.description || 'Public curated anime list'}</p>
                  <div className="mt-2 text-[11px] font-mono-tabular text-[#0284C7] dark:text-[#43B8FF]">{col.itemsCount} entries</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-3">
          <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">Community Guidelines</h2>
          <ul className="space-y-2 text-xs leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
            <li>1. Publish only SFW anime artwork, 3D renders, and original illustrations you created or are licensed to share.</li>
            <li>2. Keep critiques and comments constructive and respectful toward creators worldwide.</li>
            <li>3. Use the Report button or <Link to="/copyright" className="text-[#0284C7] dark:text-[#43B8FF] underline">DMCA Center</Link> to flag unauthorized or inappropriate content.</li>
          </ul>
        </div>
      </section>

      {/* Report Modal */}
      {reportTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
          <form
            onSubmit={(e) => void handleSubmitReport(e)}
            className="w-full max-w-md rounded-2xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#10101F] p-6 space-y-4"
          >
            <h3 className="font-display text-lg font-semibold text-[#141229] dark:text-[#F5F3FF]">
              Report Artwork: {reportTarget.title}
            </h3>
            <textarea
              rows={3}
              required
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              placeholder="Explain why this content violates community or copyright guidelines..."
              className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
            />
            {reportStatus && <p className="text-xs text-[#0284C7] dark:text-[#43B8FF]">{reportStatus}</p>}
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setReportTarget(null);
                  setReportStatus(null);
                }}
                className="rounded-lg border border-[var(--aw-border-strong)] px-4 py-2 text-xs text-[#524E6B] dark:text-[#AAA7BC]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]"
              >
                Submit Report
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export function CreatorProfilePage() {
  const { username } = useParams<{ username: string }>();
  const { user } = useAuth();
  const [profile, setProfile] = useState<{
    uid: string;
    username: string;
    displayName: string;
    bio: string;
    avatarUrl: string;
    followersCount: number;
    specialty?: string;
  } | null>(null);
  const [artworks, setArtworks] = useState<CommunityArtworkRecord[]>([]);
  const [collections, setCollections] = useState<CollectionRecord[]>([]);
  const [following, setFollowing] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    const loadCreator = async () => {
      if (!username) return;
      const featured = FEATURED_CREATORS.find((c) => c.username === username);
      if (featured) {
        setProfile({
          uid: featured.uid,
          username: featured.username,
          displayName: featured.displayName,
          bio: featured.bio,
          avatarUrl: featured.avatarUrl,
          followersCount: featured.followers,
          specialty: featured.specialty,
        });
      } else {
        try {
          const snap = await getDocs(
            query(
              collection(db, 'publicProfiles'),
              where('isPublic', '==', true),
              where('username', '==', username)
            )
          );
          if (!snap.empty) {
            const p = snap.docs[0].data() as PublicProfile;
            setProfile({
              uid: p.uid,
              username: p.username,
              displayName: p.displayName,
              bio: p.bio || 'Anime creator on THE ANIME WORLD.',
              avatarUrl: p.avatarUrl || BRAND_IMAGES.astralPortrait,
              followersCount: p.followersCount,
            });
          }
        } catch {
          // Not found or private
        }
      }

      try {
        const artSnap = await getDocs(
          query(
            collection(db, 'communityArtworks'),
            where('status', '==', 'published'),
            where('authorUsername', '==', username)
          )
        );
        setArtworks(artSnap.docs.map((d) => d.data() as CommunityArtworkRecord));
      } catch {
        // Ignore
      }
    };
    void loadCreator();
  }, [username]);

  useEffect(() => {
    if (!profile) return;
    getDocs(
      query(
        collection(db, 'collections'),
        where('isPublic', '==', true),
        where('userId', '==', profile.uid)
      )
    )
      .then((snap) => setCollections(snap.docs.map((d) => d.data() as CollectionRecord)))
      .catch(() => {});

    if (user) {
      const followId = `${user.uid}_${profile.uid}`.slice(0, 128);
      getDoc(doc(db, 'follows', followId))
        .then((snap) => setFollowing(snap.exists()))
        .catch(() => {});
    }
  }, [profile, user]);

  const handleToggleFollow = async () => {
    if (!profile) return;
    if (!user || !user.emailVerified) {
      setStatusMsg('Please sign in with a verified account to follow creators.');
      return;
    }
    if (user.uid === profile.uid) {
      setStatusMsg('You cannot follow your own profile.');
      return;
    }
    const followId = `${user.uid}_${profile.uid}`.slice(0, 128);
    try {
      if (following) {
        await deleteDoc(doc(db, 'follows', followId));
        setFollowing(false);
        setStatusMsg(`Unfollowed ${profile.displayName}.`);
      } else {
        await setDoc(doc(db, 'follows', followId), {
          id: followId,
          followerId: user.uid,
          followingId: profile.uid,
          createdAt: serverTimestamp(),
        });
        setFollowing(true);
        setStatusMsg(`Now following ${profile.displayName}.`);
      }
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Unable to update follow status.');
    }
  };

  if (!profile) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-16 text-center">
        <h1 className="font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">Creator Profile Not Found</h1>
        <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">This creator profile is private or does not exist.</p>
        <Link to="/community" className="mt-5 inline-block text-sm font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline">
          ← Return to Community
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title={`${profile.displayName} (@${profile.username})`} description={profile.bio} />

      <Link to="/community" className="text-xs font-medium text-[#0284C7] dark:text-[#43B8FF] hover:underline">
        ← Back to Community
      </Link>

      <div className="mt-5 flex flex-col gap-6 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <img
            src={profile.avatarUrl}
            alt={profile.displayName}
            referrerPolicy="no-referrer"
            className="h-20 w-20 rounded-xl object-cover shrink-0 border border-[var(--aw-border-strong)]"
          />
          <div>
            <h1 className="font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">{profile.displayName}</h1>
            <p className="text-xs text-[#0284C7] dark:text-[#43B8FF]">
              @{profile.username}
              {profile.specialty ? ` · ${profile.specialty}` : ''}
            </p>
            <p className="mt-2 max-w-xl text-sm text-[#524E6B] dark:text-[#AAA7BC]">{profile.bio}</p>
          </div>
        </div>

        <div className="flex flex-col items-start sm:items-end gap-2">
          <div className="text-xs font-mono-tabular text-[#524E6B] dark:text-[#AAA7BC]">
            {profile.followersCount.toLocaleString()} followers
          </div>
          <button
            type="button"
            onClick={() => void handleToggleFollow()}
            className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold ${
              following
                ? 'border border-[#0284C7] dark:border-[#43B8FF] bg-white dark:bg-[#080812] text-[#0284C7] dark:text-[#43B8FF]'
                : 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
            }`}
          >
            {following ? <UserCheck className="h-4 w-4" /> : <UserPlus className="h-4 w-4" />}
            {following ? 'Following' : 'Follow Creator'}
          </button>
          {statusMsg && <p className="text-xs text-[#0284C7] dark:text-[#43B8FF]">{statusMsg}</p>}
        </div>
      </div>

      <h2 className="mt-10 font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Published Artworks</h2>
      {artworks.length === 0 ? (
        <p className="mt-3 text-sm text-[#524E6B] dark:text-[#AAA7BC]">No community uploads published under this handle yet.</p>
      ) : (
        <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {artworks.map((art) => (
            <div key={art.id} className="overflow-hidden rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90">
              <img src={art.imageUrl} alt={art.title} referrerPolicy="no-referrer" className="aspect-video w-full object-cover" />
              <div className="p-4">
                <h3 className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{art.title}</h3>
                <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">{art.category} · {art.likesCount} likes</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {collections.length > 0 && (
        <>
          <h2 className="mt-10 font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Public Collections</h2>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
            {collections.map((c) => (
              <div key={c.id} className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-4">
                <h3 className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{c.name}</h3>
                <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">{c.itemsCount} items</p>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
