import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Check, Flag, Globe, Image as ImageIcon, MessageSquare, Shield, Trash2, Users } from 'lucide-react';
import { collection, deleteDoc, doc, getDocs, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { SeoHead } from '../components/SeoHead';
import { LoadingPortalLogo } from '../components/BrandLogo';
import { ANIMATIONS_CATALOG, MODELS_3D_CATALOG, WALLPAPERS_CATALOG } from '../data/catalog';
import type { CommunityArtworkRecord, FeedbackRecord, PublicProfile, SiteConfigRecord } from '../types/anime';

interface ReportRecord {
  id: string;
  reporterId: string;
  targetId: string;
  targetType: string;
  reason: string;
  status: 'pending' | 'resolved' | 'dismissed';
}

export function AdminDashboardPage() {
  const { user, authReady, isAdmin } = useAuth();
  const [users, setUsers] = useState<PublicProfile[]>([]);
  const [artworks, setArtworks] = useState<CommunityArtworkRecord[]>([]);
  const [feedbackList, setFeedbackList] = useState<FeedbackRecord[]>([]);
  const [reports, setReports] = useState<ReportRecord[]>([]);
  const [siteConfigs, setSiteConfigs] = useState<SiteConfigRecord[]>([]);
  const [searchUser, setSearchUser] = useState('');

  const [bannerTitle, setBannerTitle] = useState('');
  const [bannerMsg, setBannerMsg] = useState('');
  const [bannerPublished, setBannerPublished] = useState(true);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  const loadAdminData = async () => {
    try {
      const [uSnap, aSnap, fSnap, rSnap, sSnap] = await Promise.all([
        getDocs(collection(db, 'publicProfiles')),
        getDocs(collection(db, 'communityArtworks')),
        getDocs(collection(db, 'feedback')),
        getDocs(collection(db, 'reports')),
        getDocs(collection(db, 'siteConfig')),
      ]);
      setUsers(uSnap.docs.map((d) => d.data() as PublicProfile));
      setArtworks(aSnap.docs.map((d) => d.data() as CommunityArtworkRecord));
      setFeedbackList(fSnap.docs.map((d) => d.data() as FeedbackRecord));
      setReports(rSnap.docs.map((d) => d.data() as ReportRecord));
      setSiteConfigs(sSnap.docs.map((d) => d.data() as SiteConfigRecord));
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Unable to load admin collections.');
    }
  };

  useEffect(() => {
    if (authReady && isAdmin) {
      void loadAdminData();
    }
  }, [authReady, isAdmin]);

  if (!authReady) return <LoadingPortalLogo />;

  if (!user || !isAdmin) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-20 text-center">
        <SeoHead title="Admin Access Restricted" description="Authorized administrator credentials required." />
        <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-8">
          <Shield className="mx-auto h-10 w-10 text-[#6D38E8] dark:text-[#9B5CFF]" />
          <h1 className="mt-4 font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">Administrator Access Required</h1>
          <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            This workspace is restricted to verified platform administrators.
          </p>
          <Link to="/" className="mt-6 inline-block rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-xs font-semibold text-white dark:text-[#080812]">
            Return Home
          </Link>
        </div>
      </div>
    );
  }

  const handleToggleSuspend = async (u: PublicProfile) => {
    try {
      await updateDoc(doc(db, 'publicProfiles', u.uid), {
        isSuspended: !u.isSuspended,
        updatedAt: serverTimestamp(),
      });
      setUsers((prev) => prev.map((x) => (x.uid === u.uid ? { ...x, isSuspended: !x.isSuspended } : x)));
      setStatusMsg(`Updated account status for @${u.username}.`);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Failed to update user.');
    }
  };

  const handleArtworkAction = async (art: CommunityArtworkRecord, updates: Partial<CommunityArtworkRecord>) => {
    try {
      await updateDoc(doc(db, 'communityArtworks', art.id), {
        ...updates,
        updatedAt: serverTimestamp(),
      });
      setArtworks((prev) => prev.map((a) => (a.id === art.id ? { ...a, ...updates } : a)));
      setStatusMsg(`Updated artwork "${art.title}".`);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Failed to update artwork.');
    }
  };

  const handleDeleteArtwork = async (artId: string) => {
    try {
      await deleteDoc(doc(db, 'communityArtworks', artId));
      setArtworks((prev) => prev.filter((a) => a.id !== artId));
      setStatusMsg('Artwork deleted.');
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Failed to delete artwork.');
    }
  };

  const handleUpdateFeedbackStatus = async (fb: FeedbackRecord, nextStatus: FeedbackRecord['status']) => {
    try {
      await updateDoc(doc(db, 'feedback', fb.id), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
      setFeedbackList((prev) => prev.map((f) => (f.id === fb.id ? { ...f, status: nextStatus } : f)));
      setStatusMsg(`Feedback marked ${nextStatus}.`);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Failed to update feedback.');
    }
  };

  const handleReportStatus = async (rep: ReportRecord, nextStatus: 'resolved' | 'dismissed') => {
    try {
      await updateDoc(doc(db, 'reports', rep.id), { status: nextStatus });
      setReports((prev) => prev.map((r) => (r.id === rep.id ? { ...r, status: nextStatus } : r)));
      setStatusMsg(`Report ${nextStatus}.`);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Failed to update report.');
    }
  };

  const handlePublishAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bannerTitle.trim()) return;
    const docId = 'homepage_announcement';
    try {
      const payload: SiteConfigRecord = {
        id: docId,
        title: bannerTitle.trim().slice(0, 160),
        message: bannerMsg.trim().slice(0, 600),
        isPublished: bannerPublished,
      };
      await setDoc(doc(db, 'siteConfig', docId), {
        ...payload,
        updatedAt: serverTimestamp(),
      });
      setSiteConfigs([payload]);
      setStatusMsg('Site announcement updated.');
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Unable to save site announcement.');
    }
  };

  const filteredUsers = searchUser.trim()
    ? users.filter(
        (u) =>
          u.username.toLowerCase().includes(searchUser.toLowerCase()) ||
          u.displayName.toLowerCase().includes(searchUser.toLowerCase())
      )
    : users;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8 space-y-10">
      <SeoHead title="Admin Dashboard" description="Platform administration, user moderation, announcements, and feedback management." />

      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[var(--aw-border)] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">
            <Shield className="h-4 w-4" />
            <span>Administrative Control Center</span>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Admin Dashboard</h1>
        </div>
        <button
          type="button"
          onClick={() => void loadAdminData()}
          className="rounded-lg border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-4 py-2 text-xs font-medium text-[#141229] dark:text-[#F5F3FF]"
        >
          Refresh Metrics
        </button>
      </div>

      {statusMsg && (
        <div className="rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white/90 dark:bg-[#10101F]/90 px-4 py-3 text-xs text-[#0284C7] dark:text-[#43B8FF]">
          {statusMsg}
        </div>
      )}

      {/* Overview Stats */}
      <section className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {[
          { label: 'Registered Users', val: users.length },
          { label: 'Community Art', val: artworks.length },
          { label: 'Open Feedback', val: feedbackList.filter((f) => f.status !== 'resolved').length },
          { label: 'Pending Reports', val: reports.filter((r) => r.status === 'pending').length },
          { label: '3D Museum Models', val: MODELS_3D_CATALOG.length },
          { label: '4K Wallpapers & Reels', val: WALLPAPERS_CATALOG.length + ANIMATIONS_CATALOG.length },
        ].map((stat) => (
          <div key={stat.label} className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-4">
            <div className="text-[11px] text-[#524E6B] dark:text-[#AAA7BC]">{stat.label}</div>
            <div className="mt-1 font-mono-tabular text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">{stat.val}</div>
          </div>
        ))}
      </section>

      {/* Website Management / Announcement Banner */}
      <section className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#0284C7] dark:text-[#43B8FF]">
          <Globe className="h-4 w-4" />
          <span>Website Management &amp; Global Announcement</span>
        </div>
        <form onSubmit={(e) => void handlePublishAnnouncement(e)} className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-4 items-end">
          <div>
            <label className="block text-xs text-[#524E6B] dark:text-[#AAA7BC] mb-1">Announcement Title</label>
            <input
              type="text"
              value={bannerTitle}
              onChange={(e) => setBannerTitle(e.target.value)}
              placeholder="e.g., New Seasonal 3D Models Live"
              className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-xs text-[#524E6B] dark:text-[#AAA7BC] mb-1">Message</label>
            <input
              type="text"
              value={bannerMsg}
              onChange={(e) => setBannerMsg(e.target.value)}
              placeholder="Explore Spring & Summer releases in the 3D Anime World."
              className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
            />
          </div>
          <div className="flex items-center justify-between gap-3">
            <label className="flex items-center gap-2 text-xs text-[#141229] dark:text-[#F5F3FF] cursor-pointer">
              <input type="checkbox" checked={bannerPublished} onChange={(e) => setBannerPublished(e.target.checked)} className="accent-[#6D38E8] dark:accent-[#9B5CFF]" />
              Published
            </label>
            <button type="submit" className="rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]">
              Save Banner
            </button>
          </div>
        </form>
        {siteConfigs.length > 0 && (
          <p className="mt-3 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
            Active config: <strong className="text-[#141229] dark:text-[#F5F3FF]">{siteConfigs[0].title}</strong> ({siteConfigs[0].isPublished ? 'Visible on Home' : 'Hidden'})
          </p>
        )}
      </section>

      {/* User Management */}
      <section className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#6D38E8] dark:text-[#9B5CFF]">
            <Users className="h-4 w-4" />
            <span>User Management ({users.length})</span>
          </div>
          <input
            type="text"
            value={searchUser}
            onChange={(e) => setSearchUser(e.target.value)}
            placeholder="Filter by username..."
            className="rounded-lg border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3 py-1.5 text-xs text-[#141229] dark:text-[#F5F3FF]"
          />
        </div>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[var(--aw-border)] text-[#524E6B] dark:text-[#AAA7BC]">
                <th className="py-2 pr-4">User</th>
                <th className="py-2 pr-4">Role</th>
                <th className="py-2 pr-4">Status</th>
                <th className="py-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((u) => (
                <tr key={u.uid} className="border-b border-[var(--aw-border)]">
                  <td className="py-2.5 pr-4 text-[#141229] dark:text-[#F5F3FF]">
                    {u.displayName} <span className="text-[#524E6B] dark:text-[#AAA7BC]">(@{u.username})</span>
                  </td>
                  <td className="py-2.5 pr-4 capitalize text-[#0284C7] dark:text-[#43B8FF]">{u.role}</td>
                  <td className="py-2.5 pr-4 text-[#141229] dark:text-[#F5F3FF]">{u.isSuspended ? 'Suspended' : 'Active'}</td>
                  <td className="py-2.5 text-right">
                    <button
                      type="button"
                      onClick={() => void handleToggleSuspend(u)}
                      className="rounded-lg border border-[var(--aw-border-strong)] px-3 py-1 text-[11px] text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF]"
                    >
                      {u.isSuspended ? 'Restore' : 'Suspend'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Content & Moderation */}
      <section className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#0284C7] dark:text-[#43B8FF]">
          <ImageIcon className="h-4 w-4" />
          <span>Community Artwork Moderation ({artworks.length})</span>
        </div>
        {artworks.length === 0 ? (
          <p className="mt-3 text-xs text-[#524E6B] dark:text-[#AAA7BC]">No user-submitted artworks yet.</p>
        ) : (
          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
            {artworks.map((art) => (
              <div key={art.id} className="flex items-center justify-between gap-4 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-3.5">
                <div className="min-w-0">
                  <div className="truncate text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{art.title}</div>
                  <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                    @{art.authorUsername} · {art.status} {art.isFeatured ? '· Featured' : ''}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => void handleArtworkAction(art, { isFeatured: !art.isFeatured })}
                    className="rounded-lg border border-[var(--aw-border-strong)] px-2.5 py-1 text-[11px] text-[#0284C7] dark:text-[#43B8FF]"
                  >
                    {art.isFeatured ? 'Unfeature' : 'Feature'}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      void handleArtworkAction(art, { status: art.status === 'published' ? 'flagged' : 'published' })
                    }
                    className="rounded-lg border border-[var(--aw-border-strong)] px-2.5 py-1 text-[11px] text-[#524E6B] dark:text-[#AAA7BC]"
                  >
                    {art.status === 'published' ? 'Flag' : 'Publish'}
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleDeleteArtwork(art.id)}
                    aria-label="Delete artwork"
                    className="text-red-500 dark:text-red-400 hover:text-red-600 dark:hover:text-red-300"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Feedback & Reports */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#6D38E8] dark:text-[#9B5CFF]">
            <MessageSquare className="h-4 w-4" />
            <span>User Feedback ({feedbackList.length})</span>
          </div>
          <div className="mt-4 space-y-3">
            {feedbackList.length === 0 ? (
              <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">No feedback submissions recorded yet.</p>
            ) : (
              feedbackList.map((fb) => (
                <div key={fb.id} className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-4">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#0284C7] dark:text-[#43B8FF]">{fb.category} · {fb.rating}/5 ★</span>
                    <span className="uppercase text-[#524E6B] dark:text-[#AAA7BC]">{fb.status}</span>
                  </div>
                  <h3 className="mt-1 text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{fb.subject}</h3>
                  <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">{fb.message}</p>
                  {fb.status !== 'resolved' && (
                    <div className="mt-3 flex gap-2">
                      {fb.status === 'open' && (
                        <button
                          type="button"
                          onClick={() => void handleUpdateFeedbackStatus(fb, 'in_review')}
                          className="rounded-lg border border-[var(--aw-border-strong)] px-2.5 py-1 text-[11px] text-[#141229] dark:text-[#F5F3FF]"
                        >
                          Mark In Review
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => void handleUpdateFeedbackStatus(fb, 'resolved')}
                        className="inline-flex items-center gap-1 rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-2.5 py-1 text-[11px] font-semibold text-white dark:text-[#080812]"
                      >
                        <Check className="h-3 w-3" /> Resolve
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </section>

        <section className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
          <div className="flex items-center gap-2 text-sm font-semibold text-[#0284C7] dark:text-[#43B8FF]">
            <Flag className="h-4 w-4" />
            <span>Moderation Reports ({reports.length})</span>
          </div>
          <div className="mt-4 space-y-3">
            {reports.length === 0 ? (
              <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">No moderation or DMCA reports pending.</p>
            ) : (
              reports.map((rep) => (
                <div key={rep.id} className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-4">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#6D38E8] dark:text-[#9B5CFF]">{rep.targetType} · {rep.targetId}</span>
                    <span className="uppercase text-[#524E6B] dark:text-[#AAA7BC]">{rep.status}</span>
                  </div>
                  <p className="mt-1.5 text-xs text-[#141229] dark:text-[#F5F3FF]">{rep.reason}</p>
                  {rep.status === 'pending' && (
                    <div className="mt-3 flex gap-2">
                      <button
                        type="button"
                        onClick={() => void handleReportStatus(rep, 'resolved')}
                        className="rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-2.5 py-1 text-[11px] font-semibold text-white dark:text-[#080812]"
                      >
                        Resolve
                      </button>
                      <button
                        type="button"
                        onClick={() => void handleReportStatus(rep, 'dismissed')}
                        className="rounded-lg border border-[var(--aw-border-strong)] px-2.5 py-1 text-[11px] text-[#524E6B] dark:text-[#AAA7BC]"
                      >
                        Dismiss
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
