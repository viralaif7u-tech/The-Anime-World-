import { Link } from 'react-router-dom';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  Film,
  HardDrive,
  Loader2,
  RefreshCw,
  Trash2,
  User as UserIcon,
} from 'lucide-react';
import { SeoHead } from '../components/SeoHead';
import { LoadingPortalLogo } from '../components/BrandLogo';
import { useAuth } from '../context/AuthContext';
import { useDownloads } from '../context/DownloadContext';
import { formatBytes } from '../services/videoDownloadHelpers';

function formatDownloadTimestamp(val: unknown): string {
  if (!val) return 'Just now';
  if (typeof val === 'object' && val !== null) {
    const ts = val as { toDate?: () => Date; seconds?: number };
    if (typeof ts.toDate === 'function') {
      return ts.toDate().toLocaleString(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
      });
    }
    if (typeof ts.seconds === 'number') {
      return new Date(ts.seconds * 1000).toLocaleString(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
      });
    }
  }
  return 'Recent';
}

export function DownloadsPage() {
  const { user, authReady } = useAuth();
  const {
    activeDownloads,
    savedDownloads,
    downloadsLoading,
    startVideoDownload,
    retryVideoDownload,
    removeSavedDownload,
    clearAllSavedDownloads,
  } = useDownloads();

  if (!authReady) return <LoadingPortalLogo />;

  const activeList = Object.values(activeDownloads);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
      <SeoHead
        title="My Downloads"
        description="Track real-time MP4 video download progress, completed anime videos, and your private download history."
      />

      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[var(--aw-border)] pb-5">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#0284C7] dark:text-[#43B8FF]">
            Private Storage Library
          </p>
          <h1 className="mt-1 font-display text-3xl font-extrabold text-[#141229] dark:text-[#F5F3FF]">
            My Downloads
          </h1>
          <p className="mt-1 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Every MP4 video you download is verified and linked strictly to your personal account.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <Link
            to="/animations"
            className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]"
          >
            <Film className="h-4 w-4" />
            Browse Downloadable Videos
          </Link>
          <Link
            to="/workspace?tab=drive"
            className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-4 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF]"
          >
            <HardDrive className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
            Google Drive Vault
          </Link>
          {user && savedDownloads.length > 0 && (
            <button
              type="button"
              onClick={() => void clearAllSavedDownloads()}
              className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-red-500/35 px-4 py-2 text-xs font-semibold text-red-600 dark:text-red-400 hover:bg-red-500/10"
            >
              <Trash2 className="h-4 w-4" />
              Clear History
            </button>
          )}
        </div>
      </div>

      {/* Live / Session Active Downloads */}
      {activeList.length > 0 && (
        <section className="space-y-4">
          <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">
            Current Session Transfers ({activeList.length})
          </h2>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {activeList.map((task) => {
              const isDownloading = task.status === 'downloading';
              const isFailed = task.status === 'failed';
              return (
                <div
                  key={task.videoId}
                  className="rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-4 flex flex-col gap-3 shadow-sm"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="h-16 w-24 shrink-0 overflow-hidden rounded-xl bg-[var(--aw-surface-elevated)] border border-[var(--aw-border)]">
                      {task.thumbnailUrl ? (
                        <img src={task.thumbnailUrl} alt={task.title} className="h-full w-full object-cover" />
                      ) : (
                        <div className="flex h-full items-center justify-center text-[#0284C7]">
                          <Film className="h-5 w-5" />
                        </div>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="truncate font-display text-sm font-bold text-[#141229] dark:text-[#F5F3FF]">
                        {task.title}
                      </h3>
                      <p className="mt-0.5 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                        MP4 · {formatBytes(task.downloadedBytes)}
                        {task.totalBytes > 0 ? ` / ${formatBytes(task.totalBytes)}` : ''} · {task.saveLocation}
                      </p>
                      <div className="mt-1 inline-flex items-center gap-1.5 text-xs font-semibold">
                        {isDownloading ? (
                          <span className="inline-flex items-center gap-1 text-[#0284C7] dark:text-[#43B8FF]">
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            Downloading ({task.progressPct}%)
                          </span>
                        ) : isFailed ? (
                          <span className="inline-flex items-center gap-1 text-red-600 dark:text-red-400">
                            <AlertCircle className="h-3.5 w-3.5" />
                            Download Failed
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Download Complete
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-black/10 dark:bg-white/10">
                    <div
                      className={`h-full transition-[width] duration-150 ${
                        isFailed
                          ? 'bg-red-500'
                          : isDownloading
                          ? 'bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF]'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.max(4, task.progressPct)}%` }}
                    />
                  </div>

                  {isFailed && (
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="text-red-600 dark:text-red-300">{task.errorMessage}</span>
                      <button
                        type="button"
                        onClick={() => void retryVideoDownload(task.videoId, task.title, task.thumbnailUrl)}
                        className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-red-600 px-3 py-1.5 font-semibold text-white hover:bg-red-700"
                      >
                        <RefreshCw className="h-3.5 w-3.5" />
                        Retry Download
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Persistent Account Download History */}
      {!user ? (
        <div className="rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-8 text-center shadow-sm">
          <UserIcon className="mx-auto h-10 w-10 text-[#6D38E8] dark:text-[#9B5CFF]" />
          <h2 className="mt-4 font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">
            Sign In to Sync Your Private Download History
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            You can download MP4 videos anytime, and signing in saves your personal download history privately under your account.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link
              to="/login"
              className="inline-flex min-h-[44px] items-center rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#080812]"
            >
              Login
            </Link>
            <Link
              to="/register"
              className="inline-flex min-h-[44px] items-center rounded-xl border border-[var(--aw-border-strong)] px-5 py-2.5 text-sm font-medium text-[#141229] dark:text-[#F5F3FF]"
            >
              Sign Up
            </Link>
          </div>
        </div>
      ) : downloadsLoading ? (
        <LoadingPortalLogo />
      ) : savedDownloads.length === 0 ? (
        <div className="rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-10 text-center">
          <Download className="mx-auto h-9 w-9 text-[#0284C7] dark:text-[#43B8FF]" />
          <h2 className="mt-3 font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">
            No Saved Downloads Yet
          </h2>
          <p className="mt-1.5 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Head to Animations &amp; Trailers and click Download MP4 on any video to save it to your device.
          </p>
          <Link
            to="/animations"
            className="mt-5 inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-xs font-semibold text-white dark:text-[#080812]"
          >
            <Film className="h-4 w-4" /> Open Animations Gallery
          </Link>
        </div>
      ) : (
        <section className="space-y-4">
          <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">
            Saved Account Download History ({savedDownloads.length})
          </h2>

          <div className="space-y-3">
            {savedDownloads.map((item) => {
              const liveTask = activeDownloads[item.videoId];
              const status = liveTask?.status || item.status;
              const sizeBytes = liveTask?.totalBytes || item.fileSizeBytes || item.downloadedBytes;
              return (
                <div
                  key={item.id}
                  className="rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <Link
                      to={`/animations/${item.videoId}`}
                      className="h-16 w-28 shrink-0 overflow-hidden rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]"
                    >
                      {item.thumbnailUrl ? (
                        <img
                          src={item.thumbnailUrl}
                          alt={item.title}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-[#0284C7]">
                          <Film className="h-5 w-5" />
                        </div>
                      )}
                    </Link>

                    <div className="min-w-0">
                      <Link
                        to={`/animations/${item.videoId}`}
                        className="block truncate font-display text-base font-bold text-[#141229] dark:text-[#F5F3FF] hover:text-[#0284C7] dark:hover:text-[#43B8FF]"
                      >
                        {item.title}
                      </Link>
                      <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                        <span className="font-mono-tabular font-semibold text-[#141229] dark:text-[#F5F3FF]">
                          {item.format} · {formatBytes(sizeBytes)}
                        </span>
                        <span>{formatDownloadTimestamp(item.updatedAt || item.createdAt)}</span>
                        {item.saveLocation && <span>Folder: {item.saveLocation}</span>}
                      </div>
                      <div className="mt-1.5 text-xs font-semibold">
                        {status === 'completed' ? (
                          <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="h-3.5 w-3.5" /> Download Complete
                          </span>
                        ) : status === 'downloading' ? (
                          <span className="inline-flex items-center gap-1 text-[#0284C7] dark:text-[#43B8FF]">
                            <Loader2 className="h-3.5 w-3.5 animate-spin" /> Downloading
                            {liveTask ? ` (${liveTask.progressPct}%)` : ''}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-red-600 dark:text-red-400">
                            <AlertCircle className="h-3.5 w-3.5" /> Download Failed
                            {item.errorMessage ? ` — ${item.errorMessage}` : ''}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    {status === 'failed' ? (
                      <button
                        type="button"
                        onClick={() =>
                          void retryVideoDownload(item.videoId, item.title, item.thumbnailUrl)
                        }
                        className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl bg-red-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-red-700"
                      >
                        <RefreshCw className="h-4 w-4" />
                        Retry Download
                      </button>
                    ) : (
                      <button
                        type="button"
                        disabled={status === 'downloading'}
                        onClick={() =>
                          void startVideoDownload({
                            videoId: item.videoId,
                            title: item.title,
                            thumbnailUrl: item.thumbnailUrl,
                          })
                        }
                        className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-[#0284C7]/45 dark:border-[#43B8FF]/45 bg-white dark:bg-[#080812] px-3.5 py-2 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:bg-[#0284C7]/10 disabled:opacity-60"
                      >
                        <Download className="h-4 w-4" />
                        Download Again
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => void removeSavedDownload(item.id)}
                      aria-label={`Remove ${item.title} from download history`}
                      className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-[var(--aw-border)] text-[#524E6B] dark:text-[#AAA7BC] hover:border-red-500/40 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
