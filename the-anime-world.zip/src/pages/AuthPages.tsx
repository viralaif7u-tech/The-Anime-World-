import { useNavigate } from 'react-router-dom';
import { AuthExperience } from '../components/AuthExperience';
import { SeoHead } from '../components/SeoHead';

export function LoginPage() {
  const navigate = useNavigate();
  return (
    <div className="mx-auto flex min-h-[82vh] max-w-lg flex-col justify-center px-4 pt-10 pb-24 sm:py-12">
      <SeoHead
        title="Sign In"
        description="Sign in to THE ANIME WORLD with Google, Facebook, Apple, Microsoft, GitHub, or Email to sync favorites and collections."
      />
      <AuthExperience initialMode="login" onSuccess={() => navigate('/dashboard')} />
    </div>
  );
}

export function RegisterPage() {
  const navigate = useNavigate();
  return (
    <div className="mx-auto flex min-h-[84vh] max-w-lg flex-col justify-center px-4 pt-10 pb-24 sm:py-12">
      <SeoHead
        title="Create Account"
        description="Create your THE ANIME WORLD account to curate anime collections, favorites, 3D showcases, and community artwork."
      />
      <AuthExperience initialMode="register" onSuccess={() => navigate('/dashboard')} />
    </div>
  );
}

export function ForgotPasswordPage() {
  const navigate = useNavigate();
  return (
    <div className="mx-auto flex min-h-[76vh] max-w-lg flex-col justify-center px-4 pt-10 pb-24 sm:py-12">
      <SeoHead
        title="Reset Password"
        description="Recover access to your THE ANIME WORLD account."
      />
      <AuthExperience initialMode="forgot" onSuccess={() => navigate('/dashboard')} />
    </div>
  );
}
