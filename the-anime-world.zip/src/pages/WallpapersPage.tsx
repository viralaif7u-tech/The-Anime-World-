import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Download, Heart, Maximize2, Search, Share2, X } from 'lucide-react';
import { SeoHead } from '../components/SeoHead';
import { WALLPAPERS_CATALOG } from '../data/catalog';
import { useAuth } from '../context/AuthContext';
import type { WallpaperItem } from '../types/anime';

const WALLPAPER_CATEGORIES = ['ALL', '4K Anime', 'Cyberpunk', 'Fantasy', 'Mobile', 'Minimal', 'Aesthetic', 'Dark', 'Desktop'];
const RESOLUTIONS = ['ALL', '3840x2160', '2560x1440', '1920x1080', '2160x3840', '1440x2560'];

export function WallpapersPage() {
  const { isFavorited, toggleFavorite } = useAuth();
  const [category, setCategory] = useState('ALL');
  const [resolution, setResolution] = useState('ALL');
  const [search, setSearch] = useState('');
  const [lightbox, setLightbox] = useState<WallpaperItem | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const items = useMemo(() => {
    const q = search.trim().toLowerCase();
    return WALLPAPERS_CATALOG.filter((w) => {
      if (category !== 'ALL' && w.category !== category && !w.tags.includes(category)) return false;
      if (resolution !== 'ALL' && w.resolution !== resolution) return false;
      if (q && !`${w.title} ${w.artist} ${w.tags.join(' ')}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [category, resolution, search]);

  const handleSave = async (w: WallpaperItem) => {
    try {
      const saved = await toggleFavorite({
        itemType: 'wallpaper',
        itemId: w.id,
        title: w.title,
        imageUrl: w.imageUrl,
        subtitle: `${w.resolution} · ${w.category}`,
      });
      setToast(saved ? `Saved "${w.title}"` : `Removed "${w.title}"`);
    } catch (err) {
      setToast(err instanceof Error ? err.message : 'Sign in to favorite wallpapers.');
    }
    setTimeout(() => setToast(null), 2800);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead
        title="4K Anime Wallpapers Gallery"
        description="Explore original 4K, 2K, Full HD, desktop, and mobile anime wallpapers."
      />

      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Anime Wallpaper Gallery</h1>
          <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Original high-resolution desktop and mobile artwork authorized for personal wallpaper downloads.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative w-64">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search wallpapers..."
              aria-label="Search wallpapers"
              className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 py-2 pr-3 pl-9 text-xs text-[#141229] dark:text-[#F5F3FF]"
            />
          </div>
          <select
            aria-label="Filter by resolution"
            value={resolution}
            onChange={(e) => setResolution(e.target.value)}
            className="rounded-lg border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 px-3 py-2 text-xs text-[#141229] dark:text-[#F5F3FF]"
          >
            {RESOLUTIONS.map((r) => (
              <option key={r} value={r}>{r === 'ALL' ? 'All Resolutions' : r}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-1.5">
        {WALLPAPER_CATEGORIES.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCategory(c)}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
              category === c
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
            }`}
          >
            {c === 'ALL' ? 'All Categories' : c}
          </button>
        ))}
      </div>

      {toast && (
        <div className="mt-4 rounded-lg border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white/90 dark:bg-[#10101F]/90 px-4 py-2 text-xs text-[#0284C7] dark:text-[#43B8FF]">
          {toast}
        </div>
      )}

      {/* Masonry Columns */}
      <div className="mt-8 columns-1 gap-5 space-y-5 sm:columns-2 lg:columns-3">
        {items.map((w) => {
          const fav = isFavorited('wallpaper', w.id);
          return (
            <article
              key={w.id}
              className="break-inside-avoid overflow-hidden rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90"
            >
              <div className="group relative overflow-hidden">
                <Link to={`/wallpapers/${w.id}`}>
                  <img
                    src={w.imageUrl}
                    alt={w.title}
                    loading="lazy"
                    referrerPolicy="no-referrer"
                    className="w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </Link>
                <div className="absolute top-3 right-3 flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setLightbox(w)}
                    aria-label={`Fullscreen preview ${w.title}`}
                    className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#080812]/85 text-[#F5F3FF] border border-white/15 hover:border-[#43B8FF]"
                  >
                    <Maximize2 className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleSave(w)}
                    aria-label={`Favorite ${w.title}`}
                    className={`flex h-8 w-8 items-center justify-center rounded-lg border ${
                      fav ? 'bg-[#9B5CFF] text-[#080812] border-[#9B5CFF]' : 'bg-[#080812]/85 text-[#F5F3FF] border-white/15'
                    }`}
                  >
                    <Heart className={`h-3.5 w-3.5 ${fav ? 'fill-current' : ''}`} />
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-between gap-3 p-4">
                <div className="min-w-0">
                  <Link to={`/wallpapers/${w.id}`} className="block truncate font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] hover:text-[#0284C7] dark:hover:text-[#43B8FF]">
                    {w.title}
                  </Link>
                  <p className="mt-0.5 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                    <span className="font-mono-tabular">{w.resolution}</span> · {w.category}
                  </p>
                </div>
                <a
                  href={w.imageUrl}
                  download={`${w.id}.jpg`}
                  aria-label={`Download ${w.title}`}
                  className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[var(--aw-border-strong)] text-[#0284C7] dark:text-[#43B8FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF]"
                >
                  <Download className="h-4 w-4" />
                </a>
              </div>
            </article>
          );
        })}
      </div>

      {lightbox && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#080812]/95 p-4"
          role="dialog"
          aria-label={lightbox.title}
        >
          <button
            type="button"
            onClick={() => setLightbox(null)}
            aria-label="Close fullscreen preview"
            className="absolute top-5 right-5 rounded-lg border border-white/20 bg-[#10101F] p-2.5 text-[#F5F3FF]"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="max-h-[90vh] max-w-5xl space-y-3 text-center">
            <img
              src={lightbox.imageUrl}
              alt={lightbox.title}
              referrerPolicy="no-referrer"
              className="max-h-[78vh] w-auto rounded-xl object-contain mx-auto"
            />
            <div className="flex items-center justify-center gap-4 text-xs text-[#AAA7BC]">
              <span className="font-semibold text-[#F5F3FF]">{lightbox.title}</span>
              <span className="font-mono-tabular">{lightbox.resolution}</span>
              <a
                href={lightbox.imageUrl}
                download={`${lightbox.id}.jpg`}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#9B5CFF] px-3.5 py-1.5 font-semibold text-[#080812]"
              >
                <Download className="h-3.5 w-3.5" /> Download
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function WallpaperDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { isFavorited, toggleFavorite } = useAuth();
  const [msg, setMsg] = useState<string | null>(null);

  const wp = WALLPAPERS_CATALOG.find((w) => w.id === id) || WALLPAPERS_CATALOG[0];
  const related = WALLPAPERS_CATALOG.filter((w) => w.id !== wp.id).slice(0, 3);
  const fav = isFavorited('wallpaper', wp.id);

  const handleFav = async () => {
    try {
      const saved = await toggleFavorite({
        itemType: 'wallpaper',
        itemId: wp.id,
        title: wp.title,
        imageUrl: wp.imageUrl,
        subtitle: wp.resolution,
      });
      setMsg(saved ? 'Wallpaper saved to favorites.' : 'Removed from favorites.');
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Sign in required.');
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title={wp.title} description={wp.description} />

      <div className="overflow-hidden rounded-2xl border border-[var(--aw-border-strong)] bg-[#080812]">
        <img
          src={wp.imageUrl}
          alt={wp.title}
          referrerPolicy="no-referrer"
          className="max-h-[72vh] w-full object-contain bg-[#080812]"
        />
      </div>

      <div className="mt-6 flex flex-wrap items-start justify-between gap-6">
        <div className="max-w-2xl">
          <h1 className="font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">{wp.title}</h1>
          <p className="mt-2 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
            By {wp.artist} · <span className="font-mono-tabular">{wp.resolution}</span> · {wp.category}
          </p>
          <p className="mt-3 text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">{wp.description}</p>
          <p className="mt-2 text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">{wp.license}</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => void handleFav()}
            className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-xs font-semibold ${
              fav
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 text-[#141229] dark:text-[#F5F3FF]'
            }`}
          >
            <Heart className={`h-4 w-4 ${fav ? 'fill-current' : ''}`} />
            {fav ? 'Saved' : 'Favorite'}
          </button>

          <button
            type="button"
            onClick={() => {
              void navigator.clipboard?.writeText(window.location.href);
              setMsg('Wallpaper URL copied.');
            }}
            className="inline-flex items-center gap-2 rounded-lg border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-4 py-2.5 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF]"
          >
            <Share2 className="h-4 w-4" /> Share
          </button>

          <a
            href={wp.imageUrl}
            download={`${wp.id}.jpg`}
            className="inline-flex items-center gap-2 rounded-lg bg-[#0284C7] dark:bg-[#43B8FF] px-5 py-2.5 text-xs font-semibold text-white dark:text-[#080812]"
          >
            <Download className="h-4 w-4" /> Authorized Download
          </a>
        </div>
      </div>

      {msg && <p className="mt-3 text-xs text-[#0284C7] dark:text-[#43B8FF]">{msg}</p>}

      <section className="mt-12 border-t border-[var(--aw-border)] pt-8">
        <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Related Wallpapers</h2>
        <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-3">
          {related.map((r) => (
            <Link key={r.id} to={`/wallpapers/${r.id}`} className="overflow-hidden rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 hover:border-[#6D38E8]/50 dark:hover:border-[#9B5CFF]/50">
              <img src={r.imageUrl} alt={r.title} referrerPolicy="no-referrer" className="aspect-video w-full object-cover" />
              <div className="p-3">
                <div className="truncate text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{r.title}</div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">{r.resolution}</div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
