import { useCallback, useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Search, Sparkles, X } from 'lucide-react';
import { AnimeCard } from '../components/AnimeCard';
import { SeoHead } from '../components/SeoHead';
import { LoadingPortalLogo } from '../components/BrandLogo';
import type { AnimeSummary, DiscoverResponse } from '../types/anime';

const CATEGORIES = [
  { id: 'trending', label: 'Trending' },
  { id: 'popular', label: 'Most Popular' },
  { id: 'top_rated', label: 'Top Rated' },
  { id: 'airing', label: 'Currently Airing' },
  { id: 'upcoming', label: 'Upcoming' },
  { id: 'seasonal', label: 'Seasonal' },
  { id: 'latest', label: 'Latest Releases' },
  { id: 'classic', label: 'Classics' },
  { id: 'hidden_gems', label: 'Hidden Gems' },
  { id: 'recommended', label: 'Recommended' },
];

const GENRES = [
  'ALL', 'Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Horror',
  'Mecha', 'Music', 'Mystery', 'Psychological', 'Romance', 'Sci-Fi',
  'Slice of Life', 'Sports', 'Supernatural', 'Thriller',
];

const POPULAR_SEARCHES = ['Frieren', 'Solo Leveling', 'Attack on Titan', 'Chainsaw Man', 'Cyberpunk', 'Steins;Gate'];

export function DiscoverPage({
  defaultCategory = 'trending',
  pageTitle = 'Explore Global Anime Catalog',
}: {
  defaultCategory?: string;
  pageTitle?: string;
}) {
  const [searchParams, setSearchParams] = useSearchParams();

  const [category, setCategory] = useState(searchParams.get('category') || defaultCategory);
  const [searchInput, setSearchInput] = useState(searchParams.get('search') || '');
  const [debouncedSearch, setDebouncedSearch] = useState(searchParams.get('search') || '');
  const [genre, setGenre] = useState(searchParams.get('genre') || 'ALL');
  const [year, setYear] = useState(searchParams.get('year') || 'ALL');
  const [season, setSeason] = useState(searchParams.get('season') || 'ALL');
  const [country, setCountry] = useState(searchParams.get('country') || 'ALL');
  const [format, setFormat] = useState(searchParams.get('format') || 'ALL');
  const [status, setStatus] = useState(searchParams.get('status') || 'ALL');
  const [page, setPage] = useState(Number(searchParams.get('page') || 1));

  const [data, setData] = useState<DiscoverResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [aiParsing, setAiParsing] = useState(false);
  const [aiNote, setAiNote] = useState<string | null>(null);
  const [history, setHistory] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('aw_search_history') || '[]');
    } catch {
      return [];
    }
  });

  useEffect(() => {
    setCategory(defaultCategory);
    setPage(1);
  }, [defaultCategory]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchInput.trim());
      setPage(1);
    }, 350);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const fetchCatalog = useCallback(async () => {
    if (/^\d+$/.test(debouncedSearch)) {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/anime/${debouncedSearch}`);
        if (res.ok) {
          const item = (await res.json()) as AnimeSummary;
          setData({
            items: [item],
            pageInfo: { total: 1, currentPage: 1, lastPage: 1, hasNextPage: false, perPage: 1 },
            source: 'AniList GraphQL API',
          });
          setLoading(false);
          return;
        }
      } catch {
        // Fall through
      }
    }

    setLoading(true);
    setError(null);
    const qs = new URLSearchParams({
      category,
      page: String(page),
      perPage: '20',
    });
    if (debouncedSearch) qs.set('search', debouncedSearch);
    if (genre !== 'ALL') qs.set('genre', genre);
    if (year !== 'ALL') qs.set('year', year);
    if (season !== 'ALL') qs.set('season', season);
    if (country !== 'ALL') qs.set('country', country);
    if (format !== 'ALL') qs.set('format', format);
    if (status !== 'ALL') qs.set('status', status);

    try {
      const res = await fetch(`/api/anime/discover?${qs.toString()}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to load anime catalog.');
      setData(json);

      if (debouncedSearch && debouncedSearch.length >= 2) {
        setHistory((prev) => {
          const next = [debouncedSearch, ...prev.filter((h) => h !== debouncedSearch)].slice(0, 6);
          localStorage.setItem('aw_search_history', JSON.stringify(next));
          return next;
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach anime metadata API.');
    } finally {
      setLoading(false);
    }
  }, [category, country, debouncedSearch, format, genre, page, season, status, year]);

  useEffect(() => {
    void fetchCatalog();
    const nextParams = new URLSearchParams();
    if (category) nextParams.set('category', category);
    if (debouncedSearch) nextParams.set('search', debouncedSearch);
    if (genre !== 'ALL') nextParams.set('genre', genre);
    if (year !== 'ALL') nextParams.set('year', year);
    if (season !== 'ALL') nextParams.set('season', season);
    if (country !== 'ALL') nextParams.set('country', country);
    if (format !== 'ALL') nextParams.set('format', format);
    if (status !== 'ALL') nextParams.set('status', status);
    if (page > 1) nextParams.set('page', String(page));
    setSearchParams(nextParams, { replace: true });
  }, [fetchCatalog, setSearchParams, category, debouncedSearch, genre, year, season, country, format, status, page]);

  const handleAiParse = async () => {
    if (!searchInput.trim() || aiParsing) return;
    setAiParsing(true);
    setAiNote(null);
    try {
      const res = await fetch('/api/ai/parse-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchInput.trim() }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'AI filter conversion failed.');
      setSearchInput(json.search || '');
      setDebouncedSearch(json.search || '');
      setGenre(json.genre || 'ALL');
      setYear(json.year || 'ALL');
      setFormat(json.format || 'ALL');
      if (json.category && json.category !== 'all') setCategory(json.category);
      setAiNote(json.reasoning);
    } catch (err) {
      setAiNote(err instanceof Error ? err.message : 'Could not apply AI filters.');
    } finally {
      setAiParsing(false);
    }
  };

  const resetAll = () => {
    setSearchInput('');
    setDebouncedSearch('');
    setGenre('ALL');
    setYear('ALL');
    setSeason('ALL');
    setCountry('ALL');
    setFormat('ALL');
    setStatus('ALL');
    setPage(1);
    setAiNote(null);
  };

  const currentYear = new Date().getFullYear() + 1;
  const years = Array.from({ length: 45 }, (_, i) => String(currentYear - i));

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead
        title={pageTitle}
        description="Search and filter thousands of real anime, donghua, movies, OVAs, and seasonal releases powered by AniList & Jikan."
      />

      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF] sm:text-4xl">{pageTitle}</h1>
          <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Live catalog metadata via {data?.source || 'AniList GraphQL API'}. Safe-filtered for global audiences.
          </p>
        </div>
        {data?.pageInfo?.total ? (
          <div className="font-mono-tabular text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF]">
            {data.pageInfo.total.toLocaleString()} discoverable titles
          </div>
        ) : null}
      </div>

      {/* Category Switcher */}
      <div className="mt-6 flex flex-wrap gap-1.5">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => {
              setCategory(c.id);
              setPage(1);
            }}
            className={`rounded-lg px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              category === c.id
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {/* Global Search + Natural Language AI Filter */}
      <div className="mt-5 flex flex-col gap-3 lg:flex-row">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]" />
          <input
            type="search"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search English, Japanese, Romaji title, or Anime ID (e.g. 154587)..."
            aria-label="Search anime catalog"
            className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 py-3 pr-10 pl-10 text-sm text-[#141229] dark:text-[#F5F3FF] placeholder:text-[#524E6B]/60 dark:placeholder:text-[#AAA7BC]/60 focus:border-[#0284C7] dark:focus:border-[#43B8FF] focus:outline-none"
          />
          {searchInput && (
            <button
              type="button"
              onClick={() => {
                setSearchInput('');
                setDebouncedSearch('');
              }}
              aria-label="Clear search query"
              className="absolute top-1/2 right-3 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={() => void handleAiParse()}
          disabled={aiParsing || searchInput.trim().length < 3}
          className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white/92 dark:bg-[#10101F]/92 px-4 py-3 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:bg-[#0284C7]/10 dark:hover:bg-[#43B8FF]/10 disabled:opacity-45 transition-colors whitespace-nowrap shrink-0"
        >
          <Sparkles className="h-4 w-4" />
          {aiParsing ? 'Parsing...' : 'AI Smart Filter'}
        </button>

        <button
          type="button"
          onClick={resetAll}
          className="rounded-xl border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 px-4 py-3 text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors whitespace-nowrap shrink-0"
        >
          Reset Filters
        </button>
      </div>

      {aiNote && (
        <div className="mt-3 rounded-lg border border-[#0284C7]/30 dark:border-[#43B8FF]/30 bg-white/90 dark:bg-[#10101F]/90 px-4 py-2.5 text-xs text-[#141229] dark:text-[#F5F3FF]">
          <span className="font-semibold text-[#0284C7] dark:text-[#43B8FF]">AI Filter Applied:</span> {aiNote}
        </div>
      )}

      {/* Search History & Popular Suggestions */}
      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
        <span>Popular:</span>
        {POPULAR_SEARCHES.map((term) => (
          <button
            key={term}
            type="button"
            onClick={() => setSearchInput(term)}
            className="text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#0284C7] dark:hover:text-[#43B8FF] underline-offset-4 hover:underline"
          >
            {term}
          </button>
        ))}
        {history.length > 0 && (
          <>
            <span className="ml-2 text-[#524E6B]/30 dark:text-white/20">|</span>
            <span>Recent:</span>
            {history.map((h) => (
              <button
                key={h}
                type="button"
                onClick={() => setSearchInput(h)}
                className="text-[#6D38E8] dark:text-[#9B5CFF] hover:underline"
              >
                {h}
              </button>
            ))}
          </>
        )}
      </div>

      {/* Advanced Filters */}
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <select
          aria-label="Filter by genre"
          value={genre}
          onChange={(e) => { setGenre(e.target.value); setPage(1); }}
          className="rounded-lg border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 px-3 py-2 text-xs text-[#141229] dark:text-[#F5F3FF]"
        >
          {GENRES.map((g) => (
            <option key={g} value={g}>{g === 'ALL' ? 'All Genres' : g}</option>
          ))}
        </select>

        <select
          aria-label="Filter by year"
          value={year}
          onChange={(e) => { setYear(e.target.value); setPage(1); }}
          className="rounded-lg border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 px-3 py-2 text-xs text-[#141229] dark:text-[#F5F3FF]"
        >
          <option value="ALL">All Years</option>
          {years.map((y) => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>

        <select
          aria-label="Filter by season"
          value={season}
          onChange={(e) => { setSeason(e.target.value); setPage(1); }}
          className="rounded-lg border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 px-3 py-2 text-xs text-[#141229] dark:text-[#F5F3FF]"
        >
          <option value="ALL">All Seasons</option>
          <option value="WINTER">Winter</option>
          <option value="SPRING">Spring</option>
          <option value="SUMMER">Summer</option>
          <option value="FALL">Fall</option>
        </select>

        <select
          aria-label="Filter by country of origin"
          value={country}
          onChange={(e) => { setCountry(e.target.value); setPage(1); }}
          className="rounded-lg border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 px-3 py-2 text-xs text-[#141229] dark:text-[#F5F3FF]"
        >
          <option value="ALL">All Regions</option>
          <option value="JP">Japan (Anime)</option>
          <option value="CN">China (Donghua)</option>
          <option value="KR">South Korea</option>
          <option value="TW">Taiwan</option>
        </select>

        <select
          aria-label="Filter by format"
          value={format}
          onChange={(e) => { setFormat(e.target.value); setPage(1); }}
          className="rounded-lg border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 px-3 py-2 text-xs text-[#141229] dark:text-[#F5F3FF]"
        >
          <option value="ALL">All Formats</option>
          <option value="TV">TV Series</option>
          <option value="MOVIE">Movie</option>
          <option value="OVA">OVA</option>
          <option value="ONA">ONA</option>
          <option value="SPECIAL">Special</option>
        </select>

        <select
          aria-label="Filter by airing status"
          value={status}
          onChange={(e) => { setStatus(e.target.value); setPage(1); }}
          className="rounded-lg border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 px-3 py-2 text-xs text-[#141229] dark:text-[#F5F3FF]"
        >
          <option value="ALL">All Statuses</option>
          <option value="RELEASING">Currently Airing</option>
          <option value="FINISHED">Completed</option>
          <option value="NOT_YET_RELEASED">Upcoming</option>
        </select>
      </div>

      {/* Results */}
      {loading ? (
        <LoadingPortalLogo />
      ) : error ? (
        <div className="mt-10 rounded-xl border border-red-500/40 bg-white/90 dark:bg-[#10101F]/90 p-8 text-center">
          <p className="text-sm text-red-700 dark:text-red-200">{error}</p>
          <button
            type="button"
            onClick={() => void fetchCatalog()}
            className="mt-4 rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]"
          >
            Retry Query
          </button>
        </div>
      ) : !data || data.items.length === 0 ? (
        <div className="mt-10 rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-12 text-center">
          <h2 className="font-display text-xl font-semibold text-[#141229] dark:text-[#F5F3FF]">No matching anime found</h2>
          <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Try clearing one or more filters or asking the{' '}
            <Link to="/ai-assistant" className="text-[#0284C7] dark:text-[#43B8FF] underline">
              Anime AI Assistant
            </Link>
            .
          </p>
          <button
            type="button"
            onClick={resetAll}
            className="mt-5 rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]"
          >
            Reset Search &amp; Filters
          </button>
        </div>
      ) : (
        <>
          <div className="mt-8 grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {data.items.map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>

          <div className="mt-10 flex items-center justify-between border-t border-[var(--aw-border)] pt-6">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-4 py-2 text-xs font-medium text-[#141229] dark:text-[#F5F3FF] disabled:opacity-40 hover:border-[#0284C7] dark:hover:border-[#43B8FF]"
            >
              <ChevronLeft className="h-4 w-4" />
              Previous
            </button>

            <span className="font-mono-tabular text-xs text-[#524E6B] dark:text-[#AAA7BC]">
              Page {data.pageInfo.currentPage} of {data.pageInfo.lastPage}
            </span>

            <button
              type="button"
              disabled={!data.pageInfo.hasNextPage}
              onClick={() => setPage((p) => p + 1)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-4 py-2 text-xs font-medium text-[#141229] dark:text-[#F5F3FF] disabled:opacity-40 hover:border-[#0284C7] dark:hover:border-[#43B8FF]"
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </>
      )}
    </div>
  );
}
