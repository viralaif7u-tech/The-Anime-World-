import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Bot, Box, Compass, Flame, Image as ImageIcon, Play, Sparkles, Users } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'motion/react';
import { HeroUniverseCanvas } from '../components/three/HeroUniverseCanvas';
import { AnimeModelViewer } from '../components/three/AnimeModelViewer';
import { AnimeCard } from '../components/AnimeCard';
import { SeoHead } from '../components/SeoHead';
import { ANIMATIONS_CATALOG, FEATURED_CREATORS, MODELS_3D_CATALOG, WALLPAPERS_CATALOG } from '../data/catalog';
import type { AnimeSummary, SiteConfigRecord } from '../types/anime';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../lib/firebase';

gsap.registerPlugin(ScrollTrigger);

export function HomePage() {
  const pageRef = useRef<HTMLDivElement | null>(null);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [trending, setTrending] = useState<AnimeSummary[]>([]);
  const [trendingLoading, setTrendingLoading] = useState(true);
  const [activeModelIdx, setActiveModelIdx] = useState(0);
  const [announcement, setAnnouncement] = useState<SiteConfigRecord | null>(null);

  useEffect(() => {
    fetch('/api/anime/discover?category=trending&perPage=8&page=1')
      .then((r) => r.json())
      .then((data) => {
        if (Array.isArray(data.items)) setTrending(data.items);
      })
      .catch(() => {})
      .finally(() => setTrendingLoading(false));

    getDocs(query(collection(db, 'siteConfig'), where('isPublished', '==', true)))
      .then((snap) => {
        if (!snap.empty) {
          setAnnouncement(snap.docs[0].data() as SiteConfigRecord);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const onScroll = () => {
      const heroH = window.innerHeight || 800;
      setScrollProgress(Math.min(1, Math.max(0, window.scrollY / heroH)));
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const ctx = gsap.context(() => {
      gsap.from('.hero-stagger', {
        y: 22,
        opacity: 0,
        duration: 0.75,
        stagger: 0.1,
        ease: 'power3.out',
      });
    }, pageRef);
    return () => ctx.revert();
  }, []);

  const activeModel = MODELS_3D_CATALOG[activeModelIdx] || MODELS_3D_CATALOG[0];

  return (
    <div ref={pageRef}>
      <SeoHead
        title="THE ANIME WORLD — Enter the World of Anime"
        description="Discover thousands of anime, explore interactive 3D worlds, 4K wallpapers, character archives, and Gemini AI anime recommendations."
      />

      {announcement && (
        <div className="border-b border-[#6D38E8]/25 dark:border-[#9B5CFF]/30 bg-white/85 dark:bg-[#10101F]/85 backdrop-blur-md px-4 py-2.5 text-center text-xs text-[#141229] dark:text-[#F5F3FF]">
          <span className="font-semibold text-[#0284C7] dark:text-[#43B8FF]">{announcement.title}</span>
          {announcement.message && (
            <span className="ml-2 text-[#524E6B] dark:text-[#AAA7BC]">{announcement.message}</span>
          )}
        </div>
      )}

      {/* 1. CINEMATIC 3D HERO */}
      <section className="relative flex min-h-[88vh] items-center justify-center overflow-hidden border-b border-[var(--aw-border)] bg-[#080812]">
        <HeroUniverseCanvas scrollProgress={scrollProgress} />
        <div
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(8,8,18,0.78)_0%,rgba(8,8,18,0.42)_52%,rgba(8,8,18,0.88)_100%)]"
          aria-hidden="true"
        />

        <div className="relative z-10 mx-auto max-w-5xl px-4 py-20 text-center sm:px-6 lg:px-8">
          <p className="hero-stagger text-xs font-semibold tracking-[0.22em] text-[#43B8FF]">
            ENTER THE WORLD OF ANIME. EXPERIENCE THE IMPOSSIBLE.
          </p>
          <h1 className="hero-stagger mt-5 font-display text-4xl font-extrabold tracking-tight text-[#F5F3FF] sm:text-6xl lg:text-7xl [text-wrap:balance] drop-shadow-[0_4px_24px_rgba(8,8,18,0.9)]">
            YOUR UNIVERSE. YOUR ANIME. YOUR WORLD.
          </h1>
          <p className="hero-stagger mx-auto mt-6 max-w-2xl text-base leading-relaxed text-[#F5F3FF]/85 sm:text-lg drop-shadow-[0_2px_12px_rgba(8,8,18,0.95)]">
            Discover thousands of anime, explore breathtaking worlds, and experience the future of anime discovery.
          </p>
          <div className="hero-stagger mt-9 flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/explore"
              className="inline-flex items-center gap-2 rounded-xl bg-[#9B5CFF] px-6 py-3.5 text-sm font-semibold text-[#080812] hover:bg-[#8a46f7] transition-colors whitespace-nowrap"
            >
              <Compass className="h-4 w-4" />
              EXPLORE ANIME
            </Link>
            <Link
              to="/3d-world"
              className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-[#080812]/85 px-6 py-3.5 text-sm font-semibold text-[#F5F3FF] hover:border-[#43B8FF] transition-colors whitespace-nowrap"
            >
              <Box className="h-4 w-4 text-[#43B8FF]" />
              ENTER THE 3D WORLD
            </Link>
          </div>
        </div>
      </section>

      {/* 2. TRENDING ANIME DISCOVERY */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">
              <Flame className="h-4 w-4" />
              <span>Global Discovery Catalog</span>
            </div>
            <h2 className="mt-1 font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF] sm:text-3xl">
              Trending Across the Universe
            </h2>
          </div>
          <div className="flex flex-wrap items-center gap-3 text-sm">
            <Link to="/trending" className="text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Trending</Link>
            <span aria-hidden="true" className="text-[#524E6B]/40 dark:text-white/20">·</span>
            <Link to="/popular" className="text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Popular</Link>
            <span aria-hidden="true" className="text-[#524E6B]/40 dark:text-white/20">·</span>
            <Link to="/upcoming" className="text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF] transition-colors">Upcoming</Link>
            <span aria-hidden="true" className="text-[#524E6B]/40 dark:text-white/20">·</span>
            <Link
              to="/explore"
              className="inline-flex items-center gap-1 font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline"
            >
              Full Catalog <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

        {trendingLoading ? (
          <div className="mt-8 grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="aspect-[3/4] rounded-xl bg-white/80 dark:bg-[#10101F]/80 animate-pulse border border-[var(--aw-border)]" />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.1 }}
            transition={{ duration: 0.45 }}
            className="mt-8 grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4"
          >
            {trending.map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </motion.div>
        )}
      </section>

      {/* 3. INTERACTIVE 3D ANIME WORLD PORTAL */}
      <section className="border-y border-[var(--aw-border)] bg-white/68 dark:bg-[#10101F]/65 backdrop-blur-sm py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-medium text-[#6D38E8] dark:text-[#9B5CFF]">
                <Box className="h-4 w-4" />
                <span>Interactive Three.js Museum</span>
              </div>
              <h2 className="mt-1 font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF] sm:text-3xl">
                3D Anime Sculptures &amp; Artifacts
              </h2>
              <p className="mt-2 max-w-2xl text-sm text-[#524E6B] dark:text-[#AAA7BC]">
                Rotate 360°, switch physically-based material finishes, inspect exploded armor layers, or upload authorized GLB/GLTF models directly in real time.
              </p>
            </div>
            <Link
              to="/3d-world"
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#6D38E8]/40 dark:border-[#9B5CFF]/40 bg-white dark:bg-[#080812] px-4 py-2.5 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors whitespace-nowrap"
            >
              Open Full 3D Museum <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="mt-7 flex flex-wrap gap-2">
            {MODELS_3D_CATALOG.slice(0, 4).map((m, idx) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setActiveModelIdx(idx)}
                className={`rounded-lg px-3.5 py-2 text-xs font-medium transition-colors whitespace-nowrap ${
                  activeModelIdx === idx
                    ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                    : 'border border-[var(--aw-border)] bg-white/90 dark:bg-[#080812] text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
                }`}
              >
                {m.title}
              </button>
            ))}
          </div>

          <div className="mt-5">
            <AnimeModelViewer model={activeModel} heightClass="h-[460px] sm:h-[520px]" compactControls />
          </div>
        </div>
      </section>

      {/* 4. 4K WALLPAPERS & ANIMATIONS SHOWCASE */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">
              <ImageIcon className="h-4 w-4" />
              <span>Original Artwork &amp; Motion</span>
            </div>
            <h2 className="mt-1 font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF] sm:text-3xl">
              4K Wallpapers &amp; Motion Gallery
            </h2>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <Link to="/wallpapers" className="font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline">
              All Wallpapers
            </Link>
            <Link to="/animations" className="font-semibold text-[#6D38E8] dark:text-[#9B5CFF] hover:underline">
              Animation Reels
            </Link>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-5 md:grid-cols-3">
          {WALLPAPERS_CATALOG.slice(0, 3).map((wp, idx) => (
            <Link
              key={wp.id}
              to={`/wallpapers/${wp.id}`}
              className={`group relative overflow-hidden rounded-xl border border-[var(--aw-border)] bg-[#10101F] ${
                idx === 0 ? 'md:col-span-2 aspect-[16/9]' : 'aspect-[16/9] md:aspect-auto'
              }`}
            >
              <img
                src={wp.imageUrl}
                alt={wp.title}
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#080812]/90 via-[#080812]/25 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4">
                <h3 className="font-display text-lg font-semibold text-[#F5F3FF]">{wp.title}</h3>
                <p className="mt-1 text-xs text-[#AAA7BC]">
                  {wp.category} · <span className="font-mono-tabular">{wp.resolution}</span> · {wp.artist}
                </p>
              </div>
            </Link>
          ))}
        </div>

        {/* Animations Strip */}
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {ANIMATIONS_CATALOG.slice(0, 3).map((anim) => (
            <Link
              key={anim.id}
              to={`/animations/${anim.id}`}
              className="group flex items-center gap-3.5 rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-3 hover:border-[#6D38E8]/50 dark:hover:border-[#9B5CFF]/50 transition-colors"
            >
              <div className="relative h-16 w-24 shrink-0 overflow-hidden rounded-lg bg-[#080812]">
                <img
                  src={anim.previewImage}
                  alt={anim.title}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover"
                />
                <span className="absolute inset-0 flex items-center justify-center bg-black/35">
                  <Play className="h-5 w-5 text-[#F5F3FF] fill-current" />
                </span>
              </div>
              <div className="min-w-0">
                <h3 className="truncate font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] group-hover:text-[#0284C7] dark:group-hover:text-[#43B8FF]">
                  {anim.title}
                </h3>
                <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                  {anim.category} · {anim.durationLabel}
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* 5. GEMINI AI ASSISTANT & COMMUNITY SPOTLIGHT */}
      <section className="border-t border-[var(--aw-border)] bg-white/60 dark:bg-[#10101F]/55 backdrop-blur-sm py-16">
        <div className="mx-auto grid max-w-7xl grid-cols-1 gap-8 px-4 sm:px-6 lg:grid-cols-2 lg:px-8">
          <div className="flex flex-col justify-between rounded-2xl border border-[#6D38E8]/30 dark:border-[#9B5CFF]/30 bg-white/92 dark:bg-[#080812]/90 p-7 shadow-sm">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF]">
                <Bot className="h-4 w-4" />
                <span>Gemini Grounded Intelligence</span>
              </div>
              <h2 className="mt-2 font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">
                Anime AI Assistant
              </h2>
              <p className="mt-3 text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
                Describe what you want to watch in plain language—moods, release years, studios, or favorite genres—and get recommendations verified directly against live AniList entries.
              </p>
            </div>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Link
                to="/ai-assistant"
                className="inline-flex items-center gap-2 rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#080812] hover:bg-[#5b2cd1] dark:hover:bg-[#8a46f7] transition-colors"
              >
                <Sparkles className="h-4 w-4" />
                Launch AI Assistant
              </Link>
              <Link
                to="/characters"
                className="inline-flex items-center gap-2 rounded-lg border border-[var(--aw-border-strong)] px-4 py-2.5 text-sm font-medium text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors"
              >
                Browse Characters
              </Link>
            </div>
          </div>

          <div className="rounded-2xl border border-[var(--aw-border)] bg-white/92 dark:bg-[#080812]/90 p-7 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#6D38E8] dark:text-[#9B5CFF]">
                <Users className="h-4 w-4" />
                <span>Featured Creators</span>
              </div>
              <Link to="/community" className="text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline">
                View Community
              </Link>
            </div>
            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {FEATURED_CREATORS.map((c) => (
                <Link
                  key={c.uid}
                  to={`/creators/${c.username}`}
                  className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#10101F] p-3 hover:border-[#6D38E8]/50 dark:hover:border-[#9B5CFF]/50 transition-colors"
                >
                  <img
                    src={c.avatarUrl}
                    alt={c.displayName}
                    referrerPolicy="no-referrer"
                    className="h-11 w-11 rounded-lg object-cover shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{c.displayName}</div>
                    <div className="truncate text-xs text-[#524E6B] dark:text-[#AAA7BC]">{c.specialty}</div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
