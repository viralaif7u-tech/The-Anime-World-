import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Activity,
  Bell,
  Bookmark,
  Camera,
  CheckCircle2,
  Clock,
  Compass,
  Download,
  Eye,
  EyeOff,
  FolderPlus,
  Heart,
  Image as ImageIcon,
  KeyRound,
  LogOut,
  Mail,
  Moon,
  Palette,
  Settings,
  Shield,
  Sparkles,
  Sun,
  Trash2,
  User as UserIcon,
} from 'lucide-react';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db, getCollectionItems } from '../services/firebase';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { SeoHead } from '../components/SeoHead';
import { LoadingPortalLogo } from '../components/BrandLogo';
import type { CollectionItemRecord, CollectionRecord, CommunityArtworkRecord, FavoriteRecord } from '../types/anime';
import { buildAnimeUrl } from '../lib/validation';
import { resizeAvatarToDataUrl } from '../lib/imageUpload';

const GENRE_CHOICES = [
  'Action',
  'Adventure',
  'Comedy',
  'Drama',
  'Fantasy',
  'Horror',
  'Mecha',
  'Mystery',
  'Psychological',
  'Romance',
  'Sci-Fi',
  'Slice of Life',
  'Sports',
  'Supernatural',
  'Thriller',
];

function getItemHref(fav: { itemType: string; itemId: string; title: string }) {
  if (fav.itemType === 'anime') return buildAnimeUrl(Number(fav.itemId) || 1, fav.title);
  if (fav.itemType === 'character') return `/characters/${fav.itemId}`;
  if (fav.itemType === 'wallpaper') return `/wallpapers/${fav.itemId}`;
  if (fav.itemType === 'model3d') return `/3d-world/${fav.itemId}`;
  if (fav.itemType === 'animation') return `/animations/${fav.itemId}`;
  return '/explore';
}

function RequireAuthPrompt({ title }: { title: string }) {
  return (
    <div className="mx-auto max-w-2xl px-4 py-20 text-center">
      <SeoHead title={title} description="Sign in to access your personalized THE ANIME WORLD space." />
      <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-8 shadow-xl">
        <UserIcon className="mx-auto h-10 w-10 text-[#6D38E8] dark:text-[#9B5CFF]" />
        <h1 className="mt-4 font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">Sign In Required</h1>
        <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
          Sign in to sync your saved anime, 4K wallpapers, 3D models, profile settings, and collections across devices.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link to="/login" className="rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#080812]">
            Sign In
          </Link>
          <Link to="/register" className="rounded-xl border border-[var(--aw-border-strong)] px-5 py-2.5 text-sm font-medium text-[#141229] dark:text-[#F5F3FF]">
            Create Account
          </Link>
        </div>
      </div>
    </div>
  );
}

export function DashboardPage() {
  const {
    user,
    authReady,
    publicProfile,
    privateUser,
    isAdmin,
    favorites,
    collections,
    notifications,
    unreadCount,
    logout,
    resendVerification,
    saveThemePreference,
  } = useAuth();
  const { theme } = useTheme();

  const [tab, setTab] = useState<'overview' | 'favorites' | 'collections' | 'uploads' | 'recent'>('overview');
  const [myUploads, setMyUploads] = useState<CommunityArtworkRecord[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<Array<{ id: number; title: string; image: string | null; url: string }>>([]);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = JSON.parse(localStorage.getItem('aw_recently_viewed') || '[]');
      if (Array.isArray(raw)) setRecentlyViewed(raw);
    } catch {
      // Ignore
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    getDocs(query(collection(db, 'communityArtworks'), where('authorId', '==', user.uid)))
      .then((snap) => setMyUploads(snap.docs.map((d) => d.data() as CommunityArtworkRecord)))
      .catch(() => {});
  }, [user]);

  if (!authReady) return <LoadingPortalLogo />;
  if (!user) return <RequireAuthPrompt title="User Dashboard" />;

  const displayName = publicProfile?.displayName || privateUser?.fullName || user.displayName || 'Anime Explorer';
  const savedWallpapers = favorites.filter((f) => f.itemType === 'wallpaper');

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title="User Dashboard" description="Personalized welcome hub, account activity, favorites, collections, and settings." />

      {/* Personalized Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 sm:p-8 shadow-sm">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-20 right-0 h-56 w-56 rounded-full bg-[#6D38E8]/15 dark:bg-[#9B5CFF]/20 blur-3xl"
        />
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-2xl border-2 border-[#6D38E8]/45 dark:border-[#9B5CFF]/45 bg-[var(--aw-surface-elevated)]">
              {publicProfile?.avatarUrl || user.photoURL ? (
                <img
                  src={publicProfile?.avatarUrl || user.photoURL || ''}
                  alt={displayName}
                  className="h-full w-full object-cover"
                />
              ) : (
                <UserIcon className="h-7 w-7 text-[#6D38E8] dark:text-[#9B5CFF]" />
              )}
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-[#0284C7] dark:text-[#43B8FF]">
                Personal Anime Hub
              </p>
              <h1 className="mt-0.5 font-display text-2xl sm:text-3xl font-extrabold text-[#141229] dark:text-[#F5F3FF]">
                Welcome back, {displayName}
              </h1>
              <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                @{publicProfile?.username || 'traveler'} · {user.email} · {user.emailVerified ? 'Verified Explorer' : 'Pending Email Verification'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {isAdmin && (
              <Link
                to="/admin"
                className="inline-flex items-center gap-1.5 rounded-xl border border-[#0284C7]/45 dark:border-[#43B8FF]/50 bg-white dark:bg-[#080812] px-3.5 py-2 text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF]"
              >
                <Shield className="h-4 w-4" /> Admin Console
              </Link>
            )}
            <Link
              to="/profile"
              className="inline-flex items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3.5 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#6D38E8] dark:hover:border-[#9B5CFF]"
            >
              <UserIcon className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" /> My Profile
            </Link>
            <Link
              to="/settings"
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-3.5 py-2 text-xs font-semibold text-white dark:text-[#080812]"
            >
              <Settings className="h-4 w-4" /> Account Settings
            </Link>
            <button
              type="button"
              onClick={() => void logout()}
              className="inline-flex items-center gap-1.5 rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3.5 py-2 text-xs text-[#524E6B] dark:text-[#AAA7BC] hover:text-red-600 dark:hover:text-red-400"
            >
              <LogOut className="h-4 w-4" /> Logout
            </button>
          </div>
        </div>
      </div>

      {!user.emailVerified && (
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-500/40 bg-amber-50 dark:bg-amber-950/25 px-4 py-3 text-xs text-amber-800 dark:text-amber-200">
          <span>Verify your email address to unlock saving favorites, editing your profile, and posting community art.</span>
          <button
            type="button"
            onClick={async () => {
              await resendVerification();
              setStatusMsg('Verification email sent. Check your inbox.');
            }}
            className="rounded-lg bg-amber-500 px-3 py-1.5 font-semibold text-white dark:text-[#080812]"
          >
            Resend Verification Email
          </button>
        </div>
      )}

      {statusMsg && (
        <div className="mt-4 rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white/90 dark:bg-[#10101F]/90 px-4 py-3 text-xs text-[#0284C7] dark:text-[#43B8FF]">
          {statusMsg}
        </div>
      )}

      {/* Tabs */}
      <div className="mt-6 flex flex-wrap gap-2">
        {[
          { id: 'overview', label: 'Overview', icon: Sparkles },
          { id: 'favorites', label: `Favorites (${favorites.length})`, icon: Heart },
          { id: 'collections', label: `Collections (${collections.length})`, icon: Bookmark },
          { id: 'uploads', label: `My Uploads (${myUploads.length})`, icon: ImageIcon },
          { id: 'recent', label: `Recent Activity (${recentlyViewed.length})`, icon: Clock },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id as typeof tab)}
              className={`inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-semibold transition-colors ${
                tab === item.id
                  ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                  : 'border border-[var(--aw-border)] bg-white/85 dark:bg-[#10101F]/85 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
              }`}
            >
              <Icon className="h-3.5 w-3.5" />
              {item.label}
            </button>
          );
        })}
      </div>

      {tab === 'overview' && (
        <div className="mt-8 space-y-8">
          {/* Account Activity Stats */}
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <div className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-4">
              <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Saved Favorites</div>
              <div className="mt-1 font-mono-tabular text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">{favorites.length}</div>
            </div>
            <div className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-4">
              <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Custom Collections</div>
              <div className="mt-1 font-mono-tabular text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">{collections.length}</div>
            </div>
            <div className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-4">
              <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Saved Wallpapers</div>
              <div className="mt-1 font-mono-tabular text-2xl font-bold text-[#141229] dark:text-[#F5F3FF]">{savedWallpapers.length}</div>
            </div>
            <div className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-4">
              <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Unread Notifications</div>
              <div className="mt-1 font-mono-tabular text-2xl font-bold text-[#0284C7] dark:text-[#43B8FF]">{unreadCount}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {/* Quick Navigation */}
            <div className="lg:col-span-2 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
              <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">Quick Navigation</h2>
              <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 text-xs">
                <Link to="/profile" className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3.5 hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] transition-colors">
                  <UserIcon className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
                  <div>
                    <div className="font-semibold text-[#141229] dark:text-[#F5F3FF]">Edit My Profile</div>
                    <div className="text-[#524E6B] dark:text-[#AAA7BC]">Upload avatar &amp; bio</div>
                  </div>
                </Link>
                <Link to="/settings" className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3.5 hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] transition-colors">
                  <Settings className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
                  <div>
                    <div className="font-semibold text-[#141229] dark:text-[#F5F3FF]">Account &amp; Security Settings</div>
                    <div className="text-[#524E6B] dark:text-[#AAA7BC]">Password, genres &amp; theme</div>
                  </div>
                </Link>
                <Link to="/favorites" className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3.5 hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] transition-colors">
                  <Heart className="h-4 w-4 text-rose-500" />
                  <div>
                    <div className="font-semibold text-[#141229] dark:text-[#F5F3FF]">Favorites Library</div>
                    <div className="text-[#524E6B] dark:text-[#AAA7BC]">{favorites.length} saved items</div>
                  </div>
                </Link>
                <Link to="/collections" className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3.5 hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] transition-colors">
                  <Bookmark className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
                  <div>
                    <div className="font-semibold text-[#141229] dark:text-[#F5F3FF]">Curated Collections</div>
                    <div className="text-[#524E6B] dark:text-[#AAA7BC]">{collections.length} watchlists</div>
                  </div>
                </Link>
                <Link to="/explore" className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3.5 hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors">
                  <Compass className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
                  <div>
                    <div className="font-semibold text-[#141229] dark:text-[#F5F3FF]">Explore Anime Catalog</div>
                    <div className="text-[#524E6B] dark:text-[#AAA7BC]">Search live global releases</div>
                  </div>
                </Link>
                <Link to="/ai-assistant" className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3.5 hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors">
                  <Sparkles className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
                  <div>
                    <div className="font-semibold text-[#141229] dark:text-[#F5F3FF]">Anime AI Assistant</div>
                    <div className="text-[#524E6B] dark:text-[#AAA7BC]">Smart genre matching</div>
                  </div>
                </Link>
                <Link to="/downloads" className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3.5 hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors">
                  <Download className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
                  <div>
                    <div className="font-semibold text-[#141229] dark:text-[#F5F3FF]">My Downloads</div>
                    <div className="text-[#524E6B] dark:text-[#AAA7BC]">MP4 videos &amp; download status</div>
                  </div>
                </Link>
                <Link to="/privacy-settings" className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3.5 hover:border-[#6D38E8] dark:hover:border-[#9B5CFF] transition-colors">
                  <Shield className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
                  <div>
                    <div className="font-semibold text-[#141229] dark:text-[#F5F3FF]">Privacy Settings</div>
                    <div className="text-[#524E6B] dark:text-[#AAA7BC]">Visibility &amp; data isolation</div>
                  </div>
                </Link>
                <Link to="/workspace" className="flex items-center gap-3 rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3.5 hover:border-[#0284C7] dark:hover:border-[#43B8FF] transition-colors">
                  <Mail className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
                  <div>
                    <div className="font-semibold text-[#141229] dark:text-[#F5F3FF]">Gmail &amp; Google Drive</div>
                    <div className="text-[#524E6B] dark:text-[#AAA7BC]">Inbox, send &amp; Drive backups</div>
                  </div>
                </Link>
              </div>
            </div>

            {/* Appearance & Quick Theme Card */}
            <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-xs font-semibold text-[#6D38E8] dark:text-[#9B5CFF]">
                  <Palette className="h-4 w-4" />
                  <span>Appearance Preference</span>
                </div>
                <h2 className="mt-1 font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">
                  {theme === 'dark' ? 'Cosmic Dark Mode' : 'Daylight Anime Mode'}
                </h2>
                <p className="mt-1.5 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                  Switch between deep obsidian starlight and clean sunlit sky themes anytime.
                </p>
              </div>

              <div className="mt-5 grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => void saveThemePreference('dark')}
                  className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-semibold transition-all ${
                    theme === 'dark'
                      ? 'border-[#9B5CFF] bg-[#9B5CFF] text-[#080812]'
                      : 'border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)]/60 text-[#141229] dark:text-[#F5F3FF]'
                  }`}
                >
                  <Moon className="h-4 w-4" /> Dark
                </button>
                <button
                  type="button"
                  onClick={() => void saveThemePreference('light')}
                  className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-xs font-semibold transition-all ${
                    theme === 'light'
                      ? 'border-[#6D38E8] bg-[#6D38E8] text-white'
                      : 'border-[var(--aw-border-strong)] bg-white/10 text-[#141229] dark:text-[#F5F3FF]'
                  }`}
                >
                  <Sun className="h-4 w-4" /> Light
                </button>
              </div>
            </div>
          </div>

          {/* Recent Activity & Notifications */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF]" />
                  <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">Recent Viewing Activity</h2>
                </div>
                <Link to="/explore" className="text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline">
                  Discover More
                </Link>
              </div>
              {privateUser?.hideViewingActivity ? (
                <p className="mt-3 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                  Recent viewing activity is hidden per your Privacy Settings.
                </p>
              ) : recentlyViewed.length === 0 ? (
                <p className="mt-3 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
                  Browse anime detail pages to build your recent viewing timeline.
                </p>
              ) : (
                <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-4">
                  {recentlyViewed.slice(0, 4).map((item) => (
                    <Link key={item.id} to={item.url} className="group overflow-hidden rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80">
                      <div className="aspect-[3/4]">
                        {item.image && <img src={item.image} alt={item.title} referrerPolicy="no-referrer" className="h-full w-full object-cover" />}
                      </div>
                      <div className="p-2 text-[11px] font-medium text-[#141229] dark:text-[#F5F3FF] group-hover:text-[#0284C7] dark:group-hover:text-[#43B8FF] line-clamp-1">
                        {item.title}
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="h-4 w-4 text-[#6D38E8] dark:text-[#9B5CFF]" />
                  <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">Recent Notifications</h2>
                </div>
                <Link to="/notifications" className="text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline">
                  View All
                </Link>
              </div>
              {notifications.length === 0 ? (
                <p className="mt-3 text-xs text-[#524E6B] dark:text-[#AAA7BC]">You are all caught up.</p>
              ) : (
                <div className="mt-3 space-y-2.5">
                  {notifications.slice(0, 3).map((n) => (
                    <div key={n.id} className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812]/80 p-3">
                      <div className="text-xs font-semibold text-[#141229] dark:text-[#F5F3FF]">{n.title}</div>
                      <p className="mt-0.5 text-xs text-[#524E6B] dark:text-[#AAA7BC]">{n.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {tab === 'favorites' && <FavoritesGrid favorites={favorites} />}

      {tab === 'collections' && (
        <div className="mt-8">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold text-[#141229] dark:text-[#F5F3FF]">Your Anime Collections</h2>
            <Link to="/collections" className="rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]">
              Open Collections Manager
            </Link>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {collections.map((c) => (
              <Link key={c.id} to="/collections" className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-4 hover:border-[#6D38E8] dark:hover:border-[#9B5CFF]">
                <div className="text-xs text-[#0284C7] dark:text-[#43B8FF]">{c.isPublic ? 'Public' : 'Private'} · {c.itemsCount} items</div>
                <h3 className="mt-1 font-display text-base font-semibold text-[#141229] dark:text-[#F5F3FF]">{c.name}</h3>
                {c.description && <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC] line-clamp-2">{c.description}</p>}
              </Link>
            ))}
          </div>
        </div>
      )}

      {tab === 'uploads' && (
        <div className="mt-8">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold text-[#141229] dark:text-[#F5F3FF]">My Community Uploads</h2>
            <Link to="/community" className="text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline">
              Publish in Community →
            </Link>
          </div>
          {myUploads.length === 0 ? (
            <p className="mt-4 text-sm text-[#524E6B] dark:text-[#AAA7BC]">You have not uploaded any community artworks yet.</p>
          ) : (
            <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {myUploads.map((art) => (
                <div key={art.id} className="overflow-hidden rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90">
                  <img src={art.imageUrl} alt={art.title} className="aspect-video w-full object-cover" />
                  <div className="p-4">
                    <div className="text-xs text-[#0284C7] dark:text-[#43B8FF]">{art.category} · {art.status}</div>
                    <h3 className="mt-1 font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{art.title}</h3>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'recent' && (
        <div className="mt-8">
          <h2 className="font-display text-lg font-semibold text-[#141229] dark:text-[#F5F3FF]">Recently Viewed Anime</h2>
          {recentlyViewed.length === 0 ? (
            <p className="mt-3 text-sm text-[#524E6B] dark:text-[#AAA7BC]">Browse the anime catalog to populate your viewing history.</p>
          ) : (
            <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-6">
              {recentlyViewed.map((item) => (
                <Link key={item.id} to={item.url} className="group overflow-hidden rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90">
                  <div className="aspect-[3/4] bg-[var(--aw-surface-elevated)]">
                    {item.image && <img src={item.image} alt={item.title} referrerPolicy="no-referrer" className="h-full w-full object-cover" />}
                  </div>
                  <div className="p-2.5 text-xs font-medium text-[#141229] dark:text-[#F5F3FF] group-hover:text-[#0284C7] dark:group-hover:text-[#43B8FF] line-clamp-2">
                    {item.title}
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function FavoritesGrid({ favorites }: { favorites: FavoriteRecord[] }) {
  const { toggleFavorite } = useAuth();
  const [filter, setFilter] = useState<string>('all');
  const [feedback, setFeedback] = useState<{ kind: 'success' | 'error'; text: string } | null>(null);
  const shown = filter === 'all' ? favorites : favorites.filter((f) => f.itemType === filter);

  const handleRemoveFavorite = async (fav: FavoriteRecord) => {
    setFeedback(null);
    try {
      await toggleFavorite({
        itemType: fav.itemType,
        itemId: fav.itemId,
        title: fav.title,
        imageUrl: fav.imageUrl,
      });
      setFeedback({ kind: 'success', text: `"${fav.title}" removed from your favorites.` });
    } catch (err) {
      setFeedback({
        kind: 'error',
        text: err instanceof Error ? err.message : 'Unable to update favorites.',
      });
    }
  };

  return (
    <div className="mt-8">
      <div className="flex flex-wrap gap-2">
        {['all', 'anime', 'character', 'wallpaper', 'model3d', 'animation'].map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setFilter(t)}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium capitalize ${
              filter === t
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border)] bg-white/85 dark:bg-[#10101F]/85 text-[#524E6B] dark:text-[#AAA7BC]'
            }`}
          >
            {t === 'model3d' ? '3D Models' : t}
          </button>
        ))}
      </div>

      {feedback && (
        <div
          role={feedback.kind === 'error' ? 'alert' : 'status'}
          className={`mt-4 rounded-xl border px-4 py-3 text-xs ${
            feedback.kind === 'error'
              ? 'border-red-500/40 bg-red-50 text-red-800 dark:bg-red-950/30 dark:text-red-200'
              : 'border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white/90 dark:bg-[#10101F]/90 text-[#0284C7] dark:text-[#43B8FF]'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {shown.length === 0 ? (
        <p className="mt-6 text-sm text-[#524E6B] dark:text-[#AAA7BC]">No saved favorites in this category yet.</p>
      ) : (
        <div className="mt-5 grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
          {shown.map((fav) => (
            <div key={fav.id} className="overflow-hidden rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 flex flex-col">
              <Link to={getItemHref(fav)} className="block aspect-[4/3] bg-[var(--aw-surface-elevated)]">
                {fav.imageUrl && (
                  <img src={fav.imageUrl} alt={fav.title} referrerPolicy="no-referrer" className="h-full w-full object-cover" />
                )}
              </Link>
              <div className="flex flex-1 flex-col justify-between p-3.5">
                <div>
                  <div className="text-[11px] uppercase text-[#0284C7] dark:text-[#43B8FF]">{fav.itemType}</div>
                  <Link to={getItemHref(fav)} className="mt-1 block font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF] hover:text-[#0284C7] dark:hover:text-[#43B8FF] line-clamp-2">
                    {fav.title}
                  </Link>
                </div>
                <button
                  type="button"
                  onClick={() => void handleRemoveFavorite(fav)}
                  className="mt-3 inline-flex items-center gap-1 text-xs text-red-500 hover:underline"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function ProfilePage() {
  const {
    user,
    authReady,
    publicProfile,
    privateUser,
    favorites,
    collections,
    updateUserProfile,
    logout,
  } = useAuth();

  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setFullName(privateUser?.fullName || user?.displayName || '');
    setDisplayName(publicProfile?.displayName || user?.displayName || '');
    setUsername(publicProfile?.username || '');
    setBio(publicProfile?.bio || '');
    setAvatarUrl(publicProfile?.avatarUrl || user?.photoURL || '');
    setIsPublic(publicProfile?.isPublic ?? true);
  }, [publicProfile, privateUser, user]);

  if (!authReady) return <LoadingPortalLogo />;
  if (!user) return <RequireAuthPrompt title="My Profile" />;

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMsg(null);
    setStatusMsg(null);
    try {
      const compressed = await resizeAvatarToDataUrl(file);
      setAvatarUrl(compressed);
      setEditing(true);
      setStatusMsg('Profile picture prepared. Click Save Profile Changes to persist.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to process uploaded picture.');
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setStatusMsg(null);
    setSaving(true);
    try {
      await updateUserProfile({
        fullName: fullName.trim(),
        displayName: displayName.trim(),
        username: username.trim(),
        bio: bio.trim(),
        avatarUrl: avatarUrl.trim(),
        isPublic,
      });
      setStatusMsg('Profile updated successfully across your account.');
      setEditing(false);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to save profile.');
    } finally {
      setSaving(false);
    }
  };

  const providers = user.providerData.map((p) => p.providerId).join(', ') || 'email';

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8 space-y-6">
      <SeoHead title="My Profile" description="Manage your personal anime profile, avatar upload, username, full name, and account details." />

      <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-7 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div className="flex flex-wrap items-center gap-5">
            <div className="relative">
              <div className="h-24 w-24 overflow-hidden rounded-2xl border-2 border-[#6D38E8]/45 dark:border-[#9B5CFF]/45 bg-[var(--aw-surface-elevated)] flex items-center justify-center">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Profile picture" className="h-full w-full object-cover" />
                ) : (
                  <UserIcon className="h-9 w-9 text-[#6D38E8] dark:text-[#9B5CFF]" />
                )}
              </div>
              <label
                title="Upload profile picture"
                className="absolute -bottom-2 -right-2 flex h-8 w-8 cursor-pointer items-center justify-center rounded-xl border border-white/20 bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812] shadow-md hover:opacity-90"
              >
                <Camera className="h-4 w-4" />
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={(e) => void handleAvatarUpload(e)}
                  className="sr-only"
                />
              </label>
            </div>

            <div>
              <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#141229] dark:text-[#F5F3FF]">
                {publicProfile?.displayName || user.displayName || 'Anime Explorer'}
              </h1>
              <p className="text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF]">
                @{publicProfile?.username || 'explorer'} · {privateUser?.fullName || user.displayName || 'Member'}
              </p>
              <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">{user.email}</p>
              <p className="mt-2 max-w-xl text-sm text-[#524E6B] dark:text-[#AAA7BC]">
                {publicProfile?.bio || 'Exploring worlds on THE ANIME WORLD.'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2.5">
            <button
              type="button"
              onClick={() => setEditing((v) => !v)}
              className="rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]"
            >
              {editing ? 'Cancel Editing' : 'Edit Profile'}
            </button>
            <Link
              to="/settings"
              className="rounded-xl border border-[var(--aw-border-strong)] px-4 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF]"
            >
              Account Settings
            </Link>
            <button
              type="button"
              onClick={() => void logout()}
              className="inline-flex items-center gap-1.5 rounded-xl border border-red-500/35 px-4 py-2 text-xs font-semibold text-red-600 dark:text-red-400"
            >
              <LogOut className="h-3.5 w-3.5" /> Logout
            </button>
          </div>
        </div>

        {statusMsg && (
          <div className="mt-5 rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812] px-4 py-3 text-xs text-[#0284C7] dark:text-[#43B8FF]">
            {statusMsg}
          </div>
        )}
        {errorMsg && (
          <div className="mt-5 rounded-xl border border-red-500/40 bg-red-50 dark:bg-red-950/30 px-4 py-3 text-xs text-red-700 dark:text-red-200">
            {errorMsg}
          </div>
        )}

        {editing && (
          <form onSubmit={(e) => void handleSave(e)} className="mt-6 border-t border-[var(--aw-border)] pt-6 space-y-4">
            <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">Edit Profile Information</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3.5 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Display Name</label>
                <input
                  type="text"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3.5 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Username</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3.5 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Bio</label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3.5 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
              />
            </div>

            <label className="flex items-center gap-2.5 text-xs text-[#141229] dark:text-[#F5F3FF] cursor-pointer">
              <input
                type="checkbox"
                checked={isPublic}
                onChange={(e) => setIsPublic(e.target.checked)}
                className="accent-[#6D38E8] dark:accent-[#9B5CFF]"
              />
              Display my profile publicly in Community &amp; Creator pages
            </label>

            <button
              type="submit"
              disabled={saving}
              className="rounded-xl bg-gradient-to-r from-[#6D38E8] to-[#0284C7] dark:from-[#9B5CFF] dark:to-[#43B8FF] px-5 py-2.5 text-xs font-bold text-white dark:text-[#080812] disabled:opacity-50"
            >
              {saving ? 'Saving Changes...' : 'Save Profile Changes'}
            </button>
          </form>
        )}

        <div className="mt-8 grid grid-cols-3 gap-4 border-t border-[var(--aw-border)] pt-6 text-center">
          <div>
            <div className="font-mono-tabular text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">{favorites.length}</div>
            <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Favorites</div>
          </div>
          <div>
            <div className="font-mono-tabular text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">{collections.length}</div>
            <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Collections</div>
          </div>
          <div>
            <div className="font-mono-tabular text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">{publicProfile?.followersCount ?? 0}</div>
            <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">Followers</div>
          </div>
        </div>
      </div>

      {/* Account Information Card */}
      <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
        <h2 className="font-display text-lg font-bold text-[#141229] dark:text-[#F5F3FF]">Account Information</h2>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 text-xs">
          <div className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/50 dark:bg-[#080812]/80 p-3.5">
            <div className="text-[#524E6B] dark:text-[#AAA7BC]">Email Address</div>
            <div className="mt-1 font-semibold text-[#141229] dark:text-[#F5F3FF] truncate">{user.email}</div>
          </div>
          <div className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/50 dark:bg-[#080812]/80 p-3.5">
            <div className="text-[#524E6B] dark:text-[#AAA7BC]">Verification Status</div>
            <div className="mt-1 font-semibold text-[#0284C7] dark:text-[#43B8FF]">
              {user.emailVerified ? 'Verified' : 'Unverified'}
            </div>
          </div>
          <div className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/50 dark:bg-[#080812]/80 p-3.5">
            <div className="text-[#524E6B] dark:text-[#AAA7BC]">Sign-In Provider</div>
            <div className="mt-1 font-semibold text-[#141229] dark:text-[#F5F3FF] truncate">{providers}</div>
          </div>
          <div className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/50 dark:bg-[#080812]/80 p-3.5">
            <div className="text-[#524E6B] dark:text-[#AAA7BC]">Account ID</div>
            <div className="mt-1 font-mono-tabular font-semibold text-[#141229] dark:text-[#F5F3FF] truncate">{user.uid}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function AccountSettingsPage() {
  const {
    user,
    authReady,
    privateUser,
    publicProfile,
    updateFavoriteGenres,
    saveThemePreference,
    changeUserPassword,
    logout,
  } = useAuth();
  const { theme } = useTheme();

  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [passMsg, setPassMsg] = useState<string | null>(null);
  const [passErr, setPassErr] = useState<string | null>(null);
  const [genreMsg, setGenreMsg] = useState<string | null>(null);

  useEffect(() => {
    if (privateUser?.favoriteGenres) {
      setSelectedGenres(privateUser.favoriteGenres);
    }
  }, [privateUser]);

  if (!authReady) return <LoadingPortalLogo />;
  if (!user) return <RequireAuthPrompt title="Account Settings" />;

  const toggleGenre = (g: string) => {
    setSelectedGenres((prev) =>
      prev.includes(g) ? prev.filter((x) => x !== g) : prev.length < 15 ? [...prev, g] : prev
    );
  };

  const handleSaveGenres = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenreMsg(null);
    try {
      await updateFavoriteGenres(selectedGenres);
      setGenreMsg('AI genre preferences updated.');
    } catch (err) {
      setGenreMsg(err instanceof Error ? err.message : 'Unable to save genres.');
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);
    setPassErr(null);
    if (newPass.length < 8) {
      setPassErr('New password must be at least 8 characters long.');
      return;
    }
    if (newPass !== confirmPass) {
      setPassErr('New passwords do not match.');
      return;
    }
    try {
      await changeUserPassword(currentPass, newPass);
      setCurrentPass('');
      setNewPass('');
      setConfirmPass('');
      setPassMsg('Password changed successfully.');
    } catch (err) {
      setPassErr(err instanceof Error ? err.message : 'Could not update password.');
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8 space-y-8">
      <SeoHead title="Account Settings & Appearance" description="Customize Dark Mode, Light Mode, security password, and AI anime preferences." />

      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[var(--aw-border)] pb-5">
        <div>
          <h1 className="font-display text-3xl font-extrabold text-[#141229] dark:text-[#F5F3FF]">Account Settings</h1>
          <p className="mt-1 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Appearance, security credentials, and AI personalization for @{publicProfile?.username || 'traveler'}.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void logout()}
          className="inline-flex items-center gap-2 rounded-xl border border-red-500/35 px-4 py-2 text-xs font-semibold text-red-600 dark:text-red-400"
        >
          <LogOut className="h-4 w-4" /> Logout
        </button>
      </div>

      {/* Appearance Section (Dark Mode & Light Mode) */}
      <section id="appearance" className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#6D38E8] dark:text-[#9B5CFF]">
          <Palette className="h-4 w-4" />
          <span>Appearance &amp; Theme</span>
        </div>
        <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Dark Mode &amp; Light Mode</h2>
        <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">
          Choose your visual atmosphere. Your selection applies smoothly across all pages and persists automatically.
        </p>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => void saveThemePreference('dark')}
            className={`flex items-start gap-4 rounded-2xl border p-4 text-left transition-all ${
              theme === 'dark'
                ? 'border-[#9B5CFF] bg-[#080812] text-[#F5F3FF] ring-2 ring-[#9B5CFF]/30'
                : 'border-[var(--aw-border)] bg-[#080812]/90 text-[#F5F3FF] opacity-80 hover:opacity-100'
            }`}
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#9B5CFF]/20 text-[#9B5CFF]">
              <Moon className="h-5 w-5" />
            </div>
            <div>
              <div className="font-display text-sm font-bold">Dark Mode {theme === 'dark' ? '· Active' : ''}</div>
              <p className="mt-1 text-xs text-[#AAA7BC]">Cosmic obsidian night sky, neon violet energy, and luminous starfield.</p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => void saveThemePreference('light')}
            className={`flex items-start gap-4 rounded-2xl border p-4 text-left transition-all ${
              theme === 'light'
                ? 'border-[#6D38E8] bg-white text-[#141229] ring-2 ring-[#6D38E8]/30'
                : 'border-[var(--aw-border)] bg-[#f3f2fb] text-[#141229] opacity-85 hover:opacity-100'
            }`}
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#6D38E8]/15 text-[#6D38E8]">
              <Sun className="h-5 w-5" />
            </div>
            <div>
              <div className="font-display text-sm font-bold">Light Mode {theme === 'light' ? '· Active' : ''}</div>
              <p className="mt-1 text-xs text-[#524E6B]">Clean sunlit anime sky, drifting white clouds, and crisp high-contrast surfaces.</p>
            </div>
          </button>
        </div>
      </section>

      {/* Change Password */}
      <section className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#0284C7] dark:text-[#43B8FF]">
          <KeyRound className="h-4 w-4" />
          <span>Security</span>
        </div>
        <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Change Password</h2>

        {passErr && (
          <div className="rounded-xl border border-red-500/40 bg-red-50 dark:bg-red-950/30 p-3 text-xs text-red-700 dark:text-red-200">
            {passErr}
          </div>
        )}
        {passMsg && (
          <div className="rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812] p-3 text-xs text-[#0284C7] dark:text-[#43B8FF]">
            {passMsg}
          </div>
        )}

        <form onSubmit={(e) => void handleChangePassword(e)} className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div>
            <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Current Password</label>
            <div className="relative">
              <input
                type={showCurrent ? 'text' : 'password'}
                required
                value={currentPass}
                onChange={(e) => setCurrentPass(e.target.value)}
                className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 pr-9 text-sm text-[#141229] dark:text-[#F5F3FF]"
              />
              <button
                type="button"
                onClick={() => setShowCurrent((v) => !v)}
                aria-label="Toggle current password visibility"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]"
              >
                {showCurrent ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">New Password</label>
            <div className="relative">
              <input
                type={showNew ? 'text' : 'password'}
                required
                value={newPass}
                onChange={(e) => setNewPass(e.target.value)}
                className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 pr-9 text-sm text-[#141229] dark:text-[#F5F3FF]"
              />
              <button
                type="button"
                onClick={() => setShowNew((v) => !v)}
                aria-label="Toggle new password visibility"
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]"
              >
                {showNew ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Confirm New Password</label>
            <input
              type="password"
              required
              value={confirmPass}
              onChange={(e) => setConfirmPass(e.target.value)}
              className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
            />
          </div>

          <div className="sm:col-span-3">
            <button
              type="submit"
              className="rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-xs font-semibold text-white dark:text-[#080812]"
            >
              Update Password
            </button>
          </div>
        </form>
      </section>

      {/* AI Genre Personalization */}
      <form onSubmit={(e) => void handleSaveGenres(e)} className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4">
        <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">AI Discovery Genres</h2>
        <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">
          Select up to 15 genres used by the Gemini Anime AI Assistant when personalizing recommendations.
        </p>
        {genreMsg && <p className="text-xs text-[#0284C7] dark:text-[#43B8FF]">{genreMsg}</p>}
        <div className="flex flex-wrap gap-2">
          {GENRE_CHOICES.map((g) => {
            const active = selectedGenres.includes(g);
            return (
              <button
                key={g}
                type="button"
                onClick={() => toggleGenre(g)}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                  active
                    ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                    : 'border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812] text-[#524E6B] dark:text-[#AAA7BC]'
                }`}
              >
                {g}
              </button>
            );
          })}
        </div>
        <button
          type="submit"
          className="rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-xs font-semibold text-white dark:text-[#080812]"
        >
          Save Genre Preferences
        </button>
      </form>
    </div>
  );
}

export function FavoritesPage() {
  const { user, authReady, favorites } = useAuth();
  if (!authReady) return <LoadingPortalLogo />;
  if (!user) return <RequireAuthPrompt title="My Favorites" />;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title="My Favorites" description="Your saved anime, characters, 4K wallpapers, and 3D models." />
      <h1 className="font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">My Favorites</h1>
      <p className="mt-1 text-sm text-[#524E6B] dark:text-[#AAA7BC]">Synced securely across sessions with Cloud Firestore.</p>
      <FavoritesGrid favorites={favorites} />
    </div>
  );
}

export function CollectionsPage() {
  const {
    user,
    authReady,
    collections,
    createCollection,
    updateCollection,
    deleteCollectionById,
    removeCollectionItem,
  } = useAuth();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [selectedCol, setSelectedCol] = useState<CollectionRecord | null>(null);
  const [items, setItems] = useState<CollectionItemRecord[]>([]);
  const [feedback, setFeedback] = useState<{ kind: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (!selectedCol || !user) return;
    let active = true;
    getCollectionItems(selectedCol.id, user.uid).then((result) => {
      if (!active) return;
      if (result.ok) {
        setItems(result.data);
      } else {
        setItems([]);
        setFeedback({ kind: 'error', text: result.message });
      }
    });
    return () => {
      active = false;
    };
  }, [selectedCol, user]);

  if (!authReady) return <LoadingPortalLogo />;
  if (!user) return <RequireAuthPrompt title="My Collections" />;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setFeedback(null);
    try {
      await createCollection(name, description, isPublic);
      setName('');
      setDescription('');
      setFeedback({ kind: 'success', text: `Collection "${name.trim()}" created and synced.` });
    } catch (err) {
      setFeedback({
        kind: 'error',
        text: err instanceof Error ? err.message : 'Unable to create collection.',
      });
    }
  };

  const handleToggleVisibility = async (col: CollectionRecord) => {
    setFeedback(null);
    const result = await updateCollection(col.id, {
      name: col.name,
      description: col.description,
      isPublic: !col.isPublic,
      coverImage: col.coverImage,
    });
    setFeedback({ kind: result.ok ? 'success' : 'error', text: result.message });
  };

  const handleDeleteCollection = async (col: CollectionRecord) => {
    setFeedback(null);
    const result = await deleteCollectionById(col.id, col.name);
    if (result.ok && selectedCol?.id === col.id) {
      setSelectedCol(null);
      setItems([]);
    }
    setFeedback({ kind: result.ok ? 'success' : 'error', text: result.message });
  };

  const handleRemoveItem = async (item: CollectionItemRecord) => {
    if (!selectedCol) return;
    setFeedback(null);
    const result = await removeCollectionItem(
      selectedCol.id,
      item.id,
      selectedCol.itemsCount || items.length,
      item.title
    );
    if (result.ok) {
      setItems((prev) => prev.filter((x) => x.id !== item.id));
    }
    setFeedback({ kind: result.ok ? 'success' : 'error', text: result.message });
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title="My Anime Collections" description="Organize custom watchlists, dark fantasy tiers, and anime playlists." />

      <h1 className="font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">My Anime Collections</h1>
      <p className="mt-1 text-sm text-[#524E6B] dark:text-[#AAA7BC]">Create public or private lists and add anime directly from any Anime Details page.</p>

      {feedback && (
        <div
          role={feedback.kind === 'error' ? 'alert' : 'status'}
          className={`mt-4 rounded-xl border px-4 py-3 text-xs ${
            feedback.kind === 'error'
              ? 'border-red-500/40 bg-red-50 text-red-800 dark:bg-red-950/30 dark:text-red-200'
              : 'border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-white/90 dark:bg-[#10101F]/90 text-[#0284C7] dark:text-[#43B8FF]'
          }`}
        >
          {feedback.text}
        </div>
      )}

      <form onSubmit={(e) => void handleCreate(e)} className="mt-6 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-5 grid grid-cols-1 gap-4 md:grid-cols-4 items-end">
        <div>
          <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Collection Name</label>
          <input
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Cyberpunk Classics"
            className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
          />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Description</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Curated futuristic dystopias and atmospheric sci-fi"
            className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-white dark:bg-[#080812] px-3 py-2 text-sm text-[#141229] dark:text-[#F5F3FF]"
          />
        </div>
        <div className="flex items-center justify-between gap-3">
          <label className="flex items-center gap-2 text-xs text-[#141229] dark:text-[#F5F3FF] cursor-pointer">
            <input type="checkbox" checked={isPublic} onChange={(e) => setIsPublic(e.target.checked)} className="accent-[#6D38E8] dark:accent-[#9B5CFF]" />
            Public
          </label>
          <button type="submit" className="inline-flex items-center gap-1.5 rounded-lg bg-[#6D38E8] dark:bg-[#9B5CFF] px-4 py-2 text-xs font-semibold text-white dark:text-[#080812]">
            <FolderPlus className="h-4 w-4" /> Create
          </button>
        </div>
      </form>

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-3">
          {collections.length === 0 ? (
            <p className="text-sm text-[#524E6B] dark:text-[#AAA7BC]">No collections created yet.</p>
          ) : (
            collections.map((col) => (
              <div
                key={col.id}
                className={`rounded-xl border p-4 cursor-pointer bg-white/90 dark:bg-[#10101F]/90 ${
                  selectedCol?.id === col.id ? 'border-[#6D38E8] dark:border-[#9B5CFF]' : 'border-[var(--aw-border)]'
                }`}
                onClick={() => setSelectedCol(col)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-display text-base font-semibold text-[#141229] dark:text-[#F5F3FF]">{col.name}</h3>
                    <p className="text-xs text-[#0284C7] dark:text-[#43B8FF]">{col.isPublic ? 'Public' : 'Private'} · {col.itemsCount} items</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        void handleToggleVisibility(col);
                      }}
                      className="text-[11px] text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]"
                    >
                      Toggle
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        void handleDeleteCollection(col);
                      }}
                      className="text-red-500 hover:text-red-400"
                      aria-label={`Delete collection ${col.name}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="lg:col-span-2 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6">
          {!selectedCol ? (
            <p className="text-sm text-[#524E6B] dark:text-[#AAA7BC]">Select a collection on the left to inspect its anime entries.</p>
          ) : (
            <>
              <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">{selectedCol.name}</h2>
              <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">{selectedCol.description || 'No description.'}</p>
              {items.length === 0 ? (
                <p className="mt-6 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
                  This collection is empty. Open any <Link to="/explore" className="text-[#0284C7] dark:text-[#43B8FF] underline">Anime Details</Link> page to add entries here.
                </p>
              ) : (
                <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-3">
                  {items.map((item) => (
                    <div key={item.id} className="overflow-hidden rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)]/60 dark:bg-[#080812] flex flex-col">
                      <Link to={getItemHref(item)} className="block flex-1">
                        {item.imageUrl && <img src={item.imageUrl} alt={item.title} referrerPolicy="no-referrer" className="aspect-[3/4] w-full object-cover" />}
                        <div className="p-2.5 text-xs font-medium text-[#141229] dark:text-[#F5F3FF] line-clamp-2">{item.title}</div>
                      </Link>
                      <div className="px-2.5 pb-2.5">
                        <button
                          type="button"
                          onClick={() => void handleRemoveItem(item)}
                          className="inline-flex items-center gap-1 text-[11px] text-red-500 hover:underline"
                        >
                          <Trash2 className="h-3 w-3" /> Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export function NotificationsPage() {
  const { user, authReady, notifications, markNotificationRead } = useAuth();
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  if (!authReady) return <LoadingPortalLogo />;
  if (!user) return <RequireAuthPrompt title="Notifications" />;

  const list = filter === 'unread' ? notifications.filter((n) => !n.isRead) : notifications;

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title="Notifications" description="Platform updates, announcements, and creator activity." />
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[var(--aw-border)] pb-5">
        <h1 className="font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Notifications</h1>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium ${
              filter === 'all'
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border)] bg-white/85 dark:bg-[#10101F]/85 text-[#524E6B] dark:text-[#AAA7BC]'
            }`}
          >
            All ({notifications.length})
          </button>
          <button
            type="button"
            onClick={() => setFilter('unread')}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium ${
              filter === 'unread'
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border)] bg-white/85 dark:bg-[#10101F]/85 text-[#524E6B] dark:text-[#AAA7BC]'
            }`}
          >
            Unread ({notifications.filter((n) => !n.isRead).length})
          </button>
        </div>
      </div>

      {list.length === 0 ? (
        <div className="mt-8 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-8 text-center">
          <CheckCircle2 className="mx-auto h-8 w-8 text-[#0284C7] dark:text-[#43B8FF]" />
          <p className="mt-3 text-sm text-[#141229] dark:text-[#F5F3FF]">No notifications in this view.</p>
        </div>
      ) : (
        <div className="mt-6 space-y-3">
          {list.map((n) => (
            <div
              key={n.id}
              className={`flex flex-wrap items-center justify-between gap-3 rounded-xl border p-4 bg-white/90 dark:bg-[#10101F]/90 ${
                n.isRead ? 'border-[var(--aw-border)]' : 'border-[#6D38E8]/60 dark:border-[#9B5CFF]/50'
              }`}
            >
              <div>
                <div className="text-xs uppercase text-[#0284C7] dark:text-[#43B8FF]">{n.type}</div>
                <h2 className="mt-0.5 font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{n.title}</h2>
                <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">{n.message}</p>
              </div>
              {!n.isRead && (
                <button
                  type="button"
                  onClick={() => void markNotificationRead(n.id)}
                  className="rounded-lg border border-[var(--aw-border-strong)] px-3 py-1.5 text-xs text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF]"
                >
                  Mark as Read
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
