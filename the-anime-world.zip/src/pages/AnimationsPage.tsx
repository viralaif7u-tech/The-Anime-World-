import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Film, Heart, Play, Search } from 'lucide-react';
import { SeoHead } from '../components/SeoHead';
import { ProceduralMotionPlayer } from '../components/ProceduralMotionPlayer';
import { VideoDownloadControl } from '../components/VideoDownloadControl';
import { ANIMATIONS_CATALOG } from '../data/catalog';
import { useAuth } from '../context/AuthContext';

const CATEGORIES = ['ALL', 'Motion Artwork', 'Animated Wallpaper', 'Shader Loop', 'Short Cinematic', 'Authorized Trailer'];

export function AnimationsPage() {
  const [category, setCategory] = useState('ALL');
  const [search, setSearch] = useState('');

  const items = useMemo(() => {
    const q = search.trim().toLowerCase();
    return ANIMATIONS_CATALOG.filter((a) => {
      if (category !== 'ALL' && a.category !== category) return false;
      if (q && !`${a.title} ${a.creator} ${a.description}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [category, search]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <SeoHead
        title="Anime Animations & Video Gallery"
        description="Watch interactive procedural anime motion artwork, animated wallpapers, and authorized anime trailers, and download playable MP4 videos."
      />

      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[var(--aw-border)] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-[#6D38E8] dark:text-[#9B5CFF]">
            <Film className="h-4 w-4" />
            <span>Motion, MP4 Downloads &amp; Authorized Trailers</span>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Anime Animations Gallery</h1>
          <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
            Interactive real-time motion reels, authorized trailers, and real downloadable H.264 MP4 videos.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <Link
            to="/downloads"
            className="inline-flex min-h-[44px] items-center rounded-xl border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-4 py-2 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF] hover:border-[#0284C7] dark:hover:border-[#43B8FF]"
          >
            My Downloads
          </Link>
          <div className="relative flex-1 sm:w-72">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-[#524E6B] dark:text-[#AAA7BC]" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search animations..."
              aria-label="Search animations"
              className="w-full rounded-lg border border-[var(--aw-border-strong)] bg-white/92 dark:bg-[#10101F]/92 py-2.5 pr-3 pl-9 text-xs text-[#141229] dark:text-[#F5F3FF]"
            />
          </div>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-1.5">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCategory(c)}
            className={`min-h-[38px] rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap ${
              category === c
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 text-[#524E6B] dark:text-[#AAA7BC] hover:text-[#141229] dark:hover:text-[#F5F3FF]'
            }`}
          >
            {c === 'ALL' ? 'All Reels' : c}
          </button>
        ))}
      </div>

      <div className="mt-8 grid grid-cols-1 items-start gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((a) => (
          <div
            key={a.id}
            className="flex flex-col overflow-hidden rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 transition-colors hover:border-[#6D38E8]/50 dark:hover:border-[#9B5CFF]/50"
          >
            <Link to={`/animations/${a.id}`} className="group block">
              <div className="relative aspect-video overflow-hidden bg-[#080812]">
                <img
                  src={a.previewImage}
                  alt={a.title}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/35">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#9B5CFF] text-[#080812]">
                    <Play className="h-5 w-5 fill-current ml-0.5" />
                  </span>
                </div>
              </div>
            </Link>

            <div className="flex flex-col p-4 space-y-4">
              <div>
                <div className="text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">
                  {a.category} · {a.durationLabel}
                </div>
                <Link
                  to={`/animations/${a.id}`}
                  className="mt-1 block font-display text-base font-semibold text-[#141229] dark:text-[#F5F3FF] hover:text-[#0284C7] dark:hover:text-[#43B8FF]"
                >
                  {a.title}
                </Link>
                <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC] line-clamp-2">{a.description}</p>
              </div>

              <VideoDownloadControl
                videoId={a.id}
                title={a.title}
                thumbnailUrl={a.previewImage}
                compact
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AnimationDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { isFavorited, toggleFavorite } = useAuth();
  const [msg, setMsg] = useState<string | null>(null);
  const [playerSource, setPlayerSource] = useState<'interactive' | 'mp4'>('interactive');

  const item = ANIMATIONS_CATALOG.find((a) => a.id === id) || ANIMATIONS_CATALOG[0];
  const related = ANIMATIONS_CATALOG.filter((a) => a.id !== item.id).slice(0, 3);
  const fav = isFavorited('animation', item.id);

  const handleSave = async () => {
    try {
      const saved = await toggleFavorite({
        itemType: 'animation',
        itemId: item.id,
        title: item.title,
        imageUrl: item.previewImage,
        subtitle: item.category,
      });
      setMsg(saved ? 'Animation saved to favorites.' : 'Removed from favorites.');
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Sign in required.');
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8">
      <SeoHead title={item.title} description={item.description} />

      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div className="inline-flex rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-1">
          <button
            type="button"
            onClick={() => setPlayerSource('interactive')}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              playerSource === 'interactive'
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'text-[#524E6B] dark:text-[#AAA7BC]'
            }`}
          >
            Interactive Stream
          </button>
          <button
            type="button"
            onClick={() => setPlayerSource('mp4')}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors ${
              playerSource === 'mp4'
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'text-[#524E6B] dark:text-[#AAA7BC]'
            }`}
          >
            MP4 Video File Preview
          </button>
        </div>

        <Link
          to="/downloads"
          className="text-xs font-semibold text-[#0284C7] dark:text-[#43B8FF] hover:underline"
        >
          Open My Downloads →
        </Link>
      </div>

      {playerSource === 'mp4' ? (
        <div className="overflow-hidden rounded-xl border border-white/15 bg-[#080812]">
          <video
            key={item.id}
            controls
            playsInline
            preload="metadata"
            poster={item.previewImage}
            src={`/videos/${item.id}.mp4`}
            className="aspect-video w-full bg-black"
          />
        </div>
      ) : (
        <ProceduralMotionPlayer item={item} />
      )}

      <div className="mt-6 flex flex-wrap items-start justify-between gap-6">
        <div className="flex-1 min-w-[260px]">
          <h1 className="font-display text-2xl font-bold text-[#141229] dark:text-[#F5F3FF] sm:text-3xl">{item.title}</h1>
          <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">
            {item.creator} · {item.category} · {item.resolution}
          </p>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">{item.description}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => void handleSave()}
            className={`inline-flex min-h-[44px] items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-semibold ${
              fav
                ? 'bg-[#6D38E8] dark:bg-[#9B5CFF] text-white dark:text-[#080812]'
                : 'border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 text-[#141229] dark:text-[#F5F3FF]'
            }`}
          >
            <Heart className={`h-4 w-4 ${fav ? 'fill-current' : ''}`} />
            {fav ? 'Favorited' : 'Save Animation'}
          </button>
        </div>
      </div>

      <div className="mt-5 rounded-2xl border border-[var(--aw-border)] bg-white/95 dark:bg-[#10101F]/95 p-4 sm:p-5">
        <div className="mb-3 text-xs font-semibold uppercase tracking-wider text-[#0284C7] dark:text-[#43B8FF]">
          Download Playable MP4 Video (Android / Mobile / Desktop)
        </div>
        <VideoDownloadControl videoId={item.id} title={item.title} thumbnailUrl={item.previewImage} />
      </div>

      {msg && <p className="mt-2 text-xs text-[#0284C7] dark:text-[#43B8FF]">{msg}</p>}

      <section className="mt-12 border-t border-[var(--aw-border)] pt-8">
        <h2 className="font-display text-xl font-bold text-[#141229] dark:text-[#F5F3FF]">Related Animations</h2>
        <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-3">
          {related.map((r) => (
            <Link key={r.id} to={`/animations/${r.id}`} className="overflow-hidden rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 hover:border-[#6D38E8]/50 dark:hover:border-[#9B5CFF]/50">
              <img src={r.previewImage} alt={r.title} referrerPolicy="no-referrer" className="aspect-video w-full object-cover" />
              <div className="p-3">
                <div className="truncate text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{r.title}</div>
                <div className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">{r.durationLabel}</div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}

