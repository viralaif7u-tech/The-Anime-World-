import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, ChevronUp, FileCheck2, HelpCircle, Mail, MessageSquareHeart, Send, ShieldCheck, Sparkles, Star } from 'lucide-react';
import { collection, doc, getDocs, query, serverTimestamp, setDoc, where } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { SeoHead } from '../components/SeoHead';
import { BrandLogo } from '../components/BrandLogo';
import { ALLOWED_FEEDBACK_CATEGORIES, validateFeedbackInput } from '../lib/validation';
import { FAQ_ITEMS } from '../data/catalog';
import type { FeedbackRecord } from '../types/anime';

export function FeedbackPage() {
  const { user, publicProfile } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState<string>(ALLOWED_FEEDBACK_CATEGORIES[0]);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [rating, setRating] = useState(5);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<string | null>(null);
  const [history, setHistory] = useState<FeedbackRecord[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (user) {
      setName((prev) => prev || publicProfile?.displayName || user.displayName || '');
      setEmail((prev) => prev || user.email || '');
      getDocs(query(collection(db, 'feedback'), where('userId', '==', user.uid)))
        .then((snap) => setHistory(snap.docs.map((d) => d.data() as FeedbackRecord)))
        .catch(() => {});
    }
  }, [user, publicProfile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus(null);
    const check = validateFeedbackInput({ name, email, category, subject, message, rating });
    setErrors(check.errors);
    if (!check.valid) return;

    if (!user || !user.emailVerified) {
      setStatus('Please sign in with a verified account to submit tracked feedback to our Firestore moderation queue.');
      return;
    }

    setSubmitting(true);
    const feedbackId = `fb_${user.uid.slice(0, 6)}_${Date.now()}`;
    try {
      const payload: FeedbackRecord = {
        id: feedbackId,
        userId: user.uid,
        name: name.trim().slice(0, 100),
        email: email.trim().slice(0, 254),
        category: category as FeedbackRecord['category'],
        subject: subject.trim().slice(0, 160),
        message: message.trim().slice(0, 2000),
        rating,
        status: 'open',
      };
      await setDoc(doc(db, 'feedback', feedbackId), {
        ...payload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setHistory((prev) => [payload, ...prev]);
      setSubject('');
      setMessage('');
      setStatus('Thank you! Your feedback has been submitted and is visible to administrators.');
    } catch (err) {
      setStatus(err instanceof Error ? err.message : 'Unable to submit feedback.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title="Platform Feedback" description="Report bugs, request anime features, or rate your experience on THE ANIME WORLD." />

      <div className="border-b border-[var(--aw-border)] pb-6">
        <div className="flex items-center gap-2 text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">
          <MessageSquareHeart className="h-4 w-4" />
          <span>Community Feedback &amp; Feature Requests</span>
        </div>
        <h1 className="mt-1 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Feedback Center</h1>
        <p className="mt-2 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
          Share bug reports, metadata corrections, 3D viewer requests, or overall platform suggestions.
        </p>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-3">
        <form onSubmit={(e) => void handleSubmit(e)} className="lg:col-span-2 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4">
          {status && (
            <div className="rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-3.5 text-xs text-[#0284C7] dark:text-[#43B8FF]">
              {status}
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Your Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
              />
              {errors.name && <p className="mt-1 text-[11px] text-red-600 dark:text-red-400">{errors.name}</p>}
            </div>
            <div>
              <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
              />
              {errors.email && <p className="mt-1 text-[11px] text-red-600 dark:text-red-400">{errors.email}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
              >
                {ALLOWED_FEEDBACK_CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Experience Rating</label>
              <div className="flex items-center gap-2 py-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    aria-label={`Rate ${star} stars`}
                    className={star <= rating ? 'text-[#0284C7] dark:text-[#43B8FF]' : 'text-[#524E6B]/30 dark:text-white/20'}
                  >
                    <Star className="h-5 w-5 fill-current" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Subject</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Short summary of your feedback"
              className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
            />
            {errors.subject && <p className="mt-1 text-[11px] text-red-600 dark:text-red-400">{errors.subject}</p>}
          </div>

          <div>
            <label className="block text-xs font-medium text-[#524E6B] dark:text-[#AAA7BC] mb-1">Message</label>
            <textarea
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Describe your idea, bug steps, or anime request in detail..."
              className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
            />
            {errors.message && <p className="mt-1 text-[11px] text-red-600 dark:text-red-400">{errors.message}</p>}
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center gap-2 rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-3 text-sm font-semibold text-white dark:text-[#080812] hover:bg-[#5b2cd1] dark:hover:bg-[#8a46f7] disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
            {submitting ? 'Submitting...' : 'Submit Feedback'}
          </button>
        </form>

        <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4">
          <h2 className="font-display text-lg font-semibold text-[#141229] dark:text-[#F5F3FF]">Your Submissions</h2>
          {history.length === 0 ? (
            <p className="text-xs text-[#524E6B] dark:text-[#AAA7BC]">
              {user ? 'Your submitted feedback tickets will appear here with live review status.' : 'Sign in to track your feedback ticket status.'}
            </p>
          ) : (
            <div className="space-y-3">
              {history.map((fb) => (
                <div key={fb.id} className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-3.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-[#0284C7] dark:text-[#43B8FF]">{fb.category}</span>
                    <span className="uppercase text-[#524E6B] dark:text-[#AAA7BC]">{fb.status}</span>
                  </div>
                  <div className="mt-1 text-xs font-semibold text-[#141229] dark:text-[#F5F3FF]">{fb.subject}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;
    setSent(true);
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title="Contact Us" description="Get in touch with THE ANIME WORLD team for partnerships, support, or inquiries." />
      <div className="border-b border-[var(--aw-border)] pb-6">
        <div className="flex items-center gap-2 text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">
          <Mail className="h-4 w-4" />
          <span>Direct Support &amp; Partnerships</span>
        </div>
        <h1 className="mt-1 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Contact Us</h1>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-3">
        <div className="space-y-4 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 text-xs leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
          <h2 className="font-display text-base font-semibold text-[#141229] dark:text-[#F5F3FF]">Support Channels</h2>
          <p>General &amp; Creator Relations: <strong className="text-[#141229] dark:text-[#F5F3FF]">support@theanimeworld.io</strong></p>
          <p>DMCA &amp; Rights Compliance: <Link to="/copyright" className="text-[#0284C7] dark:text-[#43B8FF] underline">Copyright Portal</Link></p>
          <p>Trackable bug reports: <Link to="/feedback" className="text-[#0284C7] dark:text-[#43B8FF] underline">Feedback Center</Link></p>
        </div>

        <form onSubmit={handleSubmit} className="md:col-span-2 rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4">
          {sent ? (
            <div className="rounded-xl border border-[#0284C7]/40 dark:border-[#43B8FF]/40 bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-5 text-sm text-[#0284C7] dark:text-[#43B8FF]">
              Thank you for reaching out! Your message has been queued for our editorial &amp; support team.
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Full Name"
                  className="rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
                />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email Address"
                  className="rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
                />
              </div>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Subject"
                className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
              />
              <textarea
                rows={4}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="How can we assist you?"
                className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
              />
              <button type="submit" className="rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#080812]">
                Send Inquiry
              </button>
            </>
          )}
        </form>
      </div>
    </div>
  );
}

export function AboutPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8 space-y-8">
      <SeoHead title="About Us" description="The mission, technology stack, and anime metadata sources powering THE ANIME WORLD." />
      <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-8">
        <BrandLogo />
        <h1 className="mt-5 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">
          ENTER THE WORLD OF ANIME. EXPERIENCE THE IMPOSSIBLE.
        </h1>
        <p className="mt-4 text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
          THE ANIME WORLD is a global 3D animated anime discovery and entertainment platform designed to unite verified international anime catalogs, interactive Three.js 3D digital sculptures, 4K original artwork, and Gemini-powered natural-language intelligence.
        </p>
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-4">
            <Sparkles className="h-5 w-5 text-[#6D38E8] dark:text-[#9B5CFF]" />
            <h2 className="mt-2 font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">Global Metadata</h2>
            <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">Real-time AniList GraphQL &amp; Jikan API integration covering Japanese anime, Chinese donghua, Korean animation, movies, and classics.</p>
          </div>
          <div className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-4">
            <ShieldCheck className="h-5 w-5 text-[#0284C7] dark:text-[#43B8FF]" />
            <h2 className="mt-2 font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">3D WebGL Craft</h2>
            <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">Interactive orbital universes, physically-based 3D anime artifacts, and support for custom GLB/GLTF model inspection.</p>
          </div>
          <div className="rounded-xl border border-[var(--aw-border)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] p-4">
            <FileCheck2 className="h-5 w-5 text-[#6D38E8] dark:text-[#9B5CFF]" />
            <h2 className="mt-2 font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">Safe &amp; Grounded AI</h2>
            <p className="mt-1 text-xs text-[#524E6B] dark:text-[#AAA7BC]">Server-side Gemini recommendations strictly grounded against real database entries with SFW protection enabled.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function FaqPage() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <SeoHead title="Frequently Asked Questions" description="Answers about THE ANIME WORLD database, 3D viewer, Gemini AI, and accounts." />
      <div className="border-b border-[var(--aw-border)] pb-6">
        <div className="flex items-center gap-2 text-xs font-medium text-[#0284C7] dark:text-[#43B8FF]">
          <HelpCircle className="h-4 w-4" />
          <span>Knowledge Base</span>
        </div>
        <h1 className="mt-1 font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Frequently Asked Questions</h1>
      </div>

      <div className="mt-6 space-y-3">
        {FAQ_ITEMS.map((item, idx) => {
          const open = openIdx === idx;
          return (
            <div key={item.q} className="rounded-xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 overflow-hidden">
              <button
                type="button"
                onClick={() => setOpenIdx(open ? null : idx)}
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
              >
                <span className="font-display text-sm font-semibold text-[#141229] dark:text-[#F5F3FF]">{item.q}</span>
                {open ? <ChevronUp className="h-4 w-4 text-[#0284C7] dark:text-[#43B8FF] shrink-0" /> : <ChevronDown className="h-4 w-4 text-[#524E6B] dark:text-[#AAA7BC] shrink-0" />}
              </button>
              {open && (
                <div className="border-t border-[var(--aw-border)] px-5 py-4 text-xs leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
                  {item.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function PrivacyPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8 space-y-5">
      <SeoHead title="Privacy Policy" description="Privacy practices and PII isolation standards on THE ANIME WORLD." />
      <h1 className="font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Privacy Policy</h1>
      <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4 text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
        <p>THE ANIME WORLD separates private account information (email address, full name, and AI genre preferences) from public creator profiles inside Cloud Firestore with strict access rules.</p>
        <p>We never store plaintext passwords, never sell personal data, and never expose your private email or collections to public users unless you explicitly mark a collection as Public.</p>
        <p>You can update your profile visibility or delete collections anytime from your User Dashboard.</p>
      </div>
    </div>
  );
}

export function TermsPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8 space-y-5">
      <SeoHead title="Terms & Conditions" description="Platform rules and user responsibilities on THE ANIME WORLD." />
      <h1 className="font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Terms &amp; Conditions</h1>
      <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4 text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
        <p>By accessing THE ANIME WORLD, you agree to upload and share only SFW artwork, 3D models, and commentary that you own or have permission to distribute.</p>
        <p>Anime metadata is provided via the AniList GraphQL API and Jikan API for discovery and informational purposes; all trademarks belong to their respective studios and rights holders.</p>
        <p>Administrators reserve the right to flag or remove content that violates community safety or copyright policies.</p>
      </div>
    </div>
  );
}

export function CopyrightPage() {
  const { user } = useAuth();
  const [targetId, setTargetId] = useState('');
  const [reason, setReason] = useState('');
  const [msg, setMsg] = useState<string | null>(null);

  const handleDmca = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    if (!user || !user.emailVerified) {
      setMsg('Please sign in with a verified account to log a DMCA takedown request directly in our moderation queue, or email legal@theanimeworld.io.');
      return;
    }
    const cleanTarget = targetId.trim().replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 128) || 'general_dmca_notice';
    const reportId = `dmca_${user.uid.slice(0, 6)}_${Date.now()}`;
    try {
      await setDoc(doc(db, 'reports', reportId), {
        id: reportId,
        reporterId: user.uid,
        targetId: cleanTarget,
        targetType: 'artwork',
        reason: `DMCA Notice: ${reason.trim()}`.slice(0, 600),
        status: 'pending',
        createdAt: serverTimestamp(),
      });
      setTargetId('');
      setReason('');
      setMsg('DMCA takedown notice logged in our priority moderation queue.');
    } catch (err) {
      setMsg(err instanceof Error ? err.message : 'Unable to submit DMCA notice.');
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8 space-y-6">
      <SeoHead title="Copyright Policy & DMCA" description="Content attribution and DMCA takedown request process." />
      <h1 className="font-display text-3xl font-bold text-[#141229] dark:text-[#F5F3FF]">Copyright Policy &amp; DMCA</h1>
      <div className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4 text-sm leading-relaxed text-[#524E6B] dark:text-[#AAA7BC]">
        <p>THE ANIME WORLD respects intellectual property rights. External anime metadata is fetched dynamically via AniList and Jikan APIs, trailers use official authorized embeds, and bundled wallpapers/3D sculptures are original platform creations.</p>
        <p>If you believe any community upload infringes your copyright, submit a notice below or contact <strong className="text-[#141229] dark:text-[#F5F3FF]">legal@theanimeworld.io</strong>.</p>
      </div>

      <form onSubmit={(e) => void handleDmca(e)} className="rounded-2xl border border-[var(--aw-border)] bg-white/90 dark:bg-[#10101F]/90 p-6 space-y-4">
        <h2 className="font-display text-lg font-semibold text-[#141229] dark:text-[#F5F3FF]">Submit DMCA Takedown Request</h2>
        {msg && <p className="text-xs text-[#0284C7] dark:text-[#43B8FF]">{msg}</p>}
        <input
          type="text"
          required
          value={targetId}
          onChange={(e) => setTargetId(e.target.value)}
          placeholder="Content / Artwork ID or Title Reference"
          className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
        />
        <textarea
          rows={4}
          required
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Identify the copyrighted work and provide authorization statement..."
          className="w-full rounded-xl border border-[var(--aw-border-strong)] bg-[var(--aw-surface-elevated)] dark:bg-[#080812] px-3.5 py-2.5 text-sm text-[#141229] dark:text-[#F5F3FF]"
        />
        <button type="submit" className="rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-xs font-semibold text-white dark:text-[#080812]">
          Submit DMCA Notice
        </button>
      </form>
    </div>
  );
}

export function NotFoundPage() {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-2xl flex-col items-center justify-center px-4 py-16 text-center">
      <SeoHead title="404 — Portal Not Found" description="The requested dimension could not be found." />
      <p className="font-mono-tabular text-sm font-semibold text-[#0284C7] dark:text-[#43B8FF]">404 · DIMENSIONAL RIFT</p>
      <h1 className="mt-2 font-display text-4xl font-extrabold text-[#141229] dark:text-[#F5F3FF]">World Coordinates Not Found</h1>
      <p className="mt-3 text-sm text-[#524E6B] dark:text-[#AAA7BC]">
        The route you requested does not exist in this universe. Return to the main hub or explore the live anime database.
      </p>
      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <Link to="/" className="rounded-xl bg-[#6D38E8] dark:bg-[#9B5CFF] px-5 py-2.5 text-sm font-semibold text-white dark:text-[#080812]">
          Return Home
        </Link>
        <Link to="/explore" className="rounded-xl border border-[var(--aw-border-strong)] bg-white/90 dark:bg-[#10101F]/90 px-5 py-2.5 text-sm font-medium text-[#141229] dark:text-[#F5F3FF]">
          Explore Anime
        </Link>
      </div>
    </div>
  );
}
