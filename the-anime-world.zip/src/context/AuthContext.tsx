import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  browserLocalPersistence,
  browserSessionPersistence,
  createUserWithEmailAndPassword,
  EmailAuthProvider,
  GoogleAuthProvider,
  isSignInWithEmailLink,
  onAuthStateChanged,
  reauthenticateWithCredential,
  sendEmailVerification,
  sendPasswordResetEmail,
  sendSignInLinkToEmail,
  setPersistence,
  signInWithEmailAndPassword,
  signInWithEmailLink,
  signInWithPopup,
  signOut,
  updatePassword,
  updateProfile,
  type AuthProvider as FirebaseAuthProvider,
  type User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  appleProvider,
  auth,
  db,
  deleteUserCollection,
  facebookProvider,
  githubProvider,
  googleProvider,
  googleWorkspaceProvider,
  handleFirestoreError,
  logFirestoreError,
  microsoftProvider,
  OperationType,
  removeItemFromCollection,
  saveItemToCollection,
  saveUserCollection,
  toggleUserFavorite,
  type ServiceResult,
} from '../services/firebase';
import {
  clearWorkspaceAccessToken,
  getWorkspaceAccessToken,
  setWorkspaceAccessToken,
  subscribeWorkspaceToken,
} from '../services/googleWorkspace';
import type {
  CollectionRecord,
  FavoriteRecord,
  ItemType,
  NotificationRecord,
  PrivateUser,
  PublicProfile,
} from '../types/anime';
import { isValidAvatarUrl, isValidUsername, sanitizeSlug } from '../lib/validation';
import { useTheme, type ThemeMode } from './ThemeContext';

export type OAuthProviderKey = 'google' | 'facebook' | 'apple' | 'microsoft' | 'github';

const EMAIL_LINK_STORAGE_KEY = 'aw_email_for_signin';

export interface FeedbackToastState {
  id: number;
  kind: 'success' | 'error';
  message: string;
}

interface AuthContextValue {
  user: User | null;
  authReady: boolean;
  publicProfile: PublicProfile | null;
  privateUser: PrivateUser | null;
  isAdmin: boolean;
  favorites: FavoriteRecord[];
  collections: CollectionRecord[];
  notifications: NotificationRecord[];
  unreadCount: number;
  feedbackToast: FeedbackToastState | null;
  showFeedback: (kind: 'success' | 'error', message: string) => void;
  dismissFeedbackToast: () => void;
  workspaceAccessToken: string | null;
  needsWorkspaceAuth: boolean;
  connectGoogleWorkspace: () => Promise<string | null>;
  disconnectGoogleWorkspace: () => void;
  signInWithGoogle: () => Promise<void>;
  signInWithOAuthProvider: (provider: OAuthProviderKey) => Promise<void>;
  sendEmailSignInLink: (email: string) => Promise<void>;
  completeEmailLinkSignIn: (emailOverride?: string) => Promise<boolean>;
  hasPendingEmailLink: () => boolean;
  loginWithEmail: (email: string, password: string, rememberMe: boolean) => Promise<void>;
  registerWithEmail: (params: {
    fullName: string;
    username: string;
    email: string;
    password: string;
    avatarUrl?: string;
  }) => Promise<void>;
  logout: () => Promise<void>;
  requestPasswordReset: (email: string) => Promise<void>;
  resendVerification: () => Promise<void>;
  changeUserPassword: (currentPassword: string, newPassword: string) => Promise<void>;
  isFavorited: (itemType: ItemType, itemId: string) => boolean;
  toggleFavorite: (item: {
    itemType: ItemType;
    itemId: string;
    title: string;
    imageUrl?: string;
    subtitle?: string;
  }) => Promise<boolean>;
  createCollection: (name: string, description: string, isPublic: boolean) => Promise<string>;
  updateCollection: (
    collectionId: string,
    updates: { name: string; description?: string; isPublic: boolean; coverImage?: string }
  ) => Promise<ServiceResult<{ collectionId: string }>>;
  deleteCollectionById: (
    collectionId: string,
    name?: string
  ) => Promise<ServiceResult<{ collectionId: string }>>;
  addToCollection: (
    collectionId: string,
    item: { itemType: ItemType; itemId: string; title: string; imageUrl?: string }
  ) => Promise<void>;
  removeCollectionItem: (
    collectionId: string,
    itemDocId: string,
    currentItemsCount: number,
    title?: string
  ) => Promise<ServiceResult<{ collectionId: string; itemDocId: string }>>;
  updateUserProfile: (
    updates: Partial<Pick<PublicProfile, 'displayName' | 'username' | 'bio' | 'avatarUrl' | 'coverUrl' | 'isPublic'>> & {
      fullName?: string;
    }
  ) => Promise<void>;
  updateFavoriteGenres: (genres: string[]) => Promise<void>;
  saveThemePreference: (nextTheme: ThemeMode) => Promise<void>;
  markNotificationRead: (notificationId: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const BOOTSTRAPPED_ADMIN_EMAIL = 'mohdwaleed868@gmail.com';

function getProviderInstance(key: OAuthProviderKey): FirebaseAuthProvider {
  switch (key) {
    case 'facebook':
      return facebookProvider;
    case 'apple':
      return appleProvider;
    case 'microsoft':
      return microsoftProvider;
    case 'github':
      return githubProvider;
    case 'google':
    default:
      return googleProvider;
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { theme, setTheme } = useTheme();
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [publicProfile, setPublicProfile] = useState<PublicProfile | null>(null);
  const [privateUser, setPrivateUser] = useState<PrivateUser | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [favorites, setFavorites] = useState<FavoriteRecord[]>([]);
  const [collections, setCollections] = useState<CollectionRecord[]>([]);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [feedbackToast, setFeedbackToast] = useState<FeedbackToastState | null>(null);
  const [workspaceAccessToken, setWorkspaceAccessTokenState] = useState<string | null>(() => getWorkspaceAccessToken());

  useEffect(() => {
    return subscribeWorkspaceToken((token) => {
      setWorkspaceAccessTokenState(token);
    });
  }, []);

  const dismissFeedbackToast = useCallback(() => {
    setFeedbackToast(null);
  }, []);

  const showFeedback = useCallback((kind: 'success' | 'error', message: string) => {
    const id = Date.now();
    setFeedbackToast({ id, kind, message });
    if (typeof window !== 'undefined') {
      window.setTimeout(() => {
        setFeedbackToast((prev) => (prev && prev.id === id ? null : prev));
      }, 3600);
    }
  }, []);

  const isTransientOfflineError = (err: unknown): boolean => {
    const code = (err as { code?: string })?.code;
    const msg = err instanceof Error ? err.message.toLowerCase() : String(err).toLowerCase();
    return (
      code === 'unavailable' ||
      msg.includes('client is offline') ||
      msg.includes('failed to get document because the client is offline')
    );
  };

  const ensureUserProfiles = useCallback(
    async (firebaseUser: User, customUsername?: string, customFullName?: string, customAvatar?: string) => {
      if (!firebaseUser.emailVerified) return;

      const uid = firebaseUser.uid;
      const pubRef = doc(db, 'publicProfiles', uid);
      const privRef = doc(db, 'privateUsers', uid);

      const syncProfileDoc = async () => {
        const pubSnap = await getDoc(pubRef);
        if (!pubSnap.exists()) {
          const baseHandle = customUsername || sanitizeSlug(firebaseUser.email?.split('@')[0] || `traveler_${uid.slice(0, 6)}`);
          const safeUsername = isValidUsername(baseHandle) ? baseHandle : `user_${uid.slice(0, 8)}`;
          const initialAvatar = customAvatar || firebaseUser.photoURL || '';
          const safeAvatar = isValidAvatarUrl(initialAvatar) ? initialAvatar : '';

          await setDoc(pubRef, {
            uid,
            username: safeUsername,
            displayName: firebaseUser.displayName || customFullName || safeUsername,
            bio: 'Exploring worlds on THE ANIME WORLD.',
            avatarUrl: safeAvatar,
            coverUrl: '',
            isPublic: true,
            role: 'user',
            isSuspended: false,
            followersCount: 0,
            followingCount: 0,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      };

      try {
        await syncProfileDoc();
      } catch (err) {
        if (isTransientOfflineError(err)) {
          await new Promise((resolve) => setTimeout(resolve, 1500));
          try {
            await syncProfileDoc();
          } catch (retryErr) {
            if (isTransientOfflineError(retryErr)) {
              logFirestoreError(retryErr, OperationType.WRITE, `publicProfiles/${uid}`);
            } else {
              handleFirestoreError(retryErr, OperationType.WRITE, `publicProfiles/${uid}`);
            }
          }
        } else {
          handleFirestoreError(err, OperationType.WRITE, `publicProfiles/${uid}`);
        }
      }

      const syncPrivateDoc = async () => {
        const privSnap = await getDoc(privRef);
        if (!privSnap.exists()) {
          await setDoc(privRef, {
            uid,
            email: firebaseUser.email || '',
            fullName: customFullName || firebaseUser.displayName || 'Anime Explorer',
            favoriteGenres: [],
            newsletterOptIn: false,
            themePreference: theme,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      };

      try {
        await syncPrivateDoc();
      } catch (err) {
        if (isTransientOfflineError(err)) {
          await new Promise((resolve) => setTimeout(resolve, 1500));
          try {
            await syncPrivateDoc();
          } catch (retryErr) {
            if (isTransientOfflineError(retryErr)) {
              logFirestoreError(retryErr, OperationType.WRITE, `privateUsers/${uid}`);
            } else {
              handleFirestoreError(retryErr, OperationType.WRITE, `privateUsers/${uid}`);
            }
          }
        } else {
          handleFirestoreError(err, OperationType.WRITE, `privateUsers/${uid}`);
        }
      }
    },
    [theme]
  );

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);

      if (!nextUser) {
        clearWorkspaceAccessToken();
        setPublicProfile(null);
        setPrivateUser(null);
        setIsAdmin(false);
        setFavorites([]);
        setCollections([]);
        setNotifications([]);
        return;
      }

      const bootstrappedAdmin =
        Boolean(nextUser.emailVerified) &&
        nextUser.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL;

      if (bootstrappedAdmin) {
        setIsAdmin(true);
      } else {
        try {
          const adminDoc = await getDoc(doc(db, 'admins', nextUser.uid));
          setIsAdmin(adminDoc.exists() && nextUser.emailVerified);
        } catch {
          setIsAdmin(false);
        }
      }

      if (nextUser.emailVerified) {
        void ensureUserProfiles(nextUser).catch((err) => {
          console.warn('Deferred profile sync error:', err instanceof Error ? err.message : String(err));
        });
      }
    });
    return () => unsub();
  }, [ensureUserProfiles]);

  useEffect(() => {
    if (!authReady || !user) return;

    const uid = user.uid;
    const unsubs: Array<() => void> = [];

    unsubs.push(
      onSnapshot(
        doc(db, 'publicProfiles', uid),
        (snap) => {
          if (snap.exists()) {
            const data = snap.data() as PublicProfile;
            setPublicProfile(data);
            if (data.role === 'admin' && user.emailVerified) {
              setIsAdmin(true);
            }
          }
        },
        (err) => {
          console.warn('Public profile listener error:', err.message);
        }
      )
    );

    unsubs.push(
      onSnapshot(
        doc(db, 'privateUsers', uid),
        (snap) => {
          if (snap.exists()) {
            const priv = snap.data() as PrivateUser;
            setPrivateUser(priv);
            if (priv.themePreference === 'dark' || priv.themePreference === 'light') {
              setTheme(priv.themePreference);
            }
          }
        },
        (err) => {
          console.warn('Private user listener error:', err.message);
        }
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'favorites'), where('userId', '==', uid)),
        (snap) => {
          setFavorites(snap.docs.map((d) => d.data() as FavoriteRecord));
        },
        (err) => {
          console.warn('Favorites listener error:', err.message);
        }
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'collections'), where('userId', '==', uid)),
        (snap) => {
          setCollections(snap.docs.map((d) => d.data() as CollectionRecord));
        },
        (err) => {
          console.warn('Collections listener error:', err.message);
        }
      )
    );

    unsubs.push(
      onSnapshot(
        query(collection(db, 'notifications'), where('userId', '==', uid), orderBy('createdAt', 'desc')),
        (snap) => {
          setNotifications(snap.docs.map((d) => d.data() as NotificationRecord));
        },
        () => {
          const unsubFallback = onSnapshot(
            query(collection(db, 'notifications'), where('userId', '==', uid)),
            (snap) => setNotifications(snap.docs.map((d) => d.data() as NotificationRecord)),
            () => {}
          );
          unsubs.push(unsubFallback);
        }
      )
    );

    return () => {
      unsubs.forEach((u) => u());
    };
  }, [authReady, user, setTheme]);

  const signInWithOAuthProvider = useCallback(
    async (providerKey: OAuthProviderKey) => {
      const provider = getProviderInstance(providerKey);
      const cred = await signInWithPopup(auth, provider);
      if (providerKey === 'google') {
        const oauthCred = GoogleAuthProvider.credentialFromResult(cred);
        if (oauthCred?.accessToken) {
          setWorkspaceAccessToken(oauthCred.accessToken, cred.user.email);
        }
      }
      await ensureUserProfiles(cred.user);
    },
    [ensureUserProfiles]
  );

  const connectGoogleWorkspace = useCallback(async (): Promise<string | null> => {
    const cred = await signInWithPopup(auth, googleWorkspaceProvider);
    const oauthCred = GoogleAuthProvider.credentialFromResult(cred);
    if (!oauthCred?.accessToken) {
      throw new Error('Google did not return an OAuth access token. Please allow Gmail and Google Drive permissions.');
    }
    setWorkspaceAccessToken(oauthCred.accessToken, cred.user.email);
    await ensureUserProfiles(cred.user);
    return oauthCred.accessToken;
  }, [ensureUserProfiles]);

  const disconnectGoogleWorkspace = useCallback(() => {
    clearWorkspaceAccessToken();
  }, []);

  const signInWithGoogle = useCallback(async () => {
    await signInWithOAuthProvider('google');
  }, [signInWithOAuthProvider]);

  const sendEmailSignInLink = useCallback(async (email: string) => {
    const clean = email.trim();
    const actionCodeSettings = {
      url: `${window.location.origin}/login?emailLink=1`,
      handleCodeInApp: true,
    };
    await sendSignInLinkToEmail(auth, clean, actionCodeSettings);
    window.localStorage.setItem(EMAIL_LINK_STORAGE_KEY, clean);
  }, []);

  const hasPendingEmailLink = useCallback(() => {
    if (typeof window === 'undefined') return false;
    return isSignInWithEmailLink(auth, window.location.href);
  }, []);

  const completeEmailLinkSignIn = useCallback(
    async (emailOverride?: string) => {
      if (typeof window === 'undefined' || !isSignInWithEmailLink(auth, window.location.href)) {
        return false;
      }
      const storedEmail = window.localStorage.getItem(EMAIL_LINK_STORAGE_KEY) || '';
      const targetEmail = (emailOverride || storedEmail).trim();
      if (!targetEmail) {
        throw new Error('Please enter the email address where you received the sign-in link.');
      }
      const cred = await signInWithEmailLink(auth, targetEmail, window.location.href);
      window.localStorage.removeItem(EMAIL_LINK_STORAGE_KEY);
      await ensureUserProfiles(cred.user);
      return true;
    },
    [ensureUserProfiles]
  );

  const loginWithEmail = useCallback(
    async (email: string, password: string, rememberMe: boolean) => {
      await setPersistence(auth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
      const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
      if (cred.user.emailVerified) {
        await ensureUserProfiles(cred.user);
      }
    },
    [ensureUserProfiles]
  );

  const registerWithEmail = useCallback(
    async (params: {
      fullName: string;
      username: string;
      email: string;
      password: string;
      avatarUrl?: string;
    }) => {
      const cred = await createUserWithEmailAndPassword(auth, params.email.trim(), params.password);
      const safePhoto =
        params.avatarUrl && !params.avatarUrl.startsWith('data:') ? params.avatarUrl.trim() : undefined;
      await updateProfile(cred.user, {
        displayName: params.fullName.trim(),
        photoURL: safePhoto,
      });
      await sendEmailVerification(cred.user);
      if (cred.user.emailVerified) {
        await ensureUserProfiles(cred.user, params.username.trim(), params.fullName.trim(), params.avatarUrl);
      }
    },
    [ensureUserProfiles]
  );

  const logout = useCallback(async () => {
    clearWorkspaceAccessToken();
    await signOut(auth);
  }, []);

  const requestPasswordReset = useCallback(async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  }, []);

  const resendVerification = useCallback(async () => {
    if (auth.currentUser) {
      await sendEmailVerification(auth.currentUser);
    }
  }, []);

  const changeUserPassword = useCallback(async (currentPassword: string, newPassword: string) => {
    const currentUser = auth.currentUser;
    if (!currentUser || !currentUser.email) {
      throw new Error('You must be signed in to change your password.');
    }
    const hasPasswordProvider = currentUser.providerData.some((p) => p.providerId === 'password');
    if (!hasPasswordProvider) {
      throw new Error(
        'This account signs in through a federated provider (Google/Facebook/Apple/Microsoft/GitHub). Manage your password directly through your identity provider.'
      );
    }
    const credential = EmailAuthProvider.credential(currentUser.email, currentPassword);
    await reauthenticateWithCredential(currentUser, credential);
    await updatePassword(currentUser, newPassword);
  }, []);

  const isFavorited = useCallback(
    (itemType: ItemType, itemId: string) =>
      favorites.some((f) => f.itemType === itemType && f.itemId === String(itemId)),
    [favorites]
  );

  const toggleFavorite = useCallback(
    async (item: {
      itemType: ItemType;
      itemId: string;
      title: string;
      imageUrl?: string;
      subtitle?: string;
    }) => {
      const knownExists = user
        ? favorites.some((f) => f.itemType === item.itemType && f.itemId === String(item.itemId))
        : false;
      const result = await toggleUserFavorite(item, user ? knownExists : undefined, user?.uid);
      if (!result.ok) {
        showFeedback('error', result.message);
        throw new Error(result.message);
      }
      showFeedback('success', result.message);
      return result.data.saved;
    },
    [favorites, showFeedback, user]
  );

  const createCollection = useCallback(
    async (name: string, description: string, isPublic: boolean) => {
      const result = await saveUserCollection({ name, description, isPublic }, user?.uid);
      if (!result.ok) {
        showFeedback('error', result.message);
        throw new Error(result.message);
      }
      showFeedback('success', result.message);
      return result.data.collectionId;
    },
    [showFeedback, user]
  );

  const updateCollection = useCallback(
    async (
      collectionId: string,
      updates: { name: string; description?: string; isPublic: boolean; coverImage?: string }
    ) => {
      const result = await saveUserCollection({ collectionId, ...updates }, user?.uid);
      showFeedback(result.ok ? 'success' : 'error', result.message);
      return result;
    },
    [showFeedback, user]
  );

  const deleteCollectionById = useCallback(
    async (collectionId: string, name?: string) => {
      const result = await deleteUserCollection(collectionId, name);
      showFeedback(result.ok ? 'success' : 'error', result.message);
      return result;
    },
    [showFeedback]
  );

  const addToCollection = useCallback(
    async (
      collectionId: string,
      item: { itemType: ItemType; itemId: string; title: string; imageUrl?: string }
    ) => {
      const targetCol = collections.find((c) => c.id === collectionId);
      const result = await saveItemToCollection(collectionId, item, targetCol, user?.uid);
      if (!result.ok) {
        showFeedback('error', result.message);
        throw new Error(result.message);
      }
      showFeedback('success', result.message);
    },
    [collections, showFeedback, user]
  );

  const removeCollectionItem = useCallback(
    async (collectionId: string, itemDocId: string, currentItemsCount: number, title?: string) => {
      const result = await removeItemFromCollection(collectionId, itemDocId, currentItemsCount, title);
      showFeedback(result.ok ? 'success' : 'error', result.message);
      return result;
    },
    [showFeedback]
  );

  const updateUserProfile = useCallback(
    async (
      updates: Partial<Pick<PublicProfile, 'displayName' | 'username' | 'bio' | 'avatarUrl' | 'coverUrl' | 'isPublic'>> & {
        fullName?: string;
      }
    ) => {
      if (!user || !user.emailVerified) throw new Error('Verified sign-in required.');

      const { fullName, ...pubUpdates } = updates;
      if (pubUpdates.username !== undefined && !isValidUsername(pubUpdates.username)) {
        throw new Error('Username must be 2–40 characters using only letters, numbers, underscores, or hyphens.');
      }
      if (pubUpdates.avatarUrl !== undefined && !isValidAvatarUrl(pubUpdates.avatarUrl)) {
        throw new Error('Avatar must be a valid HTTPS URL or uploaded image under 25 KB.');
      }

      if (auth.currentUser && (pubUpdates.displayName || (pubUpdates.avatarUrl && !pubUpdates.avatarUrl.startsWith('data:')))) {
        await updateProfile(auth.currentUser, {
          displayName: pubUpdates.displayName ?? auth.currentUser.displayName,
          photoURL:
            pubUpdates.avatarUrl && !pubUpdates.avatarUrl.startsWith('data:')
              ? pubUpdates.avatarUrl
              : auth.currentUser.photoURL,
        });
      }

      if (Object.keys(pubUpdates).length > 0) {
        try {
          await updateDoc(doc(db, 'publicProfiles', user.uid), {
            ...pubUpdates,
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, `publicProfiles/${user.uid}`);
        }
      }

      if (fullName !== undefined && fullName.trim().length > 0) {
        try {
          await updateDoc(doc(db, 'privateUsers', user.uid), {
            fullName: fullName.trim().slice(0, 120),
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, `privateUsers/${user.uid}`);
        }
      }
    },
    [user]
  );

  const updateFavoriteGenres = useCallback(
    async (genres: string[]) => {
      if (!user || !user.emailVerified) throw new Error('Verified sign-in required.');
      try {
        await updateDoc(doc(db, 'privateUsers', user.uid), {
          favoriteGenres: genres.slice(0, 15),
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `privateUsers/${user.uid}`);
      }
    },
    [user]
  );

  const saveThemePreference = useCallback(
    async (nextTheme: ThemeMode) => {
      setTheme(nextTheme);
      if (user && user.emailVerified) {
        try {
          await updateDoc(doc(db, 'privateUsers', user.uid), {
            themePreference: nextTheme,
            updatedAt: serverTimestamp(),
          });
        } catch {
          // Non-fatal if privateUsers doc isn't created yet
        }
      }
    },
    [setTheme, user]
  );

  const markNotificationRead = useCallback(
    async (notificationId: string) => {
      if (!user || !user.emailVerified) return;
      try {
        await updateDoc(doc(db, 'notifications', notificationId), {
          isRead: true,
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `notifications/${notificationId}`);
      }
    },
    [user]
  );

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <AuthContext.Provider
      value={{
        user,
        authReady,
        publicProfile,
        privateUser,
        isAdmin,
        favorites,
        collections,
        notifications,
        unreadCount,
        feedbackToast,
        showFeedback,
        dismissFeedbackToast,
        workspaceAccessToken,
        needsWorkspaceAuth: !workspaceAccessToken,
        connectGoogleWorkspace,
        disconnectGoogleWorkspace,
        signInWithGoogle,
        signInWithOAuthProvider,
        sendEmailSignInLink,
        completeEmailLinkSignIn,
        hasPendingEmailLink,
        loginWithEmail,
        registerWithEmail,
        logout,
        requestPasswordReset,
        resendVerification,
        changeUserPassword,
        isFavorited,
        toggleFavorite,
        createCollection,
        updateCollection,
        deleteCollectionById,
        addToCollection,
        removeCollectionItem,
        updateUserProfile,
        updateFavoriteGenres,
        saveThemePreference,
        markNotificationRead,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
