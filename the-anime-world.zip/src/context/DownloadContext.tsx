import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { useAuth } from './AuthContext';
import {
  clearUserDownloadHistory,
  createDownloadHistoryEntry,
  db,
  deleteDownloadHistoryEntry,
  updateDownloadHistoryEntry,
} from '../services/firebase';
import {
  buildSafeMp4Filename,
  calculateDownloadProgress,
  detectDeviceDownloadGuidance,
  isValidMp4Buffer,
} from '../services/videoDownloadHelpers';
import type { DownloadRecord, DownloadStatus } from '../types/anime';

export interface ActiveDownloadState {
  videoId: string;
  downloadDocId: string;
  title: string;
  thumbnailUrl?: string;
  filename: string;
  status: DownloadStatus;
  progressPct: number;
  downloadedBytes: number;
  totalBytes: number;
  saveLocation: string;
  guidanceText: string;
  errorMessage?: string;
  completedBlob?: Blob;
  canShareFile: boolean;
  canPickFolder: boolean;
}

interface StartDownloadOptions {
  videoId: string;
  title: string;
  thumbnailUrl?: string;
  useFolderPicker?: boolean;
  sourceUrlOverride?: string;
}

interface DownloadContextValue {
  activeDownloads: Record<string, ActiveDownloadState>;
  savedDownloads: DownloadRecord[];
  downloadsLoading: boolean;
  startVideoDownload: (opts: StartDownloadOptions) => Promise<void>;
  retryVideoDownload: (videoId: string, title: string, thumbnailUrl?: string) => Promise<void>;
  shareDownloadedVideo: (videoId: string) => Promise<void>;
  removeSavedDownload: (downloadId: string) => Promise<void>;
  clearAllSavedDownloads: () => Promise<void>;
}

const DownloadContext = createContext<DownloadContextValue | null>(null);

interface FileSystemWritable {
  write: (data: Blob) => Promise<void>;
  close: () => Promise<void>;
}

interface FileSystemHandleLike {
  createWritable: () => Promise<FileSystemWritable>;
}

type WindowWithFs = Window & {
  showSaveFilePicker?: (options: {
    suggestedName: string;
    types: Array<{ description: string; accept: Record<string, string[]> }>;
  }) => Promise<FileSystemHandleLike>;
};

export function DownloadProvider({ children }: { children: React.ReactNode }) {
  const { user, authReady, privateUser, showFeedback } = useAuth();
  const [activeDownloads, setActiveDownloads] = useState<Record<string, ActiveDownloadState>>({});
  const [savedDownloads, setSavedDownloads] = useState<DownloadRecord[]>([]);
  const [downloadsLoading, setDownloadsLoading] = useState(false);

  // Ref guard prevents duplicate simultaneous downloads even under rapid multi-clicks
  const inFlightSetRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!authReady) return;
    if (!user) {
      setSavedDownloads([]);
      setDownloadsLoading(false);
      return;
    }

    setDownloadsLoading(true);
    const q = query(collection(db, 'downloads'), where('userId', '==', user.uid));
    const unsub = onSnapshot(
      q,
      (snap) => {
        const list = snap.docs
          .map((d) => d.data() as DownloadRecord)
          .sort((a, b) => {
            const getMs = (val: unknown) => {
              if (!val || typeof val !== 'object') return 0;
              const ts = val as { toMillis?: () => number; seconds?: number };
              if (typeof ts.toMillis === 'function') return ts.toMillis();
              if (typeof ts.seconds === 'number') return ts.seconds * 1000;
              return 0;
            };
            return getMs(b.updatedAt || b.createdAt) - getMs(a.updatedAt || a.createdAt);
          });
        setSavedDownloads(list);
        setDownloadsLoading(false);
      },
      () => {
        setDownloadsLoading(false);
      }
    );

    return () => unsub();
  }, [authReady, user]);

  const startVideoDownload = useCallback(
    async (opts: StartDownloadOptions) => {
      const { videoId, title, thumbnailUrl, useFolderPicker, sourceUrlOverride } = opts;
      if (inFlightSetRef.current.has(videoId)) {
        showFeedback('error', `"${title}" is already downloading.`);
        return;
      }

      inFlightSetRef.current.add(videoId);

      const safeFilename = buildSafeMp4Filename(title, videoId);
      const hasFileSystemPicker =
        typeof window !== 'undefined' && typeof (window as WindowWithFs).showSaveFilePicker === 'function';
      const hasFileShare =
        typeof navigator !== 'undefined' && typeof navigator.canShare === 'function' && typeof navigator.share === 'function';
      const guidance = detectDeviceDownloadGuidance({
        userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
        hasFileSystemPicker,
        hasFileShare,
      });

      const downloadDocId = `dl_${Date.now()}_${videoId.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 32)}`;
      const shouldPersistHistory = Boolean(
        user && user.emailVerified && privateUser?.saveDownloadHistory !== false
      );

      let pickedHandle: FileSystemHandleLike | null = null;
      if (useFolderPicker && hasFileSystemPicker) {
        try {
          pickedHandle = await (window as WindowWithFs).showSaveFilePicker!({
            suggestedName: safeFilename,
            types: [{ description: 'MP4 Video', accept: { 'video/mp4': ['.mp4'] } }],
          });
        } catch (pickerErr) {
          if (pickerErr instanceof Error && pickerErr.name === 'AbortError') {
            inFlightSetRef.current.delete(videoId);
            return;
          }
          pickedHandle = null;
        }
      }

      setActiveDownloads((prev) => ({
        ...prev,
        [videoId]: {
          videoId,
          downloadDocId,
          title,
          thumbnailUrl,
          filename: safeFilename,
          status: 'downloading',
          progressPct: 0,
          downloadedBytes: 0,
          totalBytes: 0,
          saveLocation: pickedHandle ? 'Selected Device Folder' : guidance.targetFolderLabel,
          guidanceText: guidance.explanation,
          canShareFile: false,
          canPickFolder: hasFileSystemPicker,
        },
      }));

      if (shouldPersistHistory) {
        void createDownloadHistoryEntry({
          downloadId: downloadDocId,
          videoId,
          title,
          thumbnailUrl,
          fileSizeBytes: 0,
          saveLocation: pickedHandle ? 'Selected Device Folder' : guidance.targetFolderLabel,
        });
      }

      try {
        const targetUrl = sourceUrlOverride || `/api/videos/${encodeURIComponent(videoId)}/download`;
        const response = await fetch(targetUrl, { method: 'GET', cache: 'no-store' });

        if (!response.ok) {
          let errText = `Server returned HTTP ${response.status}`;
          try {
            const ct = response.headers.get('content-type') || '';
            if (ct.includes('application/json')) {
              const json = (await response.json()) as { error?: string };
              if (json.error) errText = json.error;
            }
          } catch {
            // Keep default message
          }
          throw new Error(errText);
        }

        const contentType = (response.headers.get('content-type') || '').toLowerCase();
        if (contentType.includes('text/html') || contentType.includes('application/json')) {
          throw new Error('Server returned non-video response instead of an MP4 file.');
        }

        const totalBytesHeader = Number(response.headers.get('content-length') || '0');
        const totalBytes = Number.isFinite(totalBytesHeader) && totalBytesHeader > 0 ? totalBytesHeader : 0;

        setActiveDownloads((prev) => ({
          ...prev,
          [videoId]: {
            ...prev[videoId],
            totalBytes,
          },
        }));

        const chunks: Uint8Array[] = [];
        let downloadedBytes = 0;

        if (response.body) {
          const reader = response.body.getReader();
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            if (value && value.byteLength > 0) {
              chunks.push(value);
              downloadedBytes += value.byteLength;
              const pct = calculateDownloadProgress(downloadedBytes, totalBytes);
              setActiveDownloads((prev) => {
                const current = prev[videoId];
                if (!current) return prev;
                return {
                  ...prev,
                  [videoId]: {
                    ...current,
                    downloadedBytes,
                    totalBytes: totalBytes || downloadedBytes,
                    progressPct: pct,
                  },
                };
              });
            }
          }
        } else {
          const buf = new Uint8Array(await response.arrayBuffer());
          chunks.push(buf);
          downloadedBytes = buf.byteLength;
        }

        if (downloadedBytes < 1024) {
          throw new Error('Downloaded video file was empty or incomplete.');
        }

        const merged = new Uint8Array(downloadedBytes);
        let offset = 0;
        for (const chunk of chunks) {
          merged.set(chunk, offset);
          offset += chunk.byteLength;
        }

        if (!isValidMp4Buffer(merged)) {
          throw new Error('File verification failed: downloaded stream is not a valid MP4 video.');
        }

        if (totalBytes > 0 && downloadedBytes < totalBytes) {
          throw new Error(
            `Download interrupted at ${downloadedBytes} of ${totalBytes} bytes. Please retry.`
          );
        }

        const videoBlob = new Blob([merged], { type: 'video/mp4' });
        let finalLocation = guidance.targetFolderLabel;

        if (pickedHandle) {
          const writable = await pickedHandle.createWritable();
          await writable.write(videoBlob);
          await writable.close();
          finalLocation = 'Selected Device Folder (Movies / Anime World)';
        } else {
          const objectUrl = URL.createObjectURL(videoBlob);
          const anchor = document.createElement('a');
          anchor.href = objectUrl;
          anchor.download = safeFilename;
          anchor.rel = 'noopener';
          anchor.style.display = 'none';
          document.body.appendChild(anchor);
          anchor.click();
          document.body.removeChild(anchor);
          window.setTimeout(() => URL.revokeObjectURL(objectUrl), 10_000);
        }

        let shareReady = false;
        if (hasFileShare) {
          try {
            const testFile = new File([videoBlob], safeFilename, { type: 'video/mp4' });
            shareReady = navigator.canShare({ files: [testFile] });
          } catch {
            shareReady = false;
          }
        }

        setActiveDownloads((prev) => ({
          ...prev,
          [videoId]: {
            ...prev[videoId],
            status: 'completed',
            progressPct: 100,
            downloadedBytes,
            totalBytes: downloadedBytes,
            saveLocation: finalLocation,
            completedBlob: videoBlob,
            canShareFile: shareReady,
            errorMessage: undefined,
          },
        }));

        if (shouldPersistHistory) {
          await updateDownloadHistoryEntry(downloadDocId, {
            fileSizeBytes: downloadedBytes,
            downloadedBytes,
            status: 'completed',
            saveLocation: finalLocation,
          });
        }

        showFeedback('success', `Download Complete: "${safeFilename}" saved as playable MP4.`);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Video download failed unexpectedly.';
        setActiveDownloads((prev) => {
          const current = prev[videoId];
          return {
            ...prev,
            [videoId]: {
              ...(current || {
                videoId,
                downloadDocId,
                title,
                thumbnailUrl,
                filename: safeFilename,
                progressPct: 0,
                downloadedBytes: 0,
                totalBytes: 0,
                saveLocation: guidance.targetFolderLabel,
                guidanceText: guidance.explanation,
                canShareFile: false,
                canPickFolder: hasFileSystemPicker,
              }),
              status: 'failed',
              errorMessage: message,
            },
          };
        });

        if (shouldPersistHistory) {
          await updateDownloadHistoryEntry(downloadDocId, {
            fileSizeBytes: 0,
            downloadedBytes: 0,
            status: 'failed',
            saveLocation: guidance.targetFolderLabel,
            errorMessage: message,
          });
        }

        showFeedback('error', `Download Failed: ${message}`);
      } finally {
        inFlightSetRef.current.delete(videoId);
      }
    },
    [privateUser?.saveDownloadHistory, showFeedback, user]
  );

  const retryVideoDownload = useCallback(
    async (videoId: string, title: string, thumbnailUrl?: string) => {
      await startVideoDownload({ videoId, title, thumbnailUrl });
    },
    [startVideoDownload]
  );

  const shareDownloadedVideo = useCallback(
    async (videoId: string) => {
      const entry = activeDownloads[videoId];
      if (!entry?.completedBlob) {
        showFeedback('error', 'Download the MP4 video first before sharing to Photos or Gallery.');
        return;
      }
      if (typeof navigator === 'undefined' || typeof navigator.share !== 'function') {
        showFeedback('error', 'Direct share sheet is not supported on this browser.');
        return;
      }
      try {
        const file = new File([entry.completedBlob], entry.filename, { type: 'video/mp4' });
        await navigator.share({
          title: entry.title,
          text: `${entry.title} — THE ANIME WORLD`,
          files: [file],
        });
        showFeedback('success', 'Opened device Save / Share sheet for your Gallery or Files.');
      } catch (err) {
        if (err instanceof Error && err.name !== 'AbortError') {
          showFeedback('error', 'Could not open native share sheet on this browser.');
        }
      }
    },
    [activeDownloads, showFeedback]
  );

  const removeSavedDownload = useCallback(
    async (downloadId: string) => {
      const res = await deleteDownloadHistoryEntry(downloadId);
      showFeedback(res.ok ? 'success' : 'error', res.message);
    },
    [showFeedback]
  );

  const clearAllSavedDownloads = useCallback(async () => {
    const res = await clearUserDownloadHistory(user?.uid);
    showFeedback(res.ok ? 'success' : 'error', res.message);
  }, [showFeedback, user?.uid]);

  return (
    <DownloadContext.Provider
      value={{
        activeDownloads,
        savedDownloads,
        downloadsLoading,
        startVideoDownload,
        retryVideoDownload,
        shareDownloadedVideo,
        removeSavedDownload,
        clearAllSavedDownloads,
      }}
    >
      {children}
    </DownloadContext.Provider>
  );
}

export function useDownloads() {
  const ctx = useContext(DownloadContext);
  if (!ctx) throw new Error('useDownloads must be used within DownloadProvider');
  return ctx;
}
