/**
 * Client-side avatar image cropper and compressor.
 * Resizes user-selected images to a square 160x160 data URL under ~18KB
 * so profile pictures upload instantaneously and validate cleanly against Firestore rules.
 */
export async function resizeAvatarToDataUrl(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Please choose a PNG, JPEG, or WebP image file.');
  }
  if (file.size > 10 * 1024 * 1024) {
    throw new Error('Please select an image smaller than 10 MB.');
  }

  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('Could not decode the selected image file.'));
      el.src = objectUrl;
    });

    const size = 144;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Image processing canvas unavailable in this browser.');

    // Center square crop
    const minSide = Math.min(img.width, img.height);
    const sx = Math.max(0, (img.width - minSide) / 2);
    const sy = Math.max(0, (img.height - minSide) / 2);

    ctx.drawImage(img, sx, sy, minSide, minSide, 0, 0, size, size);

    const qualities = [0.82, 0.68, 0.54, 0.4];
    for (const q of qualities) {
      const webp = canvas.toDataURL('image/webp', q);
      if (webp.startsWith('data:image/webp;base64,') && webp.length <= 22000) {
        return webp;
      }
      const jpeg = canvas.toDataURL('image/jpeg', q);
      if (jpeg.startsWith('data:image/jpeg;base64,') && jpeg.length <= 22000) {
        return jpeg;
      }
    }

    throw new Error('Image is too complex to compress under the 25KB avatar limit. Please try a simpler image.');
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}
