export const ID_REGEX = /^[a-zA-Z0-9_-]+$/;
export const USERNAME_REGEX = /^[a-zA-Z0-9_-]{2,40}$/;
export const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const BLUEPRINT_LIMITS = {
  idMax: 128,
  usernameMin: 2,
  usernameMax: 40,
  displayNameMax: 80,
  bioMax: 500,
  urlMax: 500,
  avatarUrlMax: 25000,
  fullNameMax: 120,
  emailMax: 254,
  collectionNameMax: 100,
  feedbackSubjectMin: 2,
  feedbackSubjectMax: 160,
  feedbackMessageMin: 10,
  feedbackMessageMax: 2000,
  commentMax: 600,
  reportReasonMin: 5,
  reportReasonMax: 600,
} as const;

export function isValidAvatarUrl(url: string): boolean {
  if (typeof url !== 'string' || url.length > BLUEPRINT_LIMITS.avatarUrlMax) return false;
  if (url === '') return true;
  return /^(https?:\/\/.*|data:image\/(webp|jpeg|png);base64,[A-Za-z0-9+/=]+|\/.*)$/.test(url);
}

export function isValidId(id: string): boolean {
  return typeof id === 'string' && id.length >= 1 && id.length <= BLUEPRINT_LIMITS.idMax && ID_REGEX.test(id);
}

export function isValidUsername(username: string): boolean {
  return typeof username === 'string' && USERNAME_REGEX.test(username);
}

export function sanitizeSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80) || 'entry';
}

export function buildAnimeUrl(id: number, title: string): string {
  return `/anime/${id}-${sanitizeSlug(title)}`;
}

export function parseIdFromSlug(slugOrId: string): number | null {
  const match = String(slugOrId).match(/^(\d+)/);
  if (!match) return null;
  const num = Number(match[1]);
  return Number.isInteger(num) && num > 0 ? num : null;
}

export function stripHtmlTags(input: string | null | undefined): string {
  if (!input) return '';
  return input
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&quot;/g, '"')
    .replace(/&#039;|&apos;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .trim();
}

export interface FeedbackInput {
  name: string;
  email: string;
  category: string;
  subject: string;
  message: string;
  rating: number;
}

export const ALLOWED_FEEDBACK_CATEGORIES = [
  'Bug Report',
  'Website Suggestion',
  'Content Request',
  'Technical Issue',
  'General Feedback',
] as const;

export function validateFeedbackInput(input: FeedbackInput): { valid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  const name = input.name.trim();
  const email = input.email.trim();
  const subject = input.subject.trim();
  const message = input.message.trim();

  if (name.length < 1 || name.length > 100) {
    errors.name = 'Name must be between 1 and 100 characters.';
  }
  if (!EMAIL_REGEX.test(email) || email.length > BLUEPRINT_LIMITS.emailMax) {
    errors.email = 'Please enter a valid email address.';
  }
  if (!ALLOWED_FEEDBACK_CATEGORIES.includes(input.category as (typeof ALLOWED_FEEDBACK_CATEGORIES)[number])) {
    errors.category = 'Please choose a valid feedback category.';
  }
  if (subject.length < BLUEPRINT_LIMITS.feedbackSubjectMin || subject.length > BLUEPRINT_LIMITS.feedbackSubjectMax) {
    errors.subject = 'Subject must be between 2 and 160 characters.';
  }
  if (message.length < BLUEPRINT_LIMITS.feedbackMessageMin || message.length > BLUEPRINT_LIMITS.feedbackMessageMax) {
    errors.message = 'Message must be at least 10 characters and under 2000 characters.';
  }
  if (!Number.isInteger(input.rating) || input.rating < 1 || input.rating > 5) {
    errors.rating = 'Rating must be an integer between 1 and 5.';
  }

  return { valid: Object.keys(errors).length === 0, errors };
}

export interface RegistrationInput {
  fullName: string;
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
  acceptTerms: boolean;
}

export function validateRegistrationInput(input: RegistrationInput): { valid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  if (input.fullName.trim().length < 2 || input.fullName.trim().length > BLUEPRINT_LIMITS.fullNameMax) {
    errors.fullName = 'Full name must be between 2 and 120 characters.';
  }
  if (!isValidUsername(input.username.trim())) {
    errors.username = 'Username must be 2-40 characters (letters, numbers, _ or -).';
  }
  if (!EMAIL_REGEX.test(input.email.trim()) || input.email.trim().length > BLUEPRINT_LIMITS.emailMax) {
    errors.email = 'Please provide a valid email address.';
  }
  if (input.password.length < 8) {
    errors.password = 'Password must be at least 8 characters long.';
  }
  if (input.password !== input.confirmPassword) {
    errors.confirmPassword = 'Passwords do not match.';
  }
  if (!input.acceptTerms) {
    errors.acceptTerms = 'You must accept the Terms and Conditions to register.';
  }
  return { valid: Object.keys(errors).length === 0, errors };
}

export function validateFirestorePayload(
  collection: 'publicProfiles' | 'privateUsers' | 'favorites' | 'collections' | 'communityArtworks' | 'feedback' | 'follows' | 'downloads',
  payload: Record<string, unknown>
): { ok: boolean; reason?: string } {
  const keys = Object.keys(payload);
  if (collection === 'publicProfiles') {
    const allowed = new Set([
      'uid', 'username', 'displayName', 'bio', 'avatarUrl', 'coverUrl',
      'isPublic', 'role', 'isSuspended', 'followersCount', 'followingCount', 'createdAt', 'updatedAt',
    ]);
    for (const k of keys) {
      if (!allowed.has(k)) return { ok: false, reason: `Disallowed shadow field: ${k}` };
    }
    if (payload.role !== 'user') return { ok: false, reason: 'Self-assigned role escalation rejected' };
    if (typeof payload.bio === 'string' && payload.bio.length > BLUEPRINT_LIMITS.bioMax) {
      return { ok: false, reason: 'Bio exceeds 500 characters' };
    }
    if (typeof payload.avatarUrl === 'string' && !isValidAvatarUrl(payload.avatarUrl)) {
      return { ok: false, reason: 'Invalid or oversized avatarUrl' };
    }
    if (typeof payload.uid !== 'string' || !isValidId(payload.uid)) {
      return { ok: false, reason: 'Invalid uid format' };
    }
    return { ok: true };
  }
  if (collection === 'privateUsers') {
    const allowed = new Set([
      'uid',
      'email',
      'fullName',
      'favoriteGenres',
      'newsletterOptIn',
      'themePreference',
      'saveDownloadHistory',
      'hideViewingActivity',
      'createdAt',
      'updatedAt',
    ]);
    for (const k of keys) {
      if (!allowed.has(k)) return { ok: false, reason: `Disallowed shadow field: ${k}` };
    }
    if (payload.themePreference !== undefined && payload.themePreference !== 'dark' && payload.themePreference !== 'light') {
      return { ok: false, reason: 'Invalid themePreference' };
    }
    return { ok: true };
  }
  if (collection === 'favorites') {
    const allowed = new Set(['id', 'userId', 'itemId', 'itemType', 'title', 'imageUrl', 'subtitle', 'createdAt']);
    for (const k of keys) {
      if (!allowed.has(k)) return { ok: false, reason: `Disallowed shadow field: ${k}` };
    }
    if (typeof payload.id !== 'string' || !isValidId(payload.id)) return { ok: false, reason: 'Invalid favorite ID' };
    return { ok: true };
  }
  if (collection === 'downloads') {
    const allowed = new Set([
      'id',
      'userId',
      'videoId',
      'title',
      'thumbnailUrl',
      'format',
      'fileSizeBytes',
      'downloadedBytes',
      'status',
      'saveLocation',
      'errorMessage',
      'createdAt',
      'updatedAt',
    ]);
    for (const k of keys) {
      if (!allowed.has(k)) return { ok: false, reason: `Disallowed shadow field: ${k}` };
    }
    if (typeof payload.id !== 'string' || !isValidId(payload.id)) return { ok: false, reason: 'Invalid download ID' };
    if (typeof payload.userId !== 'string' || !isValidId(payload.userId)) return { ok: false, reason: 'Invalid userId' };
    if (typeof payload.videoId !== 'string' || !isValidId(payload.videoId)) return { ok: false, reason: 'Invalid videoId' };
    if (payload.format !== 'MP4') return { ok: false, reason: 'Format must be MP4' };
    if (payload.status !== 'downloading' && payload.status !== 'completed' && payload.status !== 'failed') {
      return { ok: false, reason: 'Invalid download status' };
    }
    return { ok: true };
  }
  if (collection === 'follows') {
    if (payload.followerId === payload.followingId) return { ok: false, reason: 'Self-follow rejected' };
    return { ok: true };
  }
  if (collection === 'feedback') {
    if (payload.status !== 'open') return { ok: false, reason: 'Initial feedback status must be open' };
    return { ok: true };
  }
  return { ok: true };
}
