import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildAnimeUrl,
  isValidId,
  isValidUsername,
  parseIdFromSlug,
  stripHtmlTags,
  validateFeedbackInput,
  validateRegistrationInput,
} from './validation.ts';

test('isValidId accepts alphanumeric, dash, underscore and rejects poisoning strings', () => {
  assert.equal(isValidId('user_123-abc'), true);
  assert.equal(isValidId(''), false);
  assert.equal(isValidId('../admin'), false);
  assert.equal(isValidId('a'.repeat(129)), false);
});

test('isValidUsername enforces 2-40 character safe handle', () => {
  assert.equal(isValidUsername('sora_01'), true);
  assert.equal(isValidUsername('a'), false);
  assert.equal(isValidUsername('bad user!'), false);
});

test('buildAnimeUrl and parseIdFromSlug roundtrip cleanly', () => {
  const url = buildAnimeUrl(154587, 'Frieren: Beyond Journey’s End');
  assert.equal(url, '/anime/154587-frieren-beyond-journey-s-end');
  const slugSegment = url.replace('/anime/', '');
  assert.equal(parseIdFromSlug(slugSegment), 154587);
  assert.equal(parseIdFromSlug('not-a-number'), null);
});

test('stripHtmlTags removes HTML tags and decodes entities', () => {
  assert.equal(stripHtmlTags('<p>Hello &amp; <i>World</i></p><br/>Next'), 'Hello & World\nNext');
});

test('validateFeedbackInput enforces required fields, email, rating, and message length', () => {
  const invalid = validateFeedbackInput({
    name: '',
    email: 'bad-email',
    category: 'Unknown',
    subject: 'A',
    message: 'short',
    rating: 7,
  });
  assert.equal(invalid.valid, false);
  assert.ok(invalid.errors.name);
  assert.ok(invalid.errors.email);
  assert.ok(invalid.errors.category);
  assert.ok(invalid.errors.subject);
  assert.ok(invalid.errors.message);
  assert.ok(invalid.errors.rating);

  const valid = validateFeedbackInput({
    name: 'Akira',
    email: 'akira@example.com',
    category: 'Website Suggestion',
    subject: 'Add 4K Filter',
    message: 'Would love a dedicated 4K landscape filter on mobile.',
    rating: 5,
  });
  assert.equal(valid.valid, true);
});

test('validateRegistrationInput validates password match and terms acceptance', () => {
  const mismatch = validateRegistrationInput({
    fullName: 'Akira Ren',
    username: 'akira_ren',
    email: 'akira@example.com',
    password: 'Password123',
    confirmPassword: 'Password999',
    acceptTerms: false,
  });
  assert.equal(mismatch.valid, false);
  assert.ok(mismatch.errors.confirmPassword);
  assert.ok(mismatch.errors.acceptTerms);
});
